

-- SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- Schema BridgerRFCommon
-- ----------------------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.SystemUtilitiesInfoQueue
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[SystemUtilitiesInfoQueue](
	[InfoQueueItemId] [int] IDENTITY(2,2) NOT NULL,
	[ResultMultAlertProcInfoId] [bigint] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[QueueProcessingType] [int] NOT NULL,
	[InfoQueueItemStatus] INT NOT NULL CONSTRAINT "DF_SU_InfoQueueItemStatus" DEFAULT 1,
	[EnvironmentType] [int] NOT NULL,
	[DateQueued] [datetime] NOT NULL,
 CONSTRAINT [PK_SystemUtilitiesInfoQueue] PRIMARY KEY CLUSTERED 
(
	[InfoQueueItemId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.BatchMgmtUploadBatchQueue
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[BatchMgmtBatchUploadQueue](
	[Id] BINARY(16) NOT NULL,
	[CustomerId] INT NOT NULL,
	[Status] INT NOT NULL DEFAULT 1,
    [BatchServerName] NVARCHAR(64) NULL,
    [DateQueued] DATETIME NOT NULL,
    [EnvironmentType] INT NOT NULL,
    [DelayUntilDate] DATETIME NULL,	
 CONSTRAINT [PK_dbo.BatchMgmtBatchUploadQueue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtLoginHistory
-- ----------------------------------------------------------------------------

CREATE TABLE [dbo].[UserMgmtUserAudit](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[UserName] [varchar](50) NOT NULL,
	[UserType] [int] NOT NULL,
	[Event] [int] NOT NULL,
	[IpAddress] [varchar](50)  NULL,
	[UserAgent] [varchar](512) NULL,
	[Status] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[AssociatedId] BIGINT NULL,
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_usermgmtuseraudit] PRIMARY KEY CLUSTERED  
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) 
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtUserAudit_UserId_UserType] ON [dbo].[UserMgmtUserAudit]
(
    [UserId] ASC,
	[UserType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO


-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtCustomers
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtCustomers](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [CustomerLoginName] [nvarchar](50) NOT NULL,
    [CustomerSettings_IsActive] [bit] NOT NULL,
    [CustomerSettings_IsFreeTrial] [bit] NOT NULL,
    [CustomerSettings_DateFreeTrialAccepted] [datetime] NULL,
    [CustomerSettings_DateFreeTrialExpires] [datetime] NULL,
    [CustomerSettings_EulaAcceptedBy] [nvarchar](50) NULL,
    [CustomerSettings_DateEulaAccepted] [datetime] NULL,
    [CustomerSettings_DatabaseIdentifier] [nvarchar](50) NOT NULL,
    [CustomerSettings_WebAppIdentifier] [nvarchar](50) NOT NULL,
    [CustomerSettings_DefaultCulture] [nvarchar](50) NOT NULL,
    [CustomerSettings_AllowableIPRanges] [nvarchar](max) NULL,
    [CustomerSettings_WebServicesType] [int] NOT NULL,
    [CustomerSettings_EnabledProviders] [nvarchar](200) NULL,
    [CustomerSettings_ProviderCredentials] [nvarchar](max) NULL,
    [CustomerSettings_SecurityMessage] [nvarchar](255) NULL,
	[CustomerSettings_BillingType] [int] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_CustomerSettings_BillingType" default(0),
	[CustomerSettings_DateFormat] [int] NULL CONSTRAINT "DF_UserMgmtCustomers_CustomerSettings_DateFormat" default(0),
    [ExcludedAcceptlists] [nvarchar](max) NULL,
    [ExcludedCustomWatchlists] [nvarchar](max) NULL,
    [IncludedAcceptlists] [nvarchar](max) NULL,
    [IncludedCustomWatchlists] [nvarchar](max) NULL,
    [SecurityPolicy_PolicyChangedBy] [nvarchar](50) NULL,
    [SecurityPolicy_DatePolicy] [datetime] NULL,
    [SecurityPolicy_MinPasswordLength] [int] NOT NULL,
    [SecurityPolicy_PasswordExpiresDays] [int] NOT NULL,
    [SecurityPolicy_IdleTimeout] [int] NOT NULL,
    [SecurityPolicy_InactiveAccountLockedDays] [int] NOT NULL,
    [SecurityPolicy_MaxInvalidLoginAttempts] [int] NOT NULL,
	[SecurityPolicy_MFAOption] int NOT NULL DEFAULT 0,
    [SecurityPolicy_MFACodeLength] int NOT NULL DEFAULT 4, 	
    [AccountInfo_CustomerFullName] [nvarchar](255) NULL,
	[AccountInfo_TypeOfInstitution] [nvarchar](255) NULL,
    [AccountInfo_Identifier] [nvarchar](255) NULL,
    [AccountInfo_IsInternalAccount] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_AccountInfo_IsInternalAccount" default(0),
    [AccountInfo_UseSystemProductCode] [bit] NOT NULL,
    [AccountInfo_ProductCode] [nvarchar](50) NULL,
    [AccountInfo_ProductVersion] [nvarchar](50) NULL,
    [AccountInfo_AccountType] [nvarchar](50) NULL,
    [AccountInfo_Description] [nvarchar](255) NULL,
    [AccountInfo_Address1] [nvarchar](255) NULL,
    [AccountInfo_Address2] [nvarchar](255) NULL,
    [AccountInfo_City] [nvarchar](120) NULL,
    [AccountInfo_State] [nvarchar](50) NULL,
    [AccountInfo_PostalCode] [nvarchar](20) NULL,
    [AccountInfo_Country] [nvarchar](100) NULL,
    [AccountInfo_Contact] [nvarchar](255) NULL,
    [AccountInfo_Phone] [nvarchar](20) NULL,
    [AccountInfo_PhoneExtension] [nvarchar](10) NULL,
    [AccountInfo_Fax] [nvarchar](20) NULL,
    [AccountInfo_EmailAddress] [nvarchar](320) NULL,
    [Privileges_CanAutomaticBatch] [bit] NOT NULL,
    [Privileges_CanAutomaticBatchOutputFiles] [bit] NOT NULL,
    [Privileges_CanHaveAttachments] [bit] NOT NULL,
    [Privileges_MaxAttachmentSize] [int] NOT NULL,
    [Privileges_CanSaveAllResults] [bit] NOT NULL,
    [Privileges_OnlyReturnResults] [bit] NOT NULL,
	[Privileges_MFACustomerActive] [BIT] NOT NULL DEFAULT 1,
	Privileges_WatchListSelections IMAGE NULL,
   -- TODO: remove Privileges_WatchListSelections above in time
    Privileges_ExcludedWatchlists IMAGE NULL,	
    [FtpSettings_Password] [nvarchar](150) NULL,
    [FtpSettings_OutputFilesPassword] [nvarchar](150) NULL,
    [DuplicateMatchSettings_SuppressDuplicatesForBatch] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_SuppressDuplicatesForBatch" default(0),
    [DuplicateMatchSettings_SameDivisionOnly] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_SameDivisionOnly" default(0),
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_IsDeleted" default(0),
	[UpdateHistoricClientUsageData] [bit] NOT NULL CONSTRAINT DF_UserMgmtCustomers_UpdateHistoricClientUsageData DEFAULT 0,
	[MaxOriginalResultId] [bigint] NULL,
	[AmlEnvironmentType] TINYINT NOT NULL CONSTRAINT "DF_Aml_EnvironmentType" DEFAULT 0,
	[CustomerStatus] INT NOT NULL CONSTRAINT "DF_Customer_Status" DEFAULT 0,
	[InActiveDate] DATETIME NULL,
	[DeletedDate] DATETIME NULL,
	[OriginalId] [bigint] NULL, 
	[Privileges_IsFprEnabled] BIT NOT NULL CONSTRAINT "DF_UserMgmtCustomers_Privileges_IsFprEnabled" default(0),
 CONSTRAINT [PK_dbo.UserMgmtCustomers] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtCustomers_LoginName_IsActive_IsDeleted] ON [dbo].[UserMgmtCustomers]
(
    [CustomerLoginName] ASC,
	[CustomerSettings_IsActive] ASC,
    [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtCustomerDeleteCounts
-- ----------------------------------------------------------------------------
CREATE TABLE [usermgmtcustomerdeletecounts](
    [CustomerId] int not null, 
	[TableName] varchar(100) not null, 
    [InitialRowCount] bigint NOT NULL DEFAULT 0, 
    [DeletedRowCount] bigint NOT NULL DEFAULT 0, 
	[CurrentRowCount] bigint NOT NULL DEFAULT 0, 
    PRIMARY KEY(CustomerId, TableName));
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtAuditRecords
-- ----------------------------------------------------------------------------
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserMgmtAuditRecords](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [Action] [int] NOT NULL,
    [ActorName] [nvarchar](255) NULL,
    [Date] [datetime] NOT NULL,
    [ActionItemType] [int] NOT NULL,
    [ActionItemId] [int] NOT NULL,
    [ActionItemName] [nvarchar](255) NULL,
    [ActionItemParentId] [int] NULL,
    [ActionItemParentName] [nvarchar](255) NULL,
	[CustomerId] [int] NULL,
 	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.UserMgmtAuditRecords] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFMisc.AuthenticationToken
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtAuthenticationToken](
	[TokenId] [nvarchar](50) NOT NULL,
	[TokenData] [varbinary](max) NULL,
	[Customer_Id] [int] NOT NULL,
	[User_id] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,	
	[DateModified] [datetime] NOT NULL,
	[TokenState] [int] NOT NULL,
	[IpAddress] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[TokenId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[UserMgmtAuthenticationToken] ADD  CONSTRAINT [DF_authenticationtoken_TokenState]  DEFAULT ((0)) FOR [TokenState]
GO

CREATE NONCLUSTERED INDEX IX_AuthenticationToken_CustomerId ON [dbo].[UserMgmtAuthenticationToken] 
(
   Customer_Id
)
 
CREATE NONCLUSTERED INDEX IX_AuthenticationToken_UserId ON [dbo].[UserMgmtAuthenticationToken] 
(
   User_Id
)

CREATE NONCLUSTERED INDEX IX_AuthenticationToken_TokenState ON [dbo].[UserMgmtAuthenticationToken] 
(
   TokenState
)

GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFMisc.SessionState
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSessionState](
	[SessionId] [nvarchar](40) NOT NULL,
	[ApplicationName] [nvarchar](10) NULL,	
	[Created] [datetime] NOT NULL,
	[Expires] [datetime] NOT NULL,
	[LockDate] [datetime] NOT NULL,
	[LockId] [int] NOT NULL,
	[Timeout] [int] NOT NULL,
	[Locked] [bit] NOT NULL CONSTRAINT "DF_SessionState_Locked" DEFAULT 0,
	[SessionItems] [varbinary](max) NULL,
	[Flags] [int] NOT NULL,
)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtSystemSettings
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSystemSettings](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] datetime NOT NULL CONSTRAINT DF_UserMgmtSystemSettings_DateCreated default (getutcdate()),
	[DateModified] [datetime] NOT NULL CONSTRAINT DF_UserMgmtSystemSettings_DateModified default (getutcdate()),
	[CreatedBy] nvarchar(50) NULL,
	[ModifiedBy] nvarchar(50) NULL,
    [SystemName] [nvarchar](256) NULL,
    [ProductCode] [nvarchar](24) NULL,
    [IsSystemWideProductCode] [bit] NOT NULL,
    [AuthenticationType] [int] NOT NULL,
    [DefaultFreeTrialDays] [int] NOT NULL,
    [DefaultMaxBatchSize] [int] NOT NULL,
    [SMTPPrimaryServer] [nvarchar](256) NULL,
    [SMTPPrimaryPort] [int] NULL,
    [SMTPPrimaryUserName] [nvarchar](256) NULL,
    [SMTPPrimaryPassword] [nvarchar](256) NULL,
    [SMTPSecondaryServer] [nvarchar](256) NULL,
    [SMTPSecondaryPort] [int] NULL,
    [SMTPSecondaryUserName] [nvarchar](256) NULL,
    [SMTPSecondaryPassword] [nvarchar](256) NULL,    
    [SMTPReturnAddress] [nvarchar](256) NULL,
    [BatchFileSystemType] [int] NOT NULL CONSTRAINT DF_UserMgmtSystemSettings_BatchFileSystemType default (1),
    [FTPPrimaryHostName] [nvarchar](256) NULL,
    [FTPPrimaryPort] [int] NULL,
    [FTPPrimaryLogonType] [int] NULL,
    [FTPPrimaryUserName] [nvarchar](256) NULL,
    [FTPPrimaryPassword] [nvarchar](256) NULL,
    [FTPPrimaryKey] [text] NULL,
    [FTPPrimaryKeyPassCode] [nvarchar](50) NULL,
    [FTPPrimaryTimeoutInSeconds] [int] NULL,
    [FTPPrimaryAutomaticBatchDirectory] [nvarchar](256) NULL,
    [FTPPrimaryGuiBatchDirectory] [nvarchar](256) NULL,
    [FTPPrimaryStartDirectory] [nvarchar](256) NULL,
    [FTPPrimaryOutputFilesDirectory] [nvarchar](256) NULL,
    [NetworkShareAutomaticBatchDirectory] [nvarchar](256) NULL,
    [NetworkShareGuiBatchDirectory] [nvarchar](256) NULL,
    [NetworkShareStartDirectory] [nvarchar](256) NULL,
    [NetworkShareOutputFilesDirectory] [nvarchar](256) NULL,
	[ImportService] [bit] NOT NULL,
    [AMLSolutionsID] [nvarchar](64) NULL,
    [AMLUserID] [nvarchar](256) NULL,
    [AMLPassword] [nvarchar](256) NULL,
    [ProxySettings_Address] [nvarchar](256) NULL,
    [ProxySettings_UserId] [nvarchar](256) NULL,
    [ProxySettings_Password] [nvarchar](256) NULL,
    [ProxySettings_Port] [int] NOT NULL,	
    IsEnterprise BIT NOT NULL CONSTRAINT "DF_UM_Sys_IsEnterprise" DEFAULT 0,
    IsDecryptionEnabled BIT NOT NULL CONSTRAINT "DF_UM_Sys_IsDecryptionEnabled" DEFAULT 0,
    EnableNTLM BIT NOT NULL CONSTRAINT "DF_UM_Sys_EnableNTLM" DEFAULT 0,
    [LDAPServerPath] [nvarchar](255) NULL,
    [IsImportLoginValid] BIT NOT NULL CONSTRAINT "DF_IsImportLoginValid" DEFAULT 0,
    [AllowableIPRanges] [nvarchar](max) NULL,
	[MFASystemActive] [bit] NOT NULL CONSTRAINT "DF_Sett_MFASystemActive" DEFAULT 1,
    [RequireWindowsAuthForSystemUsers] [bit] NOT NULL CONSTRAINT "DF_RequireWindowsAuthForSystemUsers" DEFAULT 0,
	[IsTmxEnabled] BIT NOT NULL CONSTRAINT "DF_UM_Sys_IsTmxEnabled" DEFAULT 0,
	[ThreatMetrixUserId] [nvarchar](256) NULL,
    [ThreatMetrixPassword] [nvarchar](256) NULL,
 CONSTRAINT [PK_dbo.UserMgmtSystemSettings] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtSystemRoles
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSystemRoles](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [Name] [nvarchar](100) NOT NULL,
    [Description] [nvarchar](255) NULL,
    [Privileges] [nvarchar](255) NULL,
 CONSTRAINT [PK_dbo.UserMgmtSystemRoles] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtProductCodeEntitlements
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtProductCodeEntitlements](
    [ProductCode] [nvarchar](19) NOT NULL,
    [EntitlementBitfield] [varbinary](2048) NULL,
    [MbsId] [int] NOT NULL CONSTRAINT "DF_UM_PC_MbsId" DEFAULT 0,
    [MbsDescription] [nvarchar](500) NULL,
 CONSTRAINT [PK_dbo.UserMgmtProductCodeEntitlements] PRIMARY KEY CLUSTERED
(
    [ProductCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtProductFeatureEntitlements
-- ----------------------------------------------------------------------------

CREATE TABLE [dbo].[UserMgmtProductFeatureEntitlements](
	[Id] [int] IDENTITY(1,1) NOT NULL,
    [ProductCode] [nvarchar](19) NOT NULL,
    [Feature] [int] NOT NULL CONSTRAINT "DF_UM_PCFeature" DEFAULT 0,
    [DateCreated] [datetime] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtProductFeatureEntitlements] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtWatchlistData
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtWatchlistData](
    [FileId] [BINARY](16) NOT NULL,
    [Name] [nvarchar](255) NULL,
    [BitfieldPosition] [int] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtWatchlistData] PRIMARY KEY CLUSTERED
(
    [FileId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtSystemUsers
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSystemUsers](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [InternalId] [int] NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
	[MFAVerified] [nvarchar](20) NULL,
    [LoginName] [nvarchar](50) NULL,
    [Password] [nvarchar](100) NULL,
    [FullName] [nvarchar](255) NULL,
    [EmployeeId] [nvarchar](100) NULL,
    [EmailAddress] [nvarchar](320) NULL,
    [LoginFailedAttempts] [int] NOT NULL,
    [IsLocked] [bit] NOT NULL,	
    [IsPasswordChangeRequired] [bit] NOT NULL,
    [PasswordResetKey] [nvarchar](36) NULL,
    [PasswordResetKeyExpiration] [datetime] NULL,
    [PasswordModified] [datetime] NULL,
    [Role_Id] [int] NOT NULL,
	[IPSettingsShowAll] [bit] NOT NULL CONSTRAINT "DF_Ums_IPSettingsShowAll" default(0),
	[ScreeningListShowAll] [bit] NOT NULL CONSTRAINT "DF_Ums_ScreeningListShowAll" default(0),
	[IsDeleted] [bit] NOT NULL DEFAULT 0,
	[Domain] [nvarchar](256) NULL,
	
 CONSTRAINT [PK_dbo.UserMgmtSystemUsers] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Role_Id_IsDeleted] ON [dbo].[UserMgmtSystemUsers]
(
    [Role_Id] ASC,
	[IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon._conversion_log
-- ----------------------------------------------------------------------------	
CREATE TABLE [dbo].[_conversion_log] (
	[id] [int] IDENTITY(1,1) NOT NULL,
	[module] [nvarchar](500) NOT NULL,
	[clientid] [nvarchar](50) NOT NULL,
	[status] [int] NOT NULL,
	[date_created] [datetime] NOT NULL,
	[comments] [nvarchar](max) NULL,
	[exception_info] [nvarchar](max) NULL,
	[Is_Preconverted] BIT NOT NULL CONSTRAINT "DF_Conv_Is_Preconverted" DEFAULT 0,
	CONSTRAINT [PK_conversion_log] PRIMARY KEY CLUSTERED ( [id] ASC ))
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtRoles
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtRoles](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [Name] [nvarchar](100) NOT NULL,
    [Description] [nvarchar](255) NOT NULL,
    [EmailOnAlertsAssignment] [bit] NOT NULL,
    [CanRemove] [bit] NOT NULL,
    [Privileges] [nvarchar](255) NULL,
    [Customer_Id] [int] NOT NULL,
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtRoles_IsDeleted" default(0),
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.UserMgmtRoles] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Customer_Id] ON [dbo].[UserMgmtRoles]
(
    [Customer_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtRolePrivilege
-- ----------------------------------------------------------------------------
CREATE TABLE [UserMgmtRolePrivilege] (
  [Id] [INT] IDENTITY(1,1) NOT NULL,
  [CustomerId] [INT] NOT NULL DEFAULT 0,
  [RoleId] [INT] NOT NULL DEFAULT 0,  
  [PrivilegeId] [INT] NOT NULL DEFAULT 0,
  [DateCreated] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [CreatedBy] [NVARCHAR](50) NULL,
  [DateModified] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [ModifiedBy] [NVARCHAR](50) NULL,
  [OriginalId] [BIGINT] NULL
   CONSTRAINT [PK_UserMgmtRolePrivilege] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_RoleId] ON [UserMgmtRolePrivilege]
(
    [RoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtDivisions
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtDivisions](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [Name] [nvarchar](100) NOT NULL,
    [Description] [nvarchar](255) NOT NULL,
    [CanRemove] [bit] NOT NULL,
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtDivisions_IsDeleted" default(0),
    [Customer_Id] [int] NOT NULL,
	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.UserMgmtDivisions] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Customer_Id] ON [dbo].[UserMgmtDivisions]
(
    [Customer_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtPreviousSystemUserPasswords
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtPreviousSystemUserPasswords](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [Password] [nvarchar](100) NULL,
    [DateCreated] [datetime] NOT NULL,
    [SystemUser_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtPreviousSystemUserPasswords] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_SystemUser_Id] ON [dbo].[UserMgmtPreviousSystemUserPasswords]
(
    [SystemUser_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtUsers
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtUsers](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,	
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [CanRemove] [bit] NOT NULL,
    [LoginName] [nvarchar](50) NOT NULL,
	[MFAVerified] [nvarchar](20) NULL,
    [Password] [nvarchar](100) NULL,
    [CallOutPermissions] [nvarchar](50) NULL default 'alert,realtime',
	[InternalId] [nvarchar](20) NULL,
    [IsActive] [bit] NOT NULL,
    [IsLocked] [bit] NOT NULL,
    [IsShortcutEnabled] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUsers_IsShortcutEnabled" default(0),
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUsers_IsDeleted" default(0),
    [IsPasswordChangeRequired] [bit] NOT NULL,
    [IsChallengeRequired] [bit] NOT NULL CONSTRAINT "DF__UserMgmtUsers__IsChallengeRequired" default(0),
    [ChallengeSetupRequired] [bit] NOT NULL CONSTRAINT "DF__UserMgmtUsers__ChallengeSetupRequired" default(0),
    [PasswordModified] [datetime] NULL,
    [PasswordResetKey] [nvarchar](36) NULL,
    [PasswordResetKeyExpiration] [datetime] NULL,
    [LoginFailedAttempts] [int] NOT NULL,
    [PreviousLogin] [datetime] NULL,
    [LastLogin] [datetime] NULL,
    [DateCookieDisclaimerAccepted] [datetime] NULL,
    [DateEulaAccepted] [datetime] NULL,
    [Role_Id] [int] NOT NULL,
    [Customer_Id] [int] NOT NULL,	
	[MFACode] varchar(20) DEFAULT NULL,
	[MFACodeDate] datetime DEFAULT NULL,
	[MFARequired] [bit] NOT NULL DEFAULT 0,
	[MFAFullyAuthenticated] [bit] NOT NULL DEFAULT 0,	
	[IsTestUser] bit NOT NULL CONSTRAINT "DF_UM_IsTestUser" DEFAULT 0,
	[IsConvertedUser] bit NOT NULL CONSTRAINT "DF_UM_IsConvertedUser" DEFAULT 0,
	[Version] [int] NULL,
	[LastEmailedTime] datetime NULL,
	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.UserMgmtUsers] PRIMARY KEY CLUSTERED
(
    [Id] ASC
), 
CONSTRAINT [UIX_CustomerID_LoginName] UNIQUE NONCLUSTERED
(
	[LoginName], [Customer_Id], [IsDeleted], [Version]
)
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Customer_Id] ON [dbo].[UserMgmtUsers]
(
    [Customer_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_Role_Id] ON [dbo].[UserMgmtUsers]
(
    [Role_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_User_LoginName] ON [dbo].[UserMgmtUsers]
(
	[LoginName] ASC
)
INCLUDE ( [IsActive], [IsDeleted]) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtUserProfiles
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtUserProfiles](
    [Id] [int] NOT NULL,
    [DateCreated] datetime not null constraint DF_UserMgmtUserProfiles_DateCreated default (getutcdate()),
	[DateModified] [datetime] not null constraint DF_UserMgmtUserProfiles_DateModified default (getutcdate()),
	[CreatedBy] nvarchar(50) null,
	[ModifiedBy] nvarchar(50) null,
    [FullName] [nvarchar](255) NOT NULL,
    [EmailAddress] [nvarchar](320) NOT NULL,
    [Domain] [nvarchar](256) NULL,
    [Homepage] [nvarchar](2048) NULL,
    [NotifyOnAlertAssignment] [bit] NOT NULL,
    [AllDivisions] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_AllDivisions" DEFAULT 0,
    [AMLLoginName] [nvarchar](50) NULL,
    [WebServiceOnly] [bit] NOT NULL,
	[UploadFileDivision] [int] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileDivision" DEFAULT 0,
	[UploadFileDistribution] [int] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileDistribution" DEFAULT 0,
	[UploadFileAllCompletedScans] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileAllCompletedScans" DEFAULT 0,
	[UploadFileScansWithAlerts] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileScansWithAlerts" DEFAULT 1,
	[UploadFileTransactionDetails] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileTransactionDetails" DEFAULT 0,
	[DefaultPageSize] [int] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_DefaultPageSize" DEFAULT 25,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_UserMgmtUserProfiles_CustomerId DEFAULT (0),
    [NewAlertViewEnabled] [bit] NULL DEFAULT 0,
 CONSTRAINT [PK_dbo.UserMgmtUserProfiles] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Id] ON [dbo].[UserMgmtUserProfiles]
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtUserProfiles_CustomerId] ON [dbo].[UserMgmtUserProfiles] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtSecurityQuestions
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSecurityQuestions](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [Question] [BINARY](16) NOT NULL,
    [Answer] [nvarchar](255) NULL,
    [User_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_UserMgmtSecurityQuestions_CustomerId DEFAULT (0),
 CONSTRAINT [PK_dbo.UserMgmtSecurityQuestions] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_User_Id] ON [dbo].[UserMgmtSecurityQuestions]
(
    [User_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtSecurityQuestions_CustomerId] ON [dbo].[UserMgmtSecurityQuestions] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtPreviousUserPasswords
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtPreviousUserPasswords](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [Password] [nvarchar](100) NULL,
    [DateCreated] [datetime] NOT NULL,
    [User_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_UserMgmtPreviousUserPasswords_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.UserMgmtPreviousUserPasswords] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_User_Id] ON [dbo].[UserMgmtPreviousUserPasswords]
(
    [User_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtPreviousUserPasswords_CustomerId] ON [dbo].[UserMgmtPreviousUserPasswords] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtDivisionUsers
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtDivisionUsers](
    [Division_Id] [int] NOT NULL,
    [User_Id] [int] NOT NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT DF_UserMgmtDivisionUsers_CustomerId DEFAULT (0),
 CONSTRAINT [PK_dbo.UserMgmtDivisionUsers] PRIMARY KEY CLUSTERED
(
    [Division_Id] ASC,
    [User_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Division_Id] ON [dbo].[UserMgmtDivisionUsers]
(
    [Division_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_User_Id] ON [dbo].[UserMgmtDivisionUsers]
(
    [User_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtDivisionUsers_CustomerId] ON [dbo].[UserMgmtDivisionUsers] 
(
	[CustomerId] ASC,
	[Division_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

/****** Object:  ForeignKey [FK_dbo.UserMgmtSystemUsers_dbo.UserMgmtSystemRoles_Role_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtSystemUsers]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtSystemUsers_dbo.UserMgmtSystemRoles_Role_Id] FOREIGN KEY([Role_Id])
REFERENCES [dbo].[UserMgmtSystemRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtSystemUsers] CHECK CONSTRAINT [FK_dbo.UserMgmtSystemUsers_dbo.UserMgmtSystemRoles_Role_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtRoles_dbo.UserMgmtCustomers_Customer_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtRoles]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtRoles_dbo.UserMgmtCustomers_Customer_Id] FOREIGN KEY([Customer_Id])
REFERENCES [dbo].[UserMgmtCustomers] ([Id])
GO
ALTER TABLE [dbo].[UserMgmtRoles] CHECK CONSTRAINT [FK_dbo.UserMgmtRoles_dbo.UserMgmtCustomers_Customer_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtDivisions_dbo.UserMgmtCustomers_Customer_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtDivisions]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtDivisions_dbo.UserMgmtCustomers_Customer_Id] FOREIGN KEY([Customer_Id])
REFERENCES [dbo].[UserMgmtCustomers] ([Id])
GO
ALTER TABLE [dbo].[UserMgmtDivisions] CHECK CONSTRAINT [FK_dbo.UserMgmtDivisions_dbo.UserMgmtCustomers_Customer_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtPreviousSystemUserPasswords_dbo.UserMgmtSystemUsers_SystemUser_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtPreviousSystemUserPasswords]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtPreviousSystemUserPasswords_dbo.UserMgmtSystemUsers_SystemUser_Id] FOREIGN KEY([SystemUser_Id])
REFERENCES [dbo].[UserMgmtSystemUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtPreviousSystemUserPasswords] CHECK CONSTRAINT [FK_dbo.UserMgmtPreviousSystemUserPasswords_dbo.UserMgmtSystemUsers_SystemUser_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtUsers_dbo.UserMgmtCustomers_Customer_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtUsers]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtUsers_dbo.UserMgmtCustomers_Customer_Id] FOREIGN KEY([Customer_Id])
REFERENCES [dbo].[UserMgmtCustomers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtUsers] CHECK CONSTRAINT [FK_dbo.UserMgmtUsers_dbo.UserMgmtCustomers_Customer_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtUsers_dbo.UserMgmtRoles_Role_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtUsers]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtUsers_dbo.UserMgmtRoles_Role_Id] FOREIGN KEY([Role_Id])
REFERENCES [dbo].[UserMgmtRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtUsers] CHECK CONSTRAINT [FK_dbo.UserMgmtUsers_dbo.UserMgmtRoles_Role_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtUserProfiles_dbo.UserMgmtUsers_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtUserProfiles]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtUserProfiles_dbo.UserMgmtUsers_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[UserMgmtUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtUserProfiles] CHECK CONSTRAINT [FK_dbo.UserMgmtUserProfiles_dbo.UserMgmtUsers_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtSecurityQuestions_dbo.UserMgmtUsers_User_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtSecurityQuestions]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtSecurityQuestions_dbo.UserMgmtUsers_User_Id] FOREIGN KEY([User_Id])
REFERENCES [dbo].[UserMgmtUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtSecurityQuestions] CHECK CONSTRAINT [FK_dbo.UserMgmtSecurityQuestions_dbo.UserMgmtUsers_User_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtPreviousUserPasswords_dbo.UserMgmtUsers_User_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtPreviousUserPasswords]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtPreviousUserPasswords_dbo.UserMgmtUsers_User_Id] FOREIGN KEY([User_Id])
REFERENCES [dbo].[UserMgmtUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtPreviousUserPasswords] CHECK CONSTRAINT [FK_dbo.UserMgmtPreviousUserPasswords_dbo.UserMgmtUsers_User_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtDivisionUsers_dbo.UserMgmtDivisions_Division_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtDivisionUsers]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtDivisionUsers_dbo.UserMgmtDivisions_Division_Id] FOREIGN KEY([Division_Id])
REFERENCES [dbo].[UserMgmtDivisions] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtDivisionUsers] CHECK CONSTRAINT [FK_dbo.UserMgmtDivisionUsers_dbo.UserMgmtDivisions_Division_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.UserMgmtDivisionUsers_dbo.UserMgmtUsers_User_Id]    Script Date: 08/26/2013 14:32:30 ******/
/* ALTER TABLE [dbo].[UserMgmtDivisionUsers]  WITH CHECK ADD  CONSTRAINT [FK_dbo.UserMgmtDivisionUsers_dbo.UserMgmtUsers_User_Id] FOREIGN KEY([User_Id])
REFERENCES [dbo].[UserMgmtUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserMgmtDivisionUsers] CHECK CONSTRAINT [FK_dbo.UserMgmtDivisionUsers_dbo.UserMgmtUsers_User_Id]
GO */

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.WlMgmtWatchlistsInfo
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistsInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[FileId] [BINARY](16) NOT NULL,
	[ParentFileId] [BINARY](16) NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Description] [nvarchar](1024) NULL,
	[HashFull] [varchar](32) NOT NULL,
	[HashPartial] [varchar](32) NOT NULL,
	[BridgerDataFileType] [int] NULL,
	[BridgerBdfDataFileType] [nvarchar](19) NULL,
	[IsPep] [bit] NULL,
	[IsSpecial] [bit] NULL,
	[Is32Bit] [bit] NULL,
	[IsCompressed] [bit] NOT NULL CONSTRAINT DF_Wlmgmtwatchlistsinfo_IsCompressed default(0),
	[HasWeakAka] [bit] NOT NULL,
	[HasSearchCriteria] [bit] NOT NULL,
	[FileSize] [bigint] NOT NULL,
	[Version] [varchar](255) NOT NULL,
	[DatePublished] [datetime] NULL,
	[DateFileBuild] [datetime] NOT NULL,
	[DateUpdated] [datetime] NULL,
	[DateAdded] [datetime] NOT NULL,
	[DateLastAccessed] [datetime] NULL,
	[Flag] [int] NOT NULL,
	[Available] [bit] NOT NULL CONSTRAINT DF_WlMgmtWatchlistsInfo_Available default(0),
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLInfo_EnvironmentType" DEFAULT(0),
 CONSTRAINT [pk_WlMgmtWatchlistsInfo] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_WlMgmtWatchlistsInfo_DateFileBuild] ON [dbo].[WlMgmtWatchlistsInfo] 
(
	[DateFileBuild] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 

GO

CREATE UNIQUE NONCLUSTERED INDEX IX_WlMgmtWatchlistsInfo_FileId_Version_Environment ON dbo.WlMgmtWatchlistsInfo
(
    [FileId], [Version],[EnvironmentType]
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
GO

CREATE NONCLUSTERED INDEX IX_WlMgmtWatchListInfo_Available_EnvironmentType_Name ON dbo.WlMgmtWatchlistsInfo
(
    [Available], [EnvironmentType], [Name]
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

ALTER TABLE [dbo].[WlMgmtWatchlistsInfo] ADD  CONSTRAINT [DF_WlMgmtWatchlistsInfo_HasWeakAka]  DEFAULT ((1)) FOR [HasWeakAka]
GO

ALTER TABLE [dbo].[WlMgmtWatchlistsInfo] ADD  CONSTRAINT [DF_WlMgmtWatchlistsInfo_HasSearchCriteria]  DEFAULT ((1)) FOR [HasSearchCriteria]
GO

ALTER TABLE [dbo].[WlMgmtWatchlistsInfo] ADD  CONSTRAINT [DF_WlMgmtWatchlistsInfo_Version]  DEFAULT ('1.0.0') FOR [Version]
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.WlMgmtWatchlistsUpdateSchedule
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistsUpdateSchedule](
	[Id] [int] IDENTITY(2,2) NOT NULL,	
	[UpdateServerUrl] [nvarchar](512) NULL,
	[Files] [nvarchar](max) NULL,
	[ScheduleType] [smallint] NOT NULL,
	[Interval] [int] NOT NULL,
	[DailyUpdateTime] [datetime] NULL,
	[LastUpdateTime] [datetime] NULL,
	[NextUpdateTime] [datetime] NULL,
	[EmailAddresses] [ntext] NULL,
	[CurrentUserId] [int] NULL,
	[FileType] [smallint] NULL,
	[DayOfWeek] [smallint] NULL,
	[WeeklyTime] [datetime] NULL,
	[Status] [int] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLU_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_WlMgmtWatchlistsUpdateSchedule] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)  
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.WlMgmtWatchlistsUpdateRealtime
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistsUpdateRealtime](
	[Id] [int] IDENTITY(2,2) NOT NULL,	
	[CurrentUserId] [int] NULL,
	[Files] [nvarchar](max) NULL,
	[FileType] [smallint] NULL,
	[Status] [int] NOT NULL,
	[IsNew] [bit] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](100) NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLUR_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_WlMgmtWatchlistsUpdateRealtime] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)  
GO

ALTER TABLE [dbo].[WlMgmtWatchlistsUpdateRealtime] ADD  CONSTRAINT [DF_WlMgmtWatchlistsUpdateRealtime_IsNew]  DEFAULT ((0)) FOR [IsNew]
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.WlMgmtWatchlistAutoScaleQueue
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistAutoScaleQueue](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[SearchCoreId] [int] NOT NULL,
	[SearchCoreInstanceName] [varchar](50) NULL,	
	[Files] [nvarchar](max) NULL,	
	[Status] [int] NOT NULL,	
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WASQ_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_WlMgmtWatchlistAutoScaleQueue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)  
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.CwlAutoScaleQueue
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[CwlAutoScaleQueue](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[SearchCoreId] [int] NOT NULL,
	[SearchCoreInstanceName] [varchar](50) NULL,	
	[Files] [nvarchar](max) NULL,	
	[Status] [int] NOT NULL,	
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_CSL_ASQ_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_CwlAutoScaleQueue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)  
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.WlMgmtWatchlistsDeploymentQueue
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistsDeploymentQueue](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[UpdateId] [int] NOT NULL,
	[FolderPath] [varchar](260) NOT NULL,
	[IsScheduledUpdate] [bit] NOT NULL,
	[FileType] [smallint] NOT NULL,
	[DeploymentStatus] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLDQ_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_WlMgmtWatchlistsDeploymentQueue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.WlMgmtSearchcoreDeploymentLocations
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtSearchcoreDeploymentLocations](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[InstanceName] [varchar](50) NOT NULL,
	[FolderPath] [varchar](260) NOT NULL,
	[ApiUrl] [varchar](1000) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[Status] INT NOT NULL CONSTRAINT "DF_WlMgmtSearchcoreDeploymentLocations_Status" default 2,
	[Type] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLDL_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_WlMgmtSearchcoreDeploymentLocations] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.BatchMgmtSystemPgpKeys
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[BatchMgmtSystemPgpKeys](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Value] [ntext] NULL,
	[Passphrase] [nvarchar](100) NULL,
	[CreatedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_dbo.BatchMgmtSystemPgpKeys] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 


CREATE TABLE [dbo].[BatchMgmtServer](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Status] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NOT NULL,
	[DropLocation] [nvarchar](255) NOT NULL,
	[OutputFilesLocation] [nvarchar](255) NOT NULL,
	[ServerType] [int] NOT NULL,
	[EnvironmentType] [int] NOT NULL,
	[DirectUrl] [nvarchar](255) NULL,
 CONSTRAINT [PK_dbo.BatchMgmtServer] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 

CREATE TABLE [dbo].[SystemServer](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Status] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NOT NULL,
	[ServerType] [int] NOT NULL,
	[EnvironmentType] [int] NOT NULL,
	[DirectUrl] [nvarchar](255) NULL,
	[SubType] nvarchar(255) NOT NULL CONSTRAINT "SS_SubType" DEFAULT '',
 CONSTRAINT [PK_dbo.SystemServer] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.BatchMgmtService
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[BatchMgmtService](
	[Id] [int] NOT NULL,
	[StartSuspended] [bit] NOT NULL,
	[CurrentEnvironment] [int] NULL,
 CONSTRAINT [PK_dbo.BatchService] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.BatchMgmtServiceBatchRun
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[BatchMgmtServiceBatchRun](
	[CustomerId] [int] NOT NULL,
	[BatchRunId] [bigint] NOT NULL,
	[Suspend] [bit] NOT NULL,
	[Abort] [bit] NOT NULL,
 CONSTRAINT [PK_dbo.BatchServiceBatchRun] PRIMARY KEY CLUSTERED
(
	[BatchRunId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.BatchMgmtServiceCustomer
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[BatchMgmtServiceCustomer](
	[CustomerId] [int] NOT NULL,
	[SuspendJobStart] [bit] NOT NULL,
	[SuspendJobProcessing] [bit] NOT NULL,
	[SuspendOutputFiles] [bit] NOT NULL,
 CONSTRAINT [PK_BatchServiceCustomer] PRIMARY KEY CLUSTERED
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UtilityMantenanceAudit
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UtilityMantenanceAudit] (
  [Id] BIGINT NOT NULL  IDENTITY(2,2),
  [last_ran_datetime] [datetime] NULL DEFAULT(GetDate()),
  [server_name] VARCHAR(1000) NULL,
  [elapse_processing_time] VARCHAR(1000) NULL,
  [sproc_name] VARCHAR(1000) NULL,
  [records_processed] BIGINT NULL,
  CONSTRAINT [PK_UtilityMantenanceAudit] PRIMARY KEY CLUSTERED
(
	Id ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UtilityNotificationService
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UtilityNotificationService] (
  [Id] BIGINT NOT NULL IDENTITY(2,2),
  [recipient_emails] VARCHAR(1000) NULL,
  [messagehash] VARCHAR(32) NULL,
  [message] VARCHAR(5000) NULL,
  [attempt_count] INT NULL DEFAULT(1),
  [created_date] [datetime] NULL DEFAULT(GetDate()),
  [last_attempt_date] DATETIME NULL,
  [success_date] DATETIME NULL DEFAULT NULL,
  [processing_span_mins] INT NULL DEFAULT(15),
  [from_email] VARCHAR(100) NULL,
  [subject] VARCHAR(1000) NULL,
  CONSTRAINT [PK_UtilityNotificationService] PRIMARY KEY CLUSTERED
(
	Id ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_UtilityNotificationService_success_date] ON [dbo].[UtilityNotificationService]
(
    [success_date] ASC	
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtCustomerInputTransform
-- ----------------------------------------------------------------------------
CREATE TABLE UserMgmtCustomerInputTransform
(
  [Id] INT NOT NULL IDENTITY(2, 2),
  [CustomerId] INT NOT NULL,
  [CustomerName] NVARCHAR(50) NOT NULL,
  [Origin] INT NOT NULL,
  [IsActive] BIT NOT NULL DEFAULT 0,
  [IsDeleted] BIT NOT NULL DEFAULT 0,
  [Description] NVARCHAR(255) NULL,
  [InputTransformXML] [NTEXT] NULL,
  [DataSourceName] NVARCHAR(100) NULL,
  [OrderIndex] INT NOT NULL,
  CONSTRAINT [PK_UserMgmtCustomerInputTransform] PRIMARY KEY CLUSTERED
(
	Id ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
);


 CREATE TABLE [dbo].[_Conversion_Important_Objects] (
  [Id] INT NOT NULL IDENTITY(2,2),
  [module] VARCHAR(500) NOT NULL,
  [Type] VARCHAR(500) NOT NULL,
  [Id_4X] TEXT NOT NULL,
  [Id_50] bigint NOT NULL,
  [date_created] DATETIME NOT NULL,
  CONSTRAINT [PK_Conversion_Important_Objects] PRIMARY KEY CLUSTERED
(
	Id ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
  
-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon._Conversion_ResultSets_Converted
-- ----------------------------------------------------------------------------             
  CREATE TABLE [dbo].[_Conversion_ResultSets_Converted] (
  [Id] INT NOT NULL IDENTITY(2,2),
  [module] VARCHAR(500) NOT NULL,
  [Type] VARCHAR(500) NOT NULL,
  [Id_4X] bigint NOT NULL,
  [Id_50] bigint NOT NULL,
  [date_created] DATETIME NOT NULL,
  [done] bit NOT NULL CONSTRAINT "DF_Conversion_DoneFlag" DEFAULT 0,  
   CONSTRAINT [PK_Conversion_ResultSets_Converted] PRIMARY KEY CLUSTERED
(
	Id ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

SET ANSI_PADDING OFF
GO
CREATE TABLE [dbo].[UserMgmtEnterpriseAudit] (
  [Id] INT NOT NULL IDENTITY(2,2),
  [ActorCustomerId] INT NOT NULL CONSTRAINT "DF_Enterprise_Audit_CustomerId"  DEFAULT 0,
  [ActorCustomerLoginName] VARCHAR(50) NULL,
  [ActorUserId] INT NOT NULL,
  [ActorUserLoginName] VARCHAR(50) NOT NULL CONSTRAINT "DF_Enterprise_Audit_ActorUserLoginName" DEFAULT '',
  [DateCreated] DATETIME NOT NULL  CONSTRAINT "DF_Enterprise_Audit_DateCreated" default (getutcdate()),
  [Action] INT NOT NULL  CONSTRAINT "DF_Enterprise_Audit_Action" DEFAULT 0,
  [ActionItemId] INT NOT NULL CONSTRAINT "DF_Enterprise_Audit_ActionItemId" DEFAULT 0,
  [ActionData] VARCHAR(MAX) NULL)

 
  CREATE NONCLUSTERED INDEX IX_UserMgmtEnterpriseAudit_CustomerId_UserId ON dbo.UserMgmtEnterpriseAudit
(
    [ActorCustomerId], [ActorUserId]
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 

  GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtCustomerFTPInfo
-- ----------------------------------------------------------------------------

CREATE TABLE [dbo].[UserMgmtCustomerFTPInfo](
	[Id] INT NOT NULL IDENTITY(2,2),
	[Username] [nvarchar](50) NOT NULL,
	[Password] [nvarchar](50) NOT NULL,
	[PasswordInactivityLockDays] [int] NULL,
	[UpdateRequired] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomerFTPInfo_UpdateRequired" DEFAULT 1,
	[IsInputAccount] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomerFTPInfo_IsInputAccount" DEFAULT 0,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomerFTPInfo_IsDeleted" DEFAULT 0,
	[DateCreated] [datetime] NOT NULL CONSTRAINT "DF_UserMgmtCustomerFTPInfo_DateCreated" DEFAULT CURRENT_TIMESTAMP,
	[DateModified] [datetime] NULL,
	[ModifiedBy] [int] NULL,
	[CreatedBy] [int] NOT NULL,
	[CustomerId] [int] NOT NULL,
 CONSTRAINT [PK_UserMgmtCustomerFTPInfo] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtCustomerFTPInfo_CustomerId] ON [dbo].[UserMgmtCustomerFTPInfo]
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtCustomerFTPInfo_UpdateRequired] ON [dbo].[UserMgmtCustomerFTPInfo]
(
	[UpdateRequired] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtFprModel
-- ----------------------------------------------------------------------------

CREATE TABLE [dbo].UserMgmtFprModel(
	[Id] INT NOT NULL IDENTITY(2,2),
	[UniqueId] [BINARY](16) NOT NULL,
    [DateCreated] [datetime] NOT NULL CONSTRAINT "DF_UserMgmtFprModel_DateCreated" DEFAULT CURRENT_TIMESTAMP,
	[DateModified] [datetime] NULL,
	[CreatedBy] [nvarchar](50) NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[Name] [nvarchar](255) NOT NULL,
	IsActive [bit] NOT NULL CONSTRAINT "DF_UserMgmtFprModel_IsActive" DEFAULT 0,
	AllCustomers [bit] NOT NULL CONSTRAINT "DF_UserMgmtFprModel_AllCustomers" DEFAULT 0,
	Model [varbinary](max) NULL,
	IsLatest [bit] NOT NULL CONSTRAINT "DF_UserMgmtFprModel_IsLatest" DEFAULT 1,
	[VersionInt] INT NOT NULL CONSTRAINT "DF_UserMgmtFprModel_VersionInt" DEFAULT 1,
 CONSTRAINT [PK_UserMgmtFprModel] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


  -- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.UserMgmtFprModelCustomer
-- ----------------------------------------------------------------------------  

CREATE TABLE [dbo].UserMgmtFprModelCustomer (
  [UniqueId] [BINARY](16)  NOT NULL ,
  [FprModelId] INT NOT NULL,
  [CustomerId] [int] NOT NULL,
  PRIMARY KEY (FprModelId, CustomerId));
  GO
  
  -- ----------------------------------------------------------------------------
-- Table BridgerRFCommon.CwlCustomWatchlistsInfo
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[CwlCustomWatchlistsInfo](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[UniqueId] [BINARY](16) NOT NULL,
	[CustomerId] INT NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Type] [int] NOT NULL,
	[LastBuilt] [datetime] NOT NULL,
 CONSTRAINT [pk_CwlCustomWatchlistsInfo] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
GO

CREATE NONCLUSTERED INDEX IX_CwlCustomWatchlistsInfo_UniqueId ON dbo.CwlCustomWatchlistsInfo
(
    [UniqueId]
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

CREATE NONCLUSTERED INDEX IX_CwlCustomWatchlistsInfo_Type ON dbo.CwlCustomWatchlistsInfo
(
    [Type]
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO