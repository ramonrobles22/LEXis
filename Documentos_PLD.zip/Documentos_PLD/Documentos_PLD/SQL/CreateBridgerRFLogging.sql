

-- SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- Schema BridgerRFLogging
-- ----------------------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFLogging.logconfig
-- ----------------------------------------------------------------------------
CREATE TABLE logconfig (
  Id 								BIGINT					NOT NULL IDENTITY(1,1) PRIMARY KEY,
  MachineName 						NVARCHAR(32) 			NULL,
  ProcessName 						NVARCHAR(512) 			NULL,
  IsEnabled 						BIT 					NOT NULL CONSTRAINT "DF_LogConfig_IsEnabled" DEFAULT 1,
  EnabledCategories 				NVARCHAR(1500) 			NULL,
  EnabledColumns 					NVARCHAR(255) 			NULL
);

-- ----------------------------------------------------------------------------
-- Table BridgerRFLogging.logtable
-- ----------------------------------------------------------------------------
CREATE TABLE logtable (
  Id 								BIGINT 					NOT NULL IDENTITY(1,1) PRIMARY KEY,
  EventID 							INT 					NULL,
  Priority 							INT 					NULL,
  Severity 							NVARCHAR(32) 			NULL,
  JobId 							NVARCHAR(30) 			NULL,
  JobPartId							NVARCHAR(30) 			NULL,
  SessionId							NVARCHAR(80) 			NULL,
  RequestId							NVARCHAR(40) 			NULL,
  CustomerId 						INT			 			NULL,
  UserId 							INT			 			NULL,
  IpAddress							NVARCHAR(50) 			NULL,
  Title 							NVARCHAR(256) 			NULL,
  OccurredOn 						DATETIME 				NULL,
  MachineName 						NVARCHAR(32)  			NULL,
  AppDomainName 					NVARCHAR(512)  			NULL,
  ProcessID 						NVARCHAR(256)  			NULL,
  ProcessName 						NVARCHAR(512)  			NULL,
  ThreadName 						NVARCHAR(512)  			NULL,
  Win32ThreadId 					NVARCHAR(128)  			NULL,
  Categories 						NVARCHAR(1500)  		NULL,
  Message 							NVARCHAR(MAX)  			NULL
);
