

-- SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- Schema BridgerRFMisc
-- ----------------------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- ----------------------------------------------------------------------------
-- Table BridgerRFMisc.PasswordBlacklist
-- ----------------------------------------------------------------------------
USE [BridgerRFMisc]
/****** Object:  Table [dbo].[SessionState]    Script Date: 03/01/2016 15:16:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[PasswordBlacklist](
	[Password] [nvarchar](100) NOT NULL
PRIMARY KEY CLUSTERED 
(
	[Password] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


-- ----------------------------------------------------------------------------
-- Table BridgerRFMisc.LoginManagement
-- ----------------------------------------------------------------------------
USE [BridgerRFMisc]
GO

/****** Object:  Table [dbo].[SessionState]    Script Date: 08/17/2016 09:04:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[LoginManagement](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerLoginName] [varchar](50) NULL,
	[UserName] [varchar](50) DEFAULT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[IpAddress] [varchar](50) NULL,
	[MFAAttemptCount] [int] NOT NULL DEFAULT 0,
	[LoginAttemptCount] [int] NOT NULL DEFAULT 0,
	[PasswordResetUsageCount] [int] NOT NULL DEFAULT 0,
	[PasswordResetUsageDate] [datetime] NOT NULL DEFAULT '2000-01-01 00:00:01'
	
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


CREATE TABLE CacheTable
(
	Id                             NVARCHAR(255)            NOT NULL,
	Sequence                       INT                      NOT NULL,
	Created                        DATETIME                 NOT NULL CONSTRAINT "DF_CacheTable_Created" DEFAULT GETDATE(),
	Expires                        DATETIME                 NULL,
	State                          INT                      NOT NULL,
	IsCompressed                   BIT                      NOT NULL,
	Data                           IMAGE                    NOT NULL,
PRIMARY KEY CLUSTERED 
(
	Id ASC,
	Sequence ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
);

CREATE TABLE CacheCounter
(
	Id                             VARCHAR(255)             NOT NULL PRIMARY KEY,
	CounterValue                   BIGINT                   NOT NULL,
	CounterVersion                 VARCHAR(100)             NOT NULL,
);

CREATE TABLE LogConfig (
  Id BIGINT IDENTITY(1,1) NOT NULL,
  MachineName NVARCHAR(32) NULL,
  ProcessName NVARCHAR(512) NULL,
  IsEnabled BIT NOT NULL CONSTRAINT "DF_LogConfig_IsEnabled" DEFAULT 1,
  EnabledCategories NVARCHAR(1500) DEFAULT NULL,
  EnabledColumns NVARCHAR(255) DEFAULT NULL
  PRIMARY KEY CLUSTERED 
  (
  	[Id] ASC
  )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
);

CREATE TABLE LogTable (
  Id BIGINT IDENTITY(1,1) NOT NULL,
  EventID INT NULL,
  Priority INT NULL,
  Severity NVARCHAR(32) NULL,
  JobId NVARCHAR(30) NULL,
  JobPartId NVARCHAR(30) NULL,
  SessionId NVARCHAR(80) NULL,
  RequestId NVARCHAR(40) NULL,
  CustomerId INT NULL,
  UserId INT NULL,
  IpAddress NVARCHAR(50) NULL,
  Title NVARCHAR(256) NULL,
  OccurredOn datetime NULL,
  MachineName NVARCHAR(32) NULL,
  AppDomainName NVARCHAR(512) NULL,
  ProcessID NVARCHAR(256) NULL,
  ProcessName NVARCHAR(512) NULL,
  ThreadName NVARCHAR(512) NULL,
  Win32ThreadId NVARCHAR(128) NULL,
  Categories NVARCHAR(1500) NULL,
  Message Text
  PRIMARY KEY CLUSTERED 
  (
  	[Id] ASC
  )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
);

INSERT INTO logconfig (MachineName, ProcessName, IsEnabled, EnabledCategories, EnabledColumns) VALUES (NULL, NULL, 1, NULL,  'EventID,Severity,SessionId,RequestId,CustomerId,UserId,IpAddress,Title,OccurredOn,MachineName,AppDomainName,ProcessName,Categories,Message');

