-- SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE [BridgerRFOffline]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'BridgerRFOffline', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\\BridgerRFOffline.mdf' , SIZE = 32768KB , MAXSIZE = UNLIMITED, FILEGROWTH = 32768KB )
 LOG ON 
( NAME = N'BridgerRFOffline_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\\BridgerRFOffline_log.LDF' , SIZE = 32768KB , MAXSIZE = 2048GB , FILEGROWTH = 131072KB )
GO
-- ----------------------------------------------------------------------------
-- Schema BridgerRFOffline
-- ----------------------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtLoginHistory
-- ----------------------------------------------------------------------------
use BridgerRFOffline

CREATE TABLE [dbo].[UserMgmtUserAudit](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[UserName] [varchar](50) NOT NULL,
	[UserType] [int] NOT NULL,
	[Event] [int] NOT NULL,
	[IpAddress] [varchar](50)  NULL,
	[UserAgent] [varchar](512) NULL,
	[Status] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
 CONSTRAINT [PK_usermgmtuseraudit] PRIMARY KEY CLUSTERED  
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) 
GO
CREATE NONCLUSTERED INDEX [IX_UserMgmtUserAudit_UserId_UserType] ON [dbo].[UserMgmtUserAudit]
(
    [UserId] ASC,
	[UserType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO


-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtCustomers
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtCustomers](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [CustomerLoginName] [nvarchar](50) NOT NULL,
    [CustomerSettings_IsActive] [bit] NOT NULL,
    [CustomerSettings_IsFreeTrial] [bit] NOT NULL,
    [CustomerSettings_DateFreeTrialAccepted] [datetime] NULL,
    [CustomerSettings_DateFreeTrialExpires] [datetime] NULL,
    [CustomerSettings_EulaAcceptedBy] [nvarchar](50) NULL,
    [CustomerSettings_DateEulaAccepted] [datetime] NULL,
    [CustomerSettings_DatabaseIdentifier] [nvarchar](50) NOT NULL,
    [CustomerSettings_WebAppIdentifier] [nvarchar](50) NOT NULL,
    [CustomerSettings_DefaultCulture] [nvarchar](50) NOT NULL,
    [CustomerSettings_AllowableIPRanges] [nvarchar](max) NULL,
    [CustomerSettings_WebServicesType] [int] NOT NULL,
    [CustomerSettings_EnabledProviders] [nvarchar](200) NULL,
    [CustomerSettings_ProviderCredentials] [nvarchar](max) NULL,
    [CustomerSettings_SecurityMessage] [nvarchar](255) NULL,
	[CustomerSettings_BillingType] [int] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_CustomerSettings_BillingType" default(0),
	[CustomerSettings_DateFormat] [int] NULL CONSTRAINT "DF_UserMgmtCustomers_CustomerSettings_DateFormat" default(0),
    [ExcludedAcceptlists] [nvarchar](max) NULL,
    [ExcludedCustomWatchlists] [nvarchar](max) NULL,
    [IncludedAcceptlists] [nvarchar](max) NULL,
    [IncludedCustomWatchlists] [nvarchar](max) NULL,
    [SecurityPolicy_PolicyChangedBy] [nvarchar](50) NULL,
    [SecurityPolicy_DatePolicy] [datetime] NULL,
    [SecurityPolicy_MinPasswordLength] [int] NOT NULL,
    [SecurityPolicy_PasswordExpiresDays] [int] NOT NULL,
    [SecurityPolicy_IdleTimeout] [int] NOT NULL,
    [SecurityPolicy_InactiveAccountLockedDays] [int] NOT NULL,
    [SecurityPolicy_MaxInvalidLoginAttempts] [int] NOT NULL,
	[SecurityPolicy_MFAOption] int NOT NULL DEFAULT 0,
    [SecurityPolicy_MFACodeLength] int NOT NULL DEFAULT 4, 	
    [AccountInfo_CustomerFullName] [nvarchar](255) NULL,
	[AccountInfo_TypeOfInstitution] [nvarchar](255) NULL,
    [AccountInfo_Identifier] [nvarchar](255) NULL,
    [AccountInfo_IsInternalAccount] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_AccountInfo_IsInternalAccount" default(0),
    [AccountInfo_UseSystemProductCode] [bit] NOT NULL,
    [AccountInfo_ProductCode] [nvarchar](50) NULL,
    [AccountInfo_ProductVersion] [nvarchar](50) NULL,
    [AccountInfo_AccountType] [nvarchar](50) NULL,
    [AccountInfo_Description] [nvarchar](255) NULL,
    [AccountInfo_Address1] [nvarchar](255) NULL,
    [AccountInfo_Address2] [nvarchar](255) NULL,
    [AccountInfo_City] [nvarchar](120) NULL,
    [AccountInfo_State] [nvarchar](50) NULL,
    [AccountInfo_PostalCode] [nvarchar](20) NULL,
    [AccountInfo_Country] [nvarchar](100) NULL,
    [AccountInfo_Contact] [nvarchar](255) NULL,
    [AccountInfo_Phone] [nvarchar](20) NULL,
    [AccountInfo_PhoneExtension] [nvarchar](10) NULL,
    [AccountInfo_Fax] [nvarchar](20) NULL,
    [AccountInfo_EmailAddress] [nvarchar](320) NULL,
    [Privileges_CanAutomaticBatch] [bit] NOT NULL,
    [Privileges_CanAutomaticBatchOutputFiles] [bit] NOT NULL,
    [Privileges_CanHaveAttachments] [bit] NOT NULL,
    [Privileges_MaxAttachmentSize] [int] NOT NULL,
    [Privileges_CanSaveAllResults] [bit] NOT NULL,
    [Privileges_OnlyReturnResults] [bit] NOT NULL,
	[Privileges_MFACustomerActive] [BIT] NOT NULL DEFAULT 1,
	Privileges_WatchListSelections IMAGE NULL,
   -- TODO: remove Privileges_WatchListSelections above in time
    Privileges_ExcludedWatchlists IMAGE NULL,	
    [FtpSettings_Password] [nvarchar](150) NULL,
    [FtpSettings_OutputFilesPassword] [nvarchar](150) NULL,
    [DuplicateMatchSettings_SuppressDuplicatesForBatch] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_SuppressDuplicatesForBatch" default(0),
    [DuplicateMatchSettings_SameDivisionOnly] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_SameDivisionOnly" default(0),
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtCustomers_IsDeleted" default(0),
	[UpdateHistoricClientUsageData] [bit] NOT NULL DEFAULT 0,
	[MaxOriginalResultId] [bigint] NULL,
	[AmlEnvironmentType] TINYINT NOT NULL CONSTRAINT "DF_Aml_EnvironmentType" DEFAULT 0,
 CONSTRAINT [PK_dbo.UserMgmtCustomers] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtAuditRecords
-- ----------------------------------------------------------------------------
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserMgmtAuditRecords](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [Action] [int] NOT NULL,
    [ActorName] [nvarchar](255) NULL,
    [Date] [datetime] NOT NULL,
    [ActionItemType] [int] NOT NULL,
    [ActionItemId] [int] NOT NULL,
    [ActionItemName] [nvarchar](255) NULL,
    [ActionItemParentId] [int] NULL,
    [ActionItemParentName] [nvarchar](255) NULL,
 CONSTRAINT [PK_dbo.UserMgmtAuditRecords] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtSystemSettings
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSystemSettings](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] datetime NOT NULL CONSTRAINT DF_UserMgmtSystemSettings_DateCreated default (getutcdate()),
	[DateModified] [datetime] NOT NULL CONSTRAINT DF_UserMgmtSystemSettings_DateModified default (getutcdate()),
	[CreatedBy] nvarchar(50) NULL,
	[ModifiedBy] nvarchar(50) NULL,
    [SystemName] [nvarchar](256) NULL,
    [ProductCode] [nvarchar](24) NULL,
    [IsSystemWideProductCode] [bit] NOT NULL,
    [AuthenticationType] [int] NOT NULL,
    [DefaultFreeTrialDays] [int] NOT NULL,
    [DefaultMaxBatchSize] [int] NOT NULL,
    [SMTPPrimaryServer] [nvarchar](256) NULL,
    [SMTPPrimaryPort] [int] NULL,
    [SMTPPrimaryUserName] [nvarchar](256) NULL,
    [SMTPPrimaryPassword] [nvarchar](256) NULL,
    [SMTPSecondaryServer] [nvarchar](256) NULL,
    [SMTPSecondaryPort] [int] NULL,
    [SMTPSecondaryUserName] [nvarchar](256) NULL,
    [SMTPSecondaryPassword] [nvarchar](256) NULL,    
    [SMTPReturnAddress] [nvarchar](256) NULL,
    [BatchFileSystemType] [int] NOT NULL CONSTRAINT DF_UserMgmtSystemSettings_BatchFileSystemType default (1),
    [FTPPrimaryHostName] [nvarchar](256) NULL,
    [FTPPrimaryPort] [int] NULL,
    [FTPPrimaryLogonType] [int] NULL,
    [FTPPrimaryUserName] [nvarchar](256) NULL,
    [FTPPrimaryPassword] [nvarchar](256) NULL,
    [FTPPrimaryKey] [text] NULL,
    [FTPPrimaryKeyPassCode] [nvarchar](50) NULL,
    [FTPPrimaryTimeoutInSeconds] [int] NULL,
    [FTPPrimaryAutomaticBatchDirectory] [nvarchar](256) NULL,
    [FTPPrimaryGuiBatchDirectory] [nvarchar](256) NULL,
    [FTPPrimaryStartDirectory] [nvarchar](256) NULL,
    [FTPPrimaryOutputFilesDirectory] [nvarchar](256) NULL,
    [NetworkShareAutomaticBatchDirectory] [nvarchar](256) NULL,
    [NetworkShareGuiBatchDirectory] [nvarchar](256) NULL,
    [NetworkShareStartDirectory] [nvarchar](256) NULL,
    [NetworkShareOutputFilesDirectory] [nvarchar](256) NULL,
	[ImportService] [bit] NOT NULL,
    [AMLSolutionsID] [nvarchar](64) NULL,
    [AMLUserID] [nvarchar](256) NULL,
    [AMLPassword] [nvarchar](256) NULL,
    [ProxySettings_Address] [nvarchar](256) NULL,
    [ProxySettings_UserId] [nvarchar](256) NULL,
    [ProxySettings_Password] [nvarchar](256) NULL,
    [ProxySettings_Port] [int] NOT NULL,	
    IsEnterprise BIT NOT NULL CONSTRAINT "DF_UM_Sys_IsEnterprise" DEFAULT 0,
    IsDecryptionEnabled BIT NOT NULL CONSTRAINT "DF_UM_Sys_IsDecryptionEnabled" DEFAULT 0,
    EnableNTLM BIT NOT NULL CONSTRAINT "DF_UM_Sys_EnableNTLM" DEFAULT 0,
    [LDAPServerPath] [nvarchar](255) NULL,
    [IsImportLoginValid] BIT NOT NULL CONSTRAINT "DF_IsImportLoginValid" DEFAULT 0,
    [AllowableIPRanges] [nvarchar](max) NULL,
	[MFASystemActive] [bit] NOT NULL CONSTRAINT "DF_Sett_MFASystemActive" DEFAULT 1,
 CONSTRAINT [PK_dbo.UserMgmtSystemSettings] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtSystemRoles
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSystemRoles](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [Name] [nvarchar](100) NOT NULL,
    [Description] [nvarchar](255) NULL,
    [Privileges] [nvarchar](255) NULL,
 CONSTRAINT [PK_dbo.UserMgmtSystemRoles] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtProductCodeEntitlements
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtProductCodeEntitlements](
    [ProductCode] [nvarchar](19) NOT NULL,
    [EntitlementBitfield] [varbinary](2048) NULL,
    [MbsId] [int] NOT NULL CONSTRAINT "DF_UM_PC_MbsId" DEFAULT 0,
    [MbsDescription] [nvarchar](500) NULL,
 CONSTRAINT [PK_dbo.UserMgmtProductCodeEntitlements] PRIMARY KEY CLUSTERED
(
    [ProductCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtWatchlistData
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtWatchlistData](
    [FileId] [BINARY](16) NOT NULL,
    [Name] [nvarchar](255) NULL,
    [BitfieldPosition] [int] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtWatchlistData] PRIMARY KEY CLUSTERED
(
    [FileId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtSystemUsers
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSystemUsers](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [InternalId] [int] NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
	[MFAVerified] [nvarchar](20) NULL,
    [LoginName] [nvarchar](50) NULL,
    [Password] [nvarchar](100) NULL,
    [FullName] [nvarchar](255) NULL,
    [EmployeeId] [nvarchar](100) NULL,
    [EmailAddress] [nvarchar](320) NULL,
    [LoginFailedAttempts] [int] NOT NULL,
    [IsLocked] [bit] NOT NULL,	
    [IsPasswordChangeRequired] [bit] NOT NULL,
    [PasswordResetKey] [nvarchar](36) NULL,
    [PasswordResetKeyExpiration] [datetime] NULL,
    [PasswordModified] [datetime] NULL,
    [Role_Id] [int] NOT NULL,
	[IPSettingsShowAll] [bit] NOT NULL CONSTRAINT "DF_Ums_IPSettingsShowAll" default(0),
	[ScreeningListShowAll] [bit] NOT NULL CONSTRAINT "DF_Ums_ScreeningListShowAll" default(0)
	
 CONSTRAINT [PK_dbo.UserMgmtSystemUsers] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Role_Id] ON [dbo].[UserMgmtSystemUsers]
(
    [Role_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtRoles
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtRoles](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [Name] [nvarchar](100) NOT NULL,
    [Description] [nvarchar](255) NOT NULL,
    [EmailOnAlertsAssignment] [bit] NOT NULL,
    [CanRemove] [bit] NOT NULL,
    [Privileges] [nvarchar](255) NULL,
    [Customer_Id] [int] NOT NULL,
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtRoles_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.UserMgmtRoles] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Customer_Id] ON [dbo].[UserMgmtRoles]
(
    [Customer_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtDivisions
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtDivisions](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [Name] [nvarchar](100) NOT NULL,
    [Description] [nvarchar](255) NOT NULL,
    [CanRemove] [bit] NOT NULL,
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtDivisions_IsDeleted" default(0),
    [Customer_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtDivisions] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Customer_Id] ON [dbo].[UserMgmtDivisions]
(
    [Customer_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtPreviousSystemUserPasswords
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtPreviousSystemUserPasswords](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [Password] [nvarchar](100) NULL,
    [DateCreated] [datetime] NOT NULL,
    [SystemUser_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtPreviousSystemUserPasswords] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_SystemUser_Id] ON [dbo].[UserMgmtPreviousSystemUserPasswords]
(
    [SystemUser_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtUsers
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtUsers](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [DateCreated] [datetime] NOT NULL,
    [CreatedBy] [nvarchar](50) NULL,
    [DateModified] [datetime] NOT NULL,
    [ModifiedBy] [nvarchar](50) NULL,
    [CanRemove] [bit] NOT NULL,
    [LoginName] [nvarchar](50) NOT NULL,
	[MFAVerified] [nvarchar](20) NULL,
    [Password] [nvarchar](100) NULL,
    [CallOutPermissions] [nvarchar](50) NULL default 'alert,realtime',
	[InternalId] [nvarchar](20) NULL,
    [IsActive] [bit] NOT NULL,
    [IsLocked] [bit] NOT NULL,
    [IsShortcutEnabled] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUsers_IsShortcutEnabled" default(0),
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUsers_IsDeleted" default(0),
    [IsPasswordChangeRequired] [bit] NOT NULL,
    [IsChallengeRequired] [bit] NOT NULL CONSTRAINT "DF__UserMgmtUsers__IsChallengeRequired" default(0),
    [ChallengeSetupRequired] [bit] NOT NULL CONSTRAINT "DF__UserMgmtUsers__ChallengeSetupRequired" default(0),
    [PasswordModified] [datetime] NULL,
    [PasswordResetKey] [nvarchar](36) NULL,
    [PasswordResetKeyExpiration] [datetime] NULL,
    [LoginFailedAttempts] [int] NOT NULL,
    [PreviousLogin] [datetime] NULL,
    [LastLogin] [datetime] NULL,
    [DateCookieDisclaimerAccepted] [datetime] NULL,
    [DateEulaAccepted] [datetime] NULL,
    [Role_Id] [int] NOT NULL,
    [Customer_Id] [int] NOT NULL,	
	[MFACode] varchar(20) DEFAULT NULL,
	[MFACodeDate] datetime DEFAULT NULL,
	[MFARequired] [bit] NOT NULL DEFAULT 0,
	[MFAFullyAuthenticated] [bit] NOT NULL DEFAULT 0,	
	[IsTestUser] bit NOT NULL CONSTRAINT "DF_UM_IsTestUser" DEFAULT 0,
	[IsConvertedUser] bit NOT NULL CONSTRAINT "DF_UM_IsConvertedUser" DEFAULT 0,
	[Version] [int] NULL,
	[LastEmailedTime] datetime NULL,
 CONSTRAINT [PK_dbo.UserMgmtUsers] PRIMARY KEY CLUSTERED
(
    [Id] ASC
), 
CONSTRAINT [UIX_CustomerID_LoginName] UNIQUE NONCLUSTERED
(
	[LoginName], [Customer_Id], [IsDeleted], [Version]
)
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Customer_Id] ON [dbo].[UserMgmtUsers]
(
    [Customer_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_Role_Id] ON [dbo].[UserMgmtUsers]
(
    [Role_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_User_LoginName] ON [dbo].[UserMgmtUsers]
(
	[LoginName] ASC
)
INCLUDE ( [IsActive], [IsDeleted]) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtUserProfiles
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtUserProfiles](
    [Id] [int] NOT NULL,
    [DateCreated] datetime not null constraint DF_UserMgmtUserProfiles_DateCreated default (getutcdate()),
	[DateModified] [datetime] not null constraint DF_UserMgmtUserProfiles_DateModified default (getutcdate()),
	[CreatedBy] nvarchar(50) null,
	[ModifiedBy] nvarchar(50) null,
    [FullName] [nvarchar](255) NOT NULL,
    [EmailAddress] [nvarchar](320) NOT NULL,
    [Domain] [nvarchar](256) NULL,
    [Homepage] [nvarchar](2048) NULL,
    [NotifyOnAlertAssignment] [bit] NOT NULL,
    [AllDivisions] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_AllDivisions" DEFAULT 0,
    [AMLLoginName] [nvarchar](50) NULL,
    [WebServiceOnly] [bit] NOT NULL,
	[UploadFileDivision] [int] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileDivision" DEFAULT 0,
	[UploadFileDistribution] [int] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileDistribution" DEFAULT 0,
	[UploadFileAllCompletedScans] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileAllCompletedScans" DEFAULT 0,
	[UploadFileScansWithAlerts] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileScansWithAlerts" DEFAULT 1,
	[UploadFileTransactionDetails] [bit] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_UploadFileTransactionDetails" DEFAULT 0,
	[DefaultPageSize] [int] NOT NULL CONSTRAINT "DF_UserMgmtUserProfiles_DefaultPageSize" DEFAULT 25,
 CONSTRAINT [PK_dbo.UserMgmtUserProfiles] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Id] ON [dbo].[UserMgmtUserProfiles]
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtSecurityQuestions
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtSecurityQuestions](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [Question] [BINARY](16) NOT NULL,
    [Answer] [nvarchar](255) NULL,
    [User_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtSecurityQuestions] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_User_Id] ON [dbo].[UserMgmtSecurityQuestions]
(
    [User_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtPreviousUserPasswords
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtPreviousUserPasswords](
    [Id] [int] IDENTITY(2,2) NOT NULL,
    [Password] [nvarchar](100) NULL,
    [DateCreated] [datetime] NOT NULL,
    [User_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtPreviousUserPasswords] PRIMARY KEY CLUSTERED
(
    [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_User_Id] ON [dbo].[UserMgmtPreviousUserPasswords]
(
    [User_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.UserMgmtDivisionUsers
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[UserMgmtDivisionUsers](
    [Division_Id] [int] NOT NULL,
    [User_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.UserMgmtDivisionUsers] PRIMARY KEY CLUSTERED
(
    [Division_Id] ASC,
    [User_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_Division_Id] ON [dbo].[UserMgmtDivisionUsers]
(
    [Division_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE NONCLUSTERED INDEX [IX_User_Id] ON [dbo].[UserMgmtDivisionUsers]
(
    [User_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO



-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.WlMgmtWatchlistsInfo
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistsInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[FileId] [BINARY](16) NOT NULL,
	[ParentFileId] [BINARY](16) NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Description] [nvarchar](1024) NULL,
	[HashFull] [varchar](32) NOT NULL,
	[HashPartial] [varchar](32) NOT NULL,
	[BridgerDataFileType] [int] NULL,
	[BridgerBdfDataFileType] [nvarchar](19) NULL,
	[IsPep] [bit] NULL,
	[IsSpecial] [bit] NULL,
	[Is32Bit] [bit] NULL,
	[IsCompressed] [bit] NOT NULL CONSTRAINT DF_Wlmgmtwatchlistsinfo_IsCompressed default(0),
	[HasWeakAka] [bit] NOT NULL,
	[HasSearchCriteria] [bit] NOT NULL,
	[FileSize] [bigint] NOT NULL,
	[Version] [varchar](255) NOT NULL,
	[DatePublished] [datetime] NULL,
	[DateFileBuild] [datetime] NOT NULL,
	[DateUpdated] [datetime] NULL,
	[DateAdded] [datetime] NOT NULL,
	[DateLastAccessed] [datetime] NULL,
	[Flag] [int] NOT NULL,
	[Available] [bit] NOT NULL CONSTRAINT DF_WlMgmtWatchlistsInfo_Available default(0),
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLInfo_EnvironmentType" DEFAULT(0),
 CONSTRAINT [pk_WlMgmtWatchlistsInfo] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
GO
CREATE NONCLUSTERED INDEX [IX_WlMgmtWatchlistsInfo_DateFileBuild] ON [dbo].[WlMgmtWatchlistsInfo] 
(
	[DateFileBuild] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) 
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_WlMgmtWatchlistsInfo_FileId ON dbo.WlMgmtWatchlistsInfo
(
    [FileId], [Version]
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
GO

ALTER TABLE [dbo].[WlMgmtWatchlistsInfo] ADD  CONSTRAINT [DF_WlMgmtWatchlistsInfo_HasWeakAka]  DEFAULT ((1)) FOR [HasWeakAka]
GO

ALTER TABLE [dbo].[WlMgmtWatchlistsInfo] ADD  CONSTRAINT [DF_WlMgmtWatchlistsInfo_HasSearchCriteria]  DEFAULT ((1)) FOR [HasSearchCriteria]
GO

ALTER TABLE [dbo].[WlMgmtWatchlistsInfo] ADD  CONSTRAINT [DF_WlMgmtWatchlistsInfo_Version]  DEFAULT ('1.0.0') FOR [Version]
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.WlMgmtWatchlistsUpdateSchedule
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistsUpdateSchedule](
	[Id] [int] IDENTITY(2,2) NOT NULL,	
	[UpdateServerUrl] [nvarchar](512) NULL,
	[Files] [nvarchar](max) NULL,
	[ScheduleType] [smallint] NOT NULL,
	[Interval] [int] NOT NULL,
	[DailyUpdateTime] [datetime] NULL,
	[LastUpdateTime] [datetime] NULL,
	[NextUpdateTime] [datetime] NULL,
	[EmailAddresses] [ntext] NULL,
	[CurrentUserId] [int] NULL,
	[FileType] [smallint] NULL,
	[DayOfWeek] [smallint] NULL,
	[WeeklyTime] [datetime] NULL,
	[Status] [int] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLU_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_WlMgmtWatchlistsUpdateSchedule] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)  
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.WlMgmtWatchlistsUpdateRealtime
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistsUpdateRealtime](
	[Id] [int] IDENTITY(2,2) NOT NULL,	
	[CurrentUserId] [int] NULL,
	[Files] [nvarchar](max) NULL,
	[FileType] [smallint] NULL,
	[Status] [int] NOT NULL,
	[IsNew] [bit] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](100) NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLUR_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_WlMgmtWatchlistsUpdateRealtime] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)  
GO

ALTER TABLE [dbo].[WlMgmtWatchlistsUpdateRealtime] ADD  CONSTRAINT [DF_WlMgmtWatchlistsUpdateRealtime_IsNew]  DEFAULT ((0)) FOR [IsNew]
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.WlMgmtWatchlistsDeploymentQueue
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtWatchlistsDeploymentQueue](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[UpdateId] [int] NOT NULL,
	[FolderPath] [varchar](260) NOT NULL,
	[IsScheduledUpdate] [bit] NOT NULL,
	[FileType] [smallint] NOT NULL,
	[DeploymentStatus] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLDQ_EnvironmentType" DEFAULT(0),
 CONSTRAINT [PK_WlMgmtWatchlistsDeploymentQueue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.WlMgmtSearchcoreDeploymentLocations
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[WlMgmtSearchcoreDeploymentLocations](
	[Id] [int] NOT NULL,
	[InstanceName] [varchar](50) NOT NULL,
	[FolderPath] [varchar](260) NOT NULL,
	[ApiUrl] [varchar](1000) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[Type] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_WLM_WLDL_EnvironmentType" DEFAULT(0)
) 

GO

-- ----------------------------------------------------------------------------
-- Table BridgerRFOffline.usermgmtcustomerinputtransform
-- ----------------------------------------------------------------------------
CREATE TABLE usermgmtcustomerinputtransform
(
  [Id] INT NOT NULL IDENTITY(2, 2),
  [CustomerId] INT NOT NULL,
  [CustomerName] NVARCHAR(50) NOT NULL,
  [Origin] INT NOT NULL,
  [IsActive] BIT NOT NULL DEFAULT 0,
  [IsDeleted] BIT NOT NULL DEFAULT 0,
  [Description] NVARCHAR(255) NULL,
  [InputTransformXML] [NTEXT] NULL,
  [DataSourceName] NVARCHAR(100) NULL,
  [OrderIndex] INT NOT NULL,
  CONSTRAINT [PK_usermgmtcustomerinputtransform] PRIMARY KEY CLUSTERED
(
	Id ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
);

GO

SET ANSI_PADDING OFF
GO