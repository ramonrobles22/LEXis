﻿USE BridgerRFCommon;

SET IDENTITY_INSERT UserMgmtSystemRoles ON
INSERT UserMgmtSystemRoles (Id, DateCreated, CreatedBy, DateModified, ModifiedBy, Name, Description, Privileges) VALUES (1, GETDATE(), N'dbseed', GETDATE(), N'dbseed', N'Server Administrator', N'Server Administrator', N'////fwAAAAAAAAAAAAAAAAAAAAAAAAAAAA==');
INSERT UserMgmtSystemRoles (Id, DateCreated, CreatedBy, DateModified, ModifiedBy, Name, Description, Privileges) VALUES (2, GETDATE(), N'dbseed', GETDATE(), N'dbseed', N'Support Administrator', N'Support Administrator', N'WnadbQAAAAAAAAAAAAAAAAAAAAAAAAAAAA==');
INSERT UserMgmtSystemRoles (Id, DateCreated, CreatedBy, DateModified, ModifiedBy, Name, Description, Privileges) VALUES (3, GETDATE(), N'dbseed', GETDATE(), N'dbseed', N'Support User', N'Support User', N'EjCAbQAAAAAAAAAAAAAAAAAAAAAAAAAAAA==');
SET IDENTITY_INSERT UserMgmtSystemRoles OFF

INSERT UserMgmtSystemUsers (DateCreated, CreatedBy, DateModified, ModifiedBy, LoginName, Password, FullName, EmployeeId, EmailAddress, LoginFailedAttempts, IsLocked, IsPasswordChangeRequired, PasswordModified, Role_Id) 
VALUES ('2015-05-01', N'dbseed', '2015-05-01', N'dbseed', N'sysuser1', N'10000:MRb95bBZIiCahKYU:i5YhzcrjhI9t0caSZbbGlC+rLLcN8TZH', N'System User', NULL, N'bridgeradminqa@elektra.com.mx', 0, 0, 0, '2115-05-01', 1)

DELETE FROM WlMgmtSearchcoreDeploymentLocations;

INSERT INTO WlMgmtSearchcoreDeploymentLocations (InstanceName, FolderPath, ApiUrl, IsActive, Type, CreatedDate, UpdatedDate) 
VALUES ('WatchlistDeploy', 'D:\LexisNexisBridger5\Bridger\BridgerDataFiles', 'http://KIOBANQALXSC209.produccion.bancoazteca:7001/WsSearchCore/?ver_=1&internal', 1, 1, GETDATE(), NULL);

INSERT INTO WlMgmtSearchcoreDeploymentLocations (InstanceName, FolderPath, ApiUrl, IsActive, Type, CreatedDate, UpdatedDate) 
VALUES ('CustomWatchlistDeploy', 'D:\LexisNexisBridger5\DataFiles\BridgerCustomDataFiles', 'http://KIOBANQALXSC209.produccion.bancoazteca:7002/WsSearchCore/?ver_=1&internal', 1, 2, GETDATE(), NULL);

UPDATE bridgerrfcommon.dbo.usermgmtsystemsettings SET isenterprise = 1;
delete FROM bridgerrfmisc.dbo.cachecounter;
delete FROM bridgerrfmisc.dbo.cachetable;

INSERT INTO BatchMgmtService(Id, StartSuspended) VALUES(1, 0);
USE BridgerRFMisc;

INSERT INTO PasswordBlackList (password) VALUES('password');
INSERT INTO PasswordBlackList (password) VALUES('Bridger1');
INSERT INTO PasswordBlackList (password) VALUES('Bridger1!');
INSERT INTO PasswordBlackList (password) VALUES('Bridger10');
INSERT INTO PasswordBlackList (password) VALUES('Bridger12');
INSERT INTO PasswordBlackList (password) VALUES('Bridger123');
INSERT INTO PasswordBlackList (password) VALUES('Bridger2');
INSERT INTO PasswordBlackList (password) VALUES('Bridger3');
INSERT INTO PasswordBlackList (password) VALUES('Bridger4');
INSERT INTO PasswordBlackList (password) VALUES('Bridger5');
INSERT INTO PasswordBlackList (password) VALUES('Bridger6');
INSERT INTO PasswordBlackList (password) VALUES('Bridger7');
INSERT INTO PasswordBlackList (password) VALUES('Bridger8');
INSERT INTO PasswordBlackList (password) VALUES('Bridger9');
INSERT INTO PasswordBlackList (password) VALUES('Changeme1');
INSERT INTO PasswordBlackList (password) VALUES('Football!');
INSERT INTO PasswordBlackList (password) VALUES('Football1');
INSERT INTO PasswordBlackList (password) VALUES('geronimo');
INSERT INTO PasswordBlackList (password) VALUES('geronimo1');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd1');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd10');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd11');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd12');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd2');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd3');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd4');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd5');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd6');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd7');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd8');
INSERT INTO PasswordBlackList (password) VALUES('Passw0rd9');
INSERT INTO PasswordBlackList (password) VALUES('Password1');
INSERT INTO PasswordBlackList (password) VALUES('Password10');
INSERT INTO PasswordBlackList (password) VALUES('Password11');
INSERT INTO PasswordBlackList (password) VALUES('Password12');
INSERT INTO PasswordBlackList (password) VALUES('Password2');
INSERT INTO PasswordBlackList (password) VALUES('Password3');
INSERT INTO PasswordBlackList (password) VALUES('Password4');
INSERT INTO PasswordBlackList (password) VALUES('Password5');
INSERT INTO PasswordBlackList (password) VALUES('Password6');
INSERT INTO PasswordBlackList (password) VALUES('Password7');
INSERT INTO PasswordBlackList (password) VALUES('Password8');
INSERT INTO PasswordBlackList (password) VALUES('Password9');




