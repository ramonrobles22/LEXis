-- ----------------------------------------------------------------------------

-- -----------------------Database BridgerRf------------------------

-- ----------------------------------------------------------------------------

---BatchManagement---
/****** Object:  Table [dbo].[BatchAction]    Script Date: 1/13/2016 11:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE BatchAction (
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] INT NULL,
	[ActionType] INT NOT NULL,
	[DateCreated] DATETIME NOT NULL,
	[Name] NVARCHAR(255) NULL,
	[ParametersXML] NTEXT NULL,
	[SourceServer] NVARCHAR(255) NULL,
	[TargetServer] NVARCHAR(255) NULL,
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.BatchActionRole] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
);

/****** Object:  Table [dbo].[BatchAssignedRole]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchAssignedRole](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[RoleId] [int] NOT NULL,
	[BatchConfigurationId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchAssignedRole_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.BatchAssignedRole] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchAssignedRole_CustomerId] ON [dbo].[BatchAssignedRole] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO
/****** Object:  Table [dbo].[BatchAssignedUser]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchAssignedUser](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[UserId] [int] NOT NULL,
	[BatchConfigurationId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchAssignedUser_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.BatchAssignedUser] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchAssignedUser_CustomerId] ON [dbo].[BatchAssignedUser] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO
/****** Object:  Table [dbo].[BatchConfiguration]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchConfiguration](
	[Id] [int] IDENTITY(2,2) NOT NULL,
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_BatchConfiguration_IsDeleted" default(0),
	[CustomerId] [int] NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[InputFileName] [nvarchar](255) NULL,
	[InputFileFormatId] [int] NULL,
	[InputFileFormatEftType] [int] NOT NULL,
	[CultureName] [nvarchar](32) NULL,
	[Name] [nvarchar](128) NULL,
	[Description] [nvarchar](255) NULL,
	[ResponsibleUserId] [int] NULL,
	[PredefinedSearchId] [BINARY](16) NOT NULL,
	[DivisionId] [int] NULL,
	[PgpKey] [ntext] NULL,
	[AlertDistribution] [int] NOT NULL,
	[EmailNotification] [int] NOT NULL,
	[XmlOutputVersion] [nvarchar](10) NULL,
	[GlbaPermissableUse] [int] NOT NULL,
	[DppaPermissableUse] [int] NOT NULL,
	[AutomaticBatchType] [int] NOT NULL,
	[PgpFileName] [nvarchar](255) NULL,
    [CreateOutputFile] bit NOT NULL,
    [IncludeNoMatchResults] bit NOT NULL,
    [WriteResultsToDb] bit NOT NULL,
	[EftTransactionDetails] [int] NOT NULL,
	[CreatedByIp] [nvarchar](50) NULL Constraint "DF_BatchConfiguration_CreatedByIp" default(null),
	[OriginalId] [bigint] NULL,
	[UseDeltaScreening] [bit] NOT NULL CONSTRAINT "DF_BatchConfiguration_UseDeltaScreening" DEFAULT 0,
 CONSTRAINT [PK_dbo.BatchConfiguration] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
/****** Object:  Table [dbo].[BatchCustomFileFormat]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchCustomFileFormat](
	[Id] [int] IDENTITY(2,2) NOT NULL,
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_BatchCustomFileFormat_IsDeleted" default(0),
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[CustomerId] [int] NULL,
	[FileFormatType] [int] NOT NULL,
	[FormatType] [int] NOT NULL,
	[EncodingType] [int] NOT NULL,
	[EntityType] [int] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[DateFormat] [nvarchar](32) NULL,
	[FirstLineIsColumnHeader] [bit] NOT NULL,
	[MultiRecordField] [bit] NOT NULL,
	[DefaultCountryCode] [nvarchar](32) NULL,
	[DefaultCountryName] [nvarchar](128) NULL,
	[AreFieldsQuoted] [bit] NOT NULL,
    [ParsedAddressFields] [bit] NOT NULL,
	[FieldDelimiter] [nvarchar](10) NULL,
	[LineDelimiter] [nvarchar](10) NULL,
	[Crlf] [bit] NOT NULL,
	[LineLength] [int] NOT NULL,
	[ExampleFileName] [nvarchar](255) NULL,
	[ExampleFileData] [ntext] NULL,
	[IIDIFields] [bit] NOT NULL CONSTRAINT "DF_BatchCustomFileFormat_IIDIFields" default(0),
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.BatchCustomFileFormat] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
/****** Object:  Table [dbo].[BatchCustomFormatEntity]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchCustomFormatEntity](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[EntityType] [int] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[CustomFileFormatId] [int] NOT NULL,
	[EntityIndex] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchCustomFormatEntity_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
CONSTRAINT [PK_dbo.BatchCustomFormatEntity] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchCustomFormatEntity_CustomerId] ON [dbo].[BatchCustomFormatEntity] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO
/****** Object:  Table [dbo].[BatchCustomFormatField]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchCustomFormatField](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[CustomFileFormatId] [int] NOT NULL,
	[EntityIndex] [int] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[FullName] [nvarchar](100) NULL,
	[DataType] [int] NOT NULL,
	[IdType] [int] NOT NULL,
	[IdentificationIdType] [int] NULL,
	[AdditionalInfoIdType] [int] NULL,
	[AddressIdType] [int] NULL,
	[PhoneIdType] [int] NULL,
	[Position] [int] NULL,
	[Start] [int] NULL,
	[End] [int] NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchCustomFormatField_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
CONSTRAINT [PK_dbo.BatchCustomFormatField] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchCustomFormatField_CustomerId] ON [dbo].[BatchCustomFormatField] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO
/****** Object:  Table [dbo].[BatchCustomWatchlist]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchCustomWatchlist](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[UniqueId] [BINARY](16) NOT NULL,
	[ModificationCheck] [nvarchar](100) NULL,
	[BatchConfigurationId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchCustomWatchlist_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.BatchCustomWatchlist] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchCustomWatchlist_CustomerId] ON [dbo].[BatchCustomWatchlist] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO

/****** Object:  Table [dbo].[BatchEmailAddress]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchEmailAddress](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Email] [nvarchar](255) NOT NULL,
	[BatchConfigurationId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchEmailAddress_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.BatchEmailAddress] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchEmailAddress_CustomerId] ON [dbo].[BatchEmailAddress] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO
/****** Object:  Table [dbo].[BatchOutputFile]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchOutputFile](
	[Id] [bigint] NOT NULL,
	[BatchConfigurationId] [int] NULL,
	[BatchRunId] [bigint] NULL,
	[ResultSetId] [bigint] NULL,
	[CustomerId] [int] NULL,
	[DateCreated] [datetime] NOT NULL,
	[MaxBlockId] [int] NOT NULL,
	[ProcessingServerName] varchar(255) NULL,
	[OutputFileState] int NOT NULL CONSTRAINT "DF_BatchOutputFile_OutputFileState" default(0),
	[OriginalFileName] [nvarchar](255) NULL,
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.BatchOutputFile] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
/****** Object:  Table [dbo].[BatchRun]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchRun](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
    [IsDeleted] [bit] NOT NULL CONSTRAINT "DF_BatchRun_IsDeleted" default(0),
	[BatchConfigurationId] [int] NULL,
	[ResultSetId] [bigint] NULL,
	[CustomerId] [int] NULL,
	[DateCreated] [datetime] NOT NULL,
	[State] [smallint] NOT NULL,
	[Origin] [int] NOT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[PredefinedSearchName] [nvarchar](255) NULL,
	[EntityType] [int] NOT NULL,
	[UploadTimeBegin] [datetime] NULL,
	[UploadTimeEnd] [datetime] NULL,
	[DateSubmitted] [datetime] NOT NULL,
	[DateCompleted] [datetime] NULL,
	[SubmittedBy] [nvarchar](100) NULL,
	[NumRecordsProcessed] [bigint] NULL,
	[TotalNumRecords] [bigint] NULL,
	[TotalNumRows] [bigint] NULL,
	[AlertCount] [bigint] NULL,
	[ErrorCount] [bigint] NULL,
	[WatchlistMatchCount] [bigint] NULL,
	[IntermediaryFileName] [nvarchar](255) NULL,
	[InputFileName] [nvarchar](255) NULL,
	[OriginalFileName] [nvarchar](255) NULL,
	[OriginalFileLastModified] [datetime] NULL,
	[OriginalFileSize] [bigint] NULL,
	[InputFileFormatId] [int] NULL,
	[InputFileFormatEftType] [int] NOT NULL,
	[InputFileFormatName] [nvarchar](64) NULL,
	[CultureName] [nvarchar](10) NULL,
	[GlbaPermissableUse] [int] NOT NULL,
	[DppaPermissableUse] [int] NOT NULL,
	[AutomaticBatchType] [int] NOT NULL,
	[StatusMessage] [nvarchar](1024) NULL,
	[DivisionId] [int] NULL,
	[DivisionName] [nvarchar](255) NULL,
	[OutputFileNameWithAlerts] [nvarchar](255) NULL,
	[OutputFileNameClean] [nvarchar](255) NULL,
	[MaxBlockId] [int] NULL,
	[JobId] [nvarchar](50) NULL,
	[MaxBlockSize] [bigint] NULL,
	[JobPhase] [int] NULL,
	[ProviderIdentifiers] [nvarchar](100) NULL,
	[ProcessingServerName] [nvarchar](255) NULL,
	[EftTransactionDetails] [int] NOT NULL,
    [CanRecover] [bit] NOT NULL CONSTRAINT "DF_BatchRun_CanRecover" default(0),
	[CreatedByIp] [nvarchar](50) NULL Constraint "DF_BatchRun_CreatedByIp" default(null),
	[SubmittedById] int NULL,
 	[OriginalId] [bigint] NULL, 
	[DuplicateMatches_SuppressDuplicatesForBatch] [BIT] NULL,
	[DuplicateMatches_SameDivisionOnly] [BIT] NULL,
	[CreateOutputFile] [BIT] NULL,
	[IncludeNoMatchResults] [BIT] NULL,
	[SaveResultsToDatabase] [BIT] NULL,
	[UseDeltaScreening] [bit] NOT NULL CONSTRAINT "DF_BatchRun_UseDeltaScreening" DEFAULT 0,
 CONSTRAINT [PK_dbo.BatchRun] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
);
CREATE NONCLUSTERED INDEX [IX_BatchRun_CustomerId_Origin_DivisionId] ON [dbo].[BatchRun]
(
	[CustomerId] ASC,
	[Origin] ASC,
	[DivisionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_BatchRun_IsDeleted_Origin_DateCompleted] ON [dbo].[BatchRun]
(
	[IsDeleted] ASC,
	[Origin] ASC,
	[DateCompleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO



/****** Object:  Table [dbo].[BatchRunNote]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchRunNote](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[Note] [ntext] NOT NULL,
	[BatchRunId] [bigint] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchRunNote_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.BatchRunNote] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchRunNote_CustomerId] ON [dbo].[BatchRunNote] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO

/****** Object:  Table [dbo].[BatchRunRecoveryFile]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchRunRecoveryFile](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NULL,
	[OriginalId] BIGINT NULL,
	[BatchRunId] [bigint] NOT NULL,
	[FileData] IMAGE NULL,	
 CONSTRAINT [PK_dbo.BatchRunRecoveryFile] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchRunRecoveryFile_CustomerId_BatchRun] ON [dbo].[BatchRunRecoveryFile]
(
	[CustomerId] ASC,
	[BatchRunId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_BatchRunRecoveryFile_BatchRunId] ON [dbo].[BatchRunRecoveryFile]
(
	[BatchRunId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

/****** Object:  Table [dbo].[BatchRunWatchlist]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchRunWatchlist](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[BatchRunId] [bigint] NOT NULL,
	[Type] [int] NOT NULL,
	[EntityType] [int] NOT NULL,
	[Name] [nvarchar](128) NULL,
	[FileName] [nvarchar](255) NULL,
	[Version] [nvarchar](64) NULL,
	[PublishedDate] [datetime] NULL,
	[UniqueId] [BINARY](16) NOT NULL,
	[FileBuildDate] [datetime] NULL,
    [IgnoreWeakAkas] bit NOT NULL,
    [MinScore] INT NOT NULL,
    [HasAccess] bit NOT NULL,
    [TopLevelOperator] int NOT NULL,
    [HasWeakAkas] bit NOT NULL,
    [HasSearchCriteria] bit NOT NULL,
	[IsPep] BIT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchRunWatchlist_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.BatchRunWatchlist] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchRunWatchlist_CustomerId] ON [dbo].[BatchRunWatchlist] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO

/****** Object:  Table [dbo].[BatchRunUpdate]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchRunUpdate](
	[BatchRunId] [bigint] NOT NULL,
	[BlockId] [int] NOT NULL,
	[ProcessedCount] [bigint] NOT NULL,
	[WatchlistMatchCount] [bigint] NOT NULL,
	[AlertCount] [bigint] NOT NULL,
	[ErrorCount] [bigint] NOT NULL,
	[TotalCount] [bigint] NOT NULL,
	[DateOccurred] [datetime] NOT NULL,
	[JobId] [nvarchar](50) NULL,
	[JobPhase] [int] NULL,
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[StatusCode] [int] NOT NULL,
	[ErrorCode] [int] NULL,
	[Message] [nvarchar](1024) NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchRunUpdate_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.BatchRunUpdate] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
CREATE NONCLUSTERED INDEX IX_BatchRunUpdate_BatchRunId ON [dbo].[BatchRunUpdate]
(
   BatchRunId
)
INCLUDE ([ProcessedCount],[WatchlistMatchCount],[AlertCount],[ErrorCount])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_BatchRunUpdate_CustomerId] ON [dbo].[BatchRunUpdate] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO

/****** Object:  Table [dbo].[BatchUpload]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchUpload](
	[Id] [BINARY](16) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NOT NULL,
	[TimeBegin] [datetime] NULL,
	[TimeEnd] [datetime] NULL,
	[FileName] [nvarchar](255) NULL,
	[FileLastModified] [datetime] NOT NULL,
	[FileSize] [bigint] NOT NULL,
	[FilePosition] [bigint] NULL,
	[BatchConfigurationId] [int] NULL,
	[State] [int] NOT NULL,
	[CurrentSize] [bigint] NOT NULL,
	[CurrentPosition] [bigint] NOT NULL,
	[Origin] [int] NOT NULL,
	[SubmittedBy] [nvarchar](100) NULL,
	[BatchRunId] [bigint] NULL,
	[ProviderIdentifiers] [nvarchar](100) NULL,
	[CreatedByIp] [nvarchar](50) NULL Constraint "DF_BatchUpload_CreatedByIp" default(null),
	[SubmittedById] int NULL,
 CONSTRAINT [PK_dbo.BatchUpload] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
/****** Object:  Table [dbo].[BatchUploadChunk]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchUploadChunk](
	[Id] [BINARY](16) NOT NULL,
	[Position] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[Size] [bigint] NOT NULL,
	[Data] image NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchUploadChunk_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.BatchUploadChunk] PRIMARY KEY CLUSTERED
(
	[Id] ASC,
	[Position] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchUploadChunk_CustomerId] ON [dbo].[BatchUploadChunk] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchWatchlist]    Script Date: 7/24/2013 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchWatchlist](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[UniqueId] [BINARY](16) NOT NULL,
	[ModificationCheck] [nvarchar](100) NOT NULL,
	[BatchConfigurationId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT DF_BatchWatchlist_CustomerId DEFAULT (0),
 	[OriginalId] [bigint] NULL, 
 CONSTRAINT [PK_dbo.BatchWatchlist] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_BatchWatchlist_CustomerId] ON [dbo].[BatchWatchlist] 
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

/****** Object:  Table [dbo].[BatchBillingConsolidationRecord]    Script Date: 5/4/2015 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchBillingConsolidationRecord](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[StartTime] [Datetime] NULL,
	[EndTime] [Datetime] NULL,
	[FtpServer] [nvarchar] (255) NULL,
	[Filename] [nvarchar] (255) NULL,
	[FileNumBytes] [int] NULL,
 CONSTRAINT [PK_dbo.BatchBillingConsolidationRecord] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/****** Object:  Table [dbo].[BatchBillingTransferAudit]    Script Date: 5/4/2015 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchBillingTransferAudit](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[StartTime] [DateTime] NULL,
	[EndTime] [DateTime] NULL,
	[Filename] [nvarchar] (45) NULL,
	[BytesTransferred] [int] NOT NULL,
	[FtpServer] [nvarchar] (255) NULL,
	[FtpPort] [int] NULL,
	[FtpDestinationPath] [nvarchar] (255) NULL,
	[ErrorMessage] [nvarchar] (255) NULL,
	[BillingTransferTicketId] [int] NULL,
 CONSTRAINT [PK_dbo.BatchBillingTransferAudit] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/****** Object:  Table [dbo].[BatchBillingFile]    Script Date: 5/4/2015 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchBillingFile](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[BillingConsolidationId] [int] NULL,
	[FileName] [nvarchar] (255) NULL,
	[Directory] [nvarchar] (255) NULL,
	[NumberOfRecords] [INT] NOT NULL,
	[Created] [DateTime] NOT NULL,
 CONSTRAINT [PK_dbo.BatchBillingFile] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/****** Object:  Table [dbo].[BatchBillingFileCompany]    Script Date: 5/4/2015 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchBillingFileCompany](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[BillingFileId] [int] NULL,
	[BillingStartDate] [DateTime] NOT NULL,
	[BillingEndDate] [DateTime] NOT NULL,
	[MBSCompanyId] [nvarchar] (45) NULL,
	[NumRecords] [int] NOT NULL,
 CONSTRAINT [PK_dbo.BatchBillingFileCompany] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/****** Object:  Table [dbo].[BatchBillingTransferTicket]    Script Date: 5/4/2015 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchBillingTransferTicket](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[BillingConsolidationId] [int] NULL,
	[NumTransferAttempts] [int] NOT NULL,
	[RunsStartDate] [DateTime] NOT NULL,
	[RunsEndDate] [DateTime] NOT NULL,
	[CreationDate] [DateTime] NOT NULL,
	[BillingRecordCount] [bigint] NOT NULL,
	[LastUpdated] [datetime] NULL,
	[Status] [int] NOT NULL,
 CONSTRAINT [PK_dbo.BatchBillingTransferTicket] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/****** Object:  Table [dbo].[BatchBillingRecord]    Script Date: 5/4/2015 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchBillingRecord](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[BillingFileCompanyId] [int] NULL,
	[BatchRunId] [bigint] NOT NULL,
	[RunDate] [DateTime] NOT NULL,
	[Count] [BIGINT] NOT NULL CONSTRAINT "DF_BBR_Count" DEFAULT 0,
	[PepListCount] [int] NOT NULL,
	[ProvidersUsed] [int] NOT NULL,
	[TransactionType] [int] NOT NULL,
	[TotalListCount] [int] NOT NULL,
	[CustomerId] [int]  NOT NULL,
	[SearchOrigin] [int]  NOT NULL,
	[BatchFileName] [nvarchar] (45) NULL,
	[CustomerName] [nvarchar] (255) NOT NULL,
	[BillingType] [int] NOT NULL,
	[EnabledWatchlists] [varbinary](max) NULL,
	[ProcessingState] [int] NOT NULL CONSTRAINT "DF_BBR_ProcessingState" DEFAULT 0,
 CONSTRAINT [PK_dbo.BatchBillingRecord] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/****** Object:  Table [dbo].[BatchBillingWatchlistUsed]    Script Date: 5/4/2015 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchBillingWatchlistUsed](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int]  NOT NULL,
	[FileId] [BINARY] (16) NOT NULL,
	[Name] [nvarchar] (255) NOT NULL,
	[IsPepList] [bit] NOT NULL,
	[BillingRecordId] [int] NOT NULL,
	[Count] [int] NOT NULL,
	[RunDate] [DATETIME] NOT NULL,
 CONSTRAINT [PK_dbo.BatchBillingWatchlistUsed] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/****** Object:  Table [dbo].[BatchBillingWatchlistMap]    Script Date: 6/4/2015 4:39:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchBillingWatchlistMap](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Name] [NVARCHAR] (255)  NOT NULL,
	[FileId] [BINARY] (16) NULL,
	[ChargeCode] [int] NOT NULL CONSTRAINT "DF_BatchBillingWatchlistMap_ChargeCode" default(0),
	[BillingProvider] [int] NOT NULL CONSTRAINT "DF_BatchBillingWatchlistMap_BillingProvider" default(0),
    [BillingType] [int] NOT NULL,
 CONSTRAINT [PK_dbo.BatchBillingWatchlistMap] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

ALTER TABLE [dbo].[BatchConfiguration] ADD  DEFAULT ((0)) FOR [EftTransactionDetails]
GO
ALTER TABLE [dbo].[BatchRun] ADD  DEFAULT ((0)) FOR [EftTransactionDetails]
GO
ALTER TABLE [dbo].[BatchRunUpdate] ADD  DEFAULT ((0)) FOR [StatusCode]
GO
ALTER TABLE [dbo].[BatchUpload] ADD  DEFAULT ((0)) FOR [State]
GO
ALTER TABLE [dbo].[BatchUpload] ADD  DEFAULT ((0)) FOR [CurrentSize]
GO
ALTER TABLE [dbo].[BatchUpload] ADD  DEFAULT ((0)) FOR [CurrentPosition]
GO
ALTER TABLE [dbo].[BatchUpload] ADD  DEFAULT ((0)) FOR [Origin]
GO

/* ALTER TABLE [dbo].[BatchAssignedRole]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchAssignedRoleDbo.BatchConfigurationBatchConfigurationId] FOREIGN KEY([BatchConfigurationId])
REFERENCES [dbo].[BatchConfiguration] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchAssignedRole] CHECK CONSTRAINT [FK_dbo.BatchAssignedRoleDbo.BatchConfigurationBatchConfigurationId]
GO */

/* ALTER TABLE [dbo].[BatchAssignedUser]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchAssignedUserDbo.BatchConfigurationBatchConfigurationId] FOREIGN KEY([BatchConfigurationId])
REFERENCES [dbo].[BatchConfiguration] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchAssignedUser] CHECK CONSTRAINT [FK_dbo.BatchAssignedUserDbo.BatchConfigurationBatchConfigurationId]
GO */

/* ALTER TABLE [dbo].[BatchConfiguration]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchConfigurationDbo.BatchCustomFileFormatInputFileFormatId] FOREIGN KEY([InputFileFormatId])
REFERENCES [dbo].[BatchCustomFileFormat] ([Id])
GO
ALTER TABLE [dbo].[BatchConfiguration] CHECK CONSTRAINT [FK_dbo.BatchConfigurationDbo.BatchCustomFileFormatInputFileFormatId]
GO */

/* ALTER TABLE [dbo].[BatchCustomFormatEntity]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchCustomFormatEntityDbo.BatchCustomFileFormatCustomFileFormatId] FOREIGN KEY([CustomFileFormatId])
REFERENCES [dbo].[BatchCustomFileFormat] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchCustomFormatEntity] CHECK CONSTRAINT [FK_dbo.BatchCustomFormatEntityDbo.BatchCustomFileFormatCustomFileFormatId]
GO */

/* ALTER TABLE [dbo].[BatchCustomFormatField]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchCustomFormatFieldDbo.BatchCustomFileFormatCustomFileFormatId] FOREIGN KEY([CustomFileFormatId])
REFERENCES [dbo].[BatchCustomFileFormat] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchCustomFormatField] CHECK CONSTRAINT [FK_dbo.BatchCustomFormatFieldDbo.BatchCustomFileFormatCustomFileFormatId]
GO */

/* ALTER TABLE [dbo].[BatchCustomWatchlist]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchCustomWatchlistDbo.BatchConfigurationBatchConfigurationId] FOREIGN KEY([BatchConfigurationId])
REFERENCES [dbo].[BatchConfiguration] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchCustomWatchlist] CHECK CONSTRAINT [FK_dbo.BatchCustomWatchlistDbo.BatchConfigurationBatchConfigurationId]
GO */

/* ALTER TABLE [dbo].[BatchEmailAddress]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchEmailAddressDbo.BatchConfigurationBatchConfigurationId] FOREIGN KEY([BatchConfigurationId])
REFERENCES [dbo].[BatchConfiguration] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchEmailAddress] CHECK CONSTRAINT [FK_dbo.BatchEmailAddressDbo.BatchConfigurationBatchConfigurationId]
GO */

/* ALTER TABLE [dbo].[BatchRun]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchRunDbo.BatchConfigurationBatchConfigurationId] FOREIGN KEY([BatchConfigurationId])
REFERENCES [dbo].[BatchConfiguration] ([Id])
GO
ALTER TABLE [dbo].[BatchRun] CHECK CONSTRAINT [FK_dbo.BatchRunDbo.BatchConfigurationBatchConfigurationId]
GO */

/* ALTER TABLE [dbo].[BatchRun]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchRunDbo.BatchCustomFileFormatInputFileFormatId] FOREIGN KEY([InputFileFormatId])
REFERENCES [dbo].[BatchCustomFileFormat] ([Id])
GO
ALTER TABLE [dbo].[BatchRun] CHECK CONSTRAINT [FK_dbo.BatchRunDbo.BatchCustomFileFormatInputFileFormatId]
GO */

/* ALTER TABLE [dbo].[BatchRunNote]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchRunNoteDbo.BatchRunBatchRunId] FOREIGN KEY([BatchRunId])
REFERENCES [dbo].[BatchRun] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchRunNote] CHECK CONSTRAINT [FK_dbo.BatchRunNoteDbo.BatchRunBatchRunId]
GO */

/* ALTER TABLE [dbo].[BatchRunWatchlist]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchRunWatchlistDbo.BatchRunBatchRunId] FOREIGN KEY([BatchRunId])
REFERENCES [dbo].[BatchRun] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchRunWatchlist] CHECK CONSTRAINT [FK_dbo.BatchRunWatchlistDbo.BatchRunBatchRunId]
GO */

/* ALTER TABLE [dbo].[BatchWatchlist]  WITH CHECK ADD  CONSTRAINT [FK_dbo.BatchWatchlistDbo.BatchConfigurationBatchConfigurationId] FOREIGN KEY([BatchConfigurationId])
REFERENCES [dbo].[BatchConfiguration] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchWatchlist] CHECK CONSTRAINT [FK_dbo.BatchWatchlistDbo.BatchConfigurationBatchConfigurationId]
GO */
-- Table BridgerRF.ClientUsageRecords
-- ----------------------------------------------------------------------------
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE ClientUsageRecords (
    Id BIGINT NOT NULL IDENTITY(1,1),
    CustomerId INT NOT NULL,
    DateCreated DATETIME NOT NULL,
    RealTimeCount BIGINT DEFAULT 0,
    BatchCount BIGINT DEFAULT 0,
    BatchRecordsCount BIGINT DEFAULT 0,
    EFTBatchCount BIGINT DEFAULT 0,
    EFTBatchRecordsCount BIGINT DEFAULT 0,
    WebServiceCount BIGINT DEFAULT 0,
    WebServiceRecordsCount BIGINT DEFAULT 0,
    IIDIndividualCount BIGINT DEFAULT 0,
    IIDBusinessCount BIGINT DEFAULT 0,
	IIDInternationalCount BIGINT DEFAULT 0,
    FraudPointCount BIGINT DEFAULT 0,
    LexisNexisNewsCount BIGINT DEFAULT 0,
     CONSTRAINT [PK_dbo.ClientUsageRecord] PRIMARY KEY CLUSTERED
	(
		[Id] ASC,
		DateCreated ASC
	)
);
    
GO

CREATE NONCLUSTERED INDEX IX_ClientUsageRecord_CustomerId ON [dbo].[ClientUsageRecords]
(
   CustomerId ASC
)

GO

CREATE UNIQUE INDEX IX_ClientUsageRecords_CustomerId_DateCreated ON [dbo].[ClientUsageRecords]
(
   CustomerId ASC,
   DateCreated ASC
)

GO

/****** Object:  View [dbo].[BatchRunCounts]    Script Date: 6/2/2014 10:19:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE view [dbo].[BatchRunCounts]
as
	with counts as (
		select
		BatchRunId,
        ProcessedBlockCount = count(*),
        NumRecordsProcessed = sum(ProcessedCount),
		WatchlistMatchCount = sum(WatchlistMatchCount),
		AlertCount = Sum(AlertCount),
		ErrorCount = Sum(ErrorCount)
		from dbo.BatchRunUpdate with (ReadUncommitted)
		group by BatchRunId
	)
	select Id, IsDeleted, State,
	 counts.ProcessedBlockCount, counts.NumRecordsProcessed, counts.WatchlistMatchCount, counts.AlertCount, counts.ErrorCount
	from dbo.BatchRun with (ReadUncommitted)
	inner join counts on counts.BatchRunId = dbo.BatchRun.Id;

GO

---resultsmanagement---

/****** Object:  Table [dbo].[ResultInstantIdBusinessRiskIndicator]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultInstantIdBusinessRiskIndicator](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Code] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
	[InstantIdBusinessResult_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdBusinessRiskIndicator_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdBusinessRiskIndicator] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdBusinessResult_Id] ON [dbo].[ResultInstantIdBusinessRiskIndicator]
(
	[InstantIdBusinessResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdBusinessRiskIndicator_CustomerId] ON [dbo].[ResultInstantIdBusinessRiskIndicator] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdBusinessRedFlagRiskIndicator
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdBusinessRedFlagRiskIndicator]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdBusinessRedFlagRiskIndicator](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Code] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
	[InstantIdBusinessRedFlag_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdBusinessRedFlagRiskIndicator_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdBusinessRedFlagRiskIndicator] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdBusinessRedFlag_Id] ON [dbo].[ResultInstantIdBusinessRedFlagRiskIndicator]
(
	[InstantIdBusinessRedFlag_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdBusinessRedFlagRiskIndicator_CustomerId] ON [dbo].[ResultInstantIdBusinessRedFlagRiskIndicator] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdBusinessRedFlag
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdBusinessRedFlag]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdBusinessRedFlag](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Category] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[InstantIdBusinessResult_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdBusinessRedFlag_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdBusinessRedFlag] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdBusinessResult_Id] ON [dbo].[ResultInstantIdBusinessRedFlag]
(
	[InstantIdBusinessResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdBusinessRedFlag_CustomerId] ON [dbo].[ResultInstantIdBusinessRedFlag] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultBusinessInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultBusinessInfo]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultBusinessInfo](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[CompanyName] [nvarchar](512) NULL,
	[Address_Type] [int] NULL,
	[Address_AddressLine1] [nvarchar](255) NULL,
	[Address_AddressLine2] [nvarchar](255) NULL,
	[Address_City] [nvarchar](128) NULL,
	[Address_State] [nvarchar](100) NULL,
	[Address_County] [nvarchar](255) NULL,
	[Address_PostalCode] [nvarchar](20) NULL,
	[Address_CountryCode] [nvarchar](100) NULL,
	[Address_StreetNumber] [nvarchar](64) NULL,
	[Address_StreetName] [nvarchar](64) NULL,
	[Address_StreetPreDirection] [nvarchar](10) NULL,
	[Address_StreetPostDirection] [nvarchar](10) NULL,
	[Address_StreetType] [nvarchar](64) NULL,
	[Address_FullAddress] [nvarchar](512) NULL,
	[Address_SubBuildingNumber] [nvarchar](64) NULL,
	[Address_UnitDesignation] [nvarchar](30) NULL,
	[Address_UnitNumber] [nvarchar](30) NULL,
	[Address_Instance] [int] NULL,
	[Phone10] [nvarchar](30) NULL,
	[FEIN] [nvarchar](30) NULL,
	[InstantIdBusinessResultId] [bigint] NULL,
	[BusinessInfoType] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultBusinessInfo_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsBusinessInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdBusinessResult_Id] ON [dbo].[ResultBusinessInfo]
(
	[InstantIdBusinessResultId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultBusinessInfo_CustomerId] ON [dbo].[ResultBusinessInfo] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultProcessSetting
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultProcessSetting]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultProcessSetting](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[AddNoteAlertStateChanged] [bit] NOT NULL,
	[AddNoteAttachmentAddedToRecord] [bit] NOT NULL,
	[AddNoteRecordAddedToAcceptList] [bit] NOT NULL,
	[AddNoteRecordAddedToCWL] [bit] NOT NULL,
	[AddNoteRecordReassigned] [bit] NOT NULL,
	[AddNoteStatusChanged] [bit] NOT NULL,
	[RequireStatusReassignAlert] [bit] NOT NULL,
	[RequireStatusCloseAlert] [bit] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsProcessSetting] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultStatus
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultStatus]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultStatus](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[Description] [nvarchar](255) NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_ResultStatus_IsDeleted" default(0),
	[CanEdit] [bit] NOT NULL,
	[CanRemove] [bit] NOT NULL,
	[CanSelect] [bit] NOT NULL,
	[DateModified] [datetime] NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultStatus] PRIMARY KEY CLUSTERED
(
	[Id] ASC
),
CONSTRAINT [UIX_CustomerID_AlertStatusDescription] UNIQUE NONCLUSTERED
(
	[CustomerId], [Description], [IsDeleted]
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO

/****** Object:  Table [dbo].[ResultSet]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultSet](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Assignees] [nvarchar](max) NULL,  -- This needs to be nvarchar(max), since any number of users / roles could be assigned to a result set
	[AlertDistributionType] [int] NOT NULL,
	[Origin] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[CustomerId] [int] NOT NULL,
	[Complete] [bit] NOT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[BatchRunId] [bigint] NULL,
	[DivisionId] [int] NOT NULL,
	[CustomFormatUsed] [nvarchar](255) NULL,
	[BatchFileName] [nvarchar](255) NULL,
	[ParsedAddressFields] [bit] NOT NULL,
	[ResponsibleUserName] [nvarchar](100) NULL,
	[ResponsibleUserId] int NULL,
	[PredefinedSearchUniqueId] [BINARY](16) NULL,
	[ResponsibleUserRoleId] INT NULL,
	[IsDeleted] [BIT] NOT NULL CONSTRAINT "DF_ResultSet_IsDeleted" DEFAULT(0),
	[OriginalId] BIGINT NULL,
	[AppliedModelId] INT NULL,
 CONSTRAINT [PK_dbo.ResultSet] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultSet_PDS_Id] ON [dbo].[ResultSet]
(
	[PredefinedSearchId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultSet_PdsUniqueId_Id] ON [dbo].[ResultSet]
(
	[PredefinedSearchUniqueId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultSet_Division_Id] ON [dbo].[ResultSet]
(
	[DivisionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CustomerId_IsDeleted_DivisionId_RoleId] ON [dbo].[ResultSet]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[DivisionId] ASC,
	[ResponsibleUserRoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CustomerId_IsDeleted_DivisionId_UserId] ON [dbo].[ResultSet]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[DivisionId] ASC,
	[ResponsibleUserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultSet_IsDeleted_Origin_DateCreated] ON [dbo].[ResultSet]
(
	[IsDeleted] ASC,
	[Origin] ASC,
	[DateCreated] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInputEntity
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInputEntity]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ResultInputEntity](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInputEntity_CustomerId DEFAULT 0,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[EntityType] [int] NOT NULL,
	[Gender] [int] NOT NULL,
	[Name_Title] [nvarchar](255) NULL,
	[Name_First] [nvarchar](255) NULL,
	[Name_Last] [nvarchar](255) NULL,
	[Name_Middle] [nvarchar](255) NULL,
	[Maiden] [nvarchar](255) NULL,
	[SecondSurname] [nvarchar](255) NULL,
	[Name_Generation] [nvarchar](50) NULL,
	[Name_Full] [nvarchar](1000) NULL,
	[RecordType] [int] NOT NULL,
	[ReferenceNumber] [nvarchar](50) NULL,
	[Text] [nvarchar](2000) NULL, --guess
	[DelimiterType] [int] NOT NULL,
	[PostContext] [nvarchar](512) NULL,
	[PreContext] [nvarchar](512) NULL,
	[EFT] [nvarchar](36) NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_ResultInputEntity_IsDeleted" default(0),
	[MatchText] [nvarchar](1000) NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInputEntity] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInputEntity_CustomerId] ON [dbo].[ResultInputEntity]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAccountType
-- ----------------------------------------------------------------------------

CREATE TABLE [dbo].[ResultAccountType](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[Description] [nvarchar](255) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NOT NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_ResultAccountType_IsDeleted" default(0),
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsAccountType] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAlertDecision
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAlertDecision]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultAlertDecision](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](255) NOT NULL,
	[AssignmentOption] [int] NOT NULL,
	[AlertStateOption] [int] NOT NULL,
	[ResultStatusOption] [int] NOT NULL,
	[CustomWatchListOption] [int] NOT NULL,
	[AcceptListOption] [int] NOT NULL,
	[NoteOption] [int] NOT NULL,
	[NavigationOption] [int] NOT NULL,
	[ResultStatusId] [int] NULL,
	[AlertState] [int] NOT NULL,
	[AcceptListId] [int] NULL,
	[CustomWatchListId] [int] NULL,
	[CustomWatchListReason] [nvarchar](255) NULL,
	[AssignedRoleId] [int] NULL,
	[AssignedUserId] [int] NULL,
	[AssignedSelection] [int] NOT NULL,
	[NoteText] [ntext] NULL,
	[IsRuleAlert] [bit] NOT NULL CONSTRAINT "DF_ResultAlertDecision_IsRuleAlert" default(0),
	[AllDivisions] [bit] NOT NULL CONSTRAINT "DF_ResultAlertDecision_AllDivisions" default(0),
	[UniqueId] [BINARY](16) NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT "DF_ResultAlertDecision_IsActive" default(1),
	[Version] [int] NOT NULL CONSTRAINT "DF_ResultAlertDecision_Version" default(1),
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsAlertDecision] PRIMARY KEY CLUSTERED
(
	[Id] ASC
))
GO
CREATE NONCLUSTERED INDEX [UIX_CustomerID_AlertDecisionName_IsActive] ON [dbo].[ResultAlertDecision]
(
	[CustomerId], [IsActive], [Name]
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAlertDecisionAssignedRoles
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAlertDecisionAssignedRoles]    Script Date: 06/18/2015 18:01:15 ******/

CREATE TABLE [dbo].[ResultAlertDecisionAssignedRoles](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RoleId] [int] NOT NULL,
	[AlertDecisionId] [int] NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultAlertDecisionAssignedRoles_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultAlertDecisionAssignedRoles] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAlertDecisionAssignedRoles_CustomerId] ON [dbo].[ResultAlertDecisionAssignedRoles] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO


---- ----------------------------------------------------------------------------
---- Table BridgerRF.ResultAlertDecisionAssignedUsers
---- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAlertDecisionAssignedUsers]    Script Date: 06/18/2015 18:01:15 ******/

CREATE TABLE [dbo].[ResultAlertDecisionAssignedUsers](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[AlertDecisionId] [int] NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultAlertDecisionAssignedUsers_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultAlertDecisionAssignedUsers] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAlertDecisionAssignedUsers_CustomerId] ON [dbo].[ResultAlertDecisionAssignedUsers] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO



-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAdverseFilingResult
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAdverseFilingResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultAdverseFilingResult](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[ResultRecordId] [int] NOT NULL,
	[Searched] [varbinary](10) NULL,
	[Saved] [varbinary](10) NULL,
	[ResultEntitiesId] [int] NULL,
	[FilingsFound] [bit] NULL,
	[SearchConducted] [bit] NOT NULL,
	[ErrorCode] [int] NULL,
	[ErrorMessage] [nvarchar](1024) NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultAdverseFilingResult_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsAdverseFilingResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAdverseFilingResult_CustomerId] ON [dbo].[ResultAdverseFilingResult] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAlertFilter
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAlertFilter]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultAlertFilter](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[Name] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Query] [nvarchar](max) NULL,
	[CanRemove] [bit] NOT NULL,
	[CanEdit] [bit] NOT NULL,
	[DatePreset] [int] NOT NULL,
	[EFTId] [nvarchar](72) NULL,
	[FromDate] [datetime] NULL,
	[ToDate] [datetime] NULL,
	[FilterType] [int] NOT NULL,
	[SearchWithIn] [int] NOT NULL,
	[ReturnAssignedTo] [int] NOT NULL,
	[Origin] [int] NOT NULL,
	[PrimarySortKey] [nvarchar](100) NULL,
	[PrimarySortDirection] [int] NOT NULL,
	[SecondarySortKey] [nvarchar](100) NULL,
	[SecondarySortDirection] [int] NOT NULL,
	[IsTempFilter] [bit] NOT NULL,
	[BatchResultSetIds] [nvarchar](max) NULL,
	[EnableReturnAssignedTo] [bit] NOT NULL,
	[ShareFilter] [bit] NOT NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_ResultAlertFilter_IsDeleted" default(0),
	[ParentId] [int] NULL,
	[RootParentId] [int] NULL,
	[MultipleAlertProcessingId] [bigint] NULL,
	[MultipleAlertRecordStatus] [int] NOT NULL CONSTRAINT "DF_ResultAlertFilter_MARStatus" default(0),
	[QueryFunction] [varbinary](max) NULL,
	[QueryData] [varbinary](max) NULL,
	[QueryFields] [nvarchar](max) NULL,
	[IsCachable] [bit] NOT NULL CONSTRAINT "DF_ResultAlertFilter_IsCachable" default(0),
	[CacheRefreshIntervalSeconds] [int] NULL,
	[OriginalId] BIGINT NULL,
	[OriginalCulture] [nvarchar](20) NULL,
CONSTRAINT [PK_dbo.ResultsAlertFilter] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
CREATE NONCLUSTERED INDEX [IX_RAF_CustomerId_IsDeleted_IsTempFilter_ShareFilter] ON [dbo].[ResultAlertFilter]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[IsTempFilter] ASC,
	[ShareFilter] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RAF_IsCachable_IsDeleted_Interval_IsTemp] ON [dbo].[ResultAlertFilter]
(
	[IsCachable] ASC,
	[IsDeleted] ASC,
	[CacheRefreshIntervalSeconds] ASC,
	[IsTempFilter] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAlertFilterCacheResult
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAlertFilterCacheResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultAlertFilterCacheResult](
	[Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NOT NULL,
	[CacheData] [varbinary](max) NULL,
	[OriginalId] BIGINT NULL,
    [QueryError] [NVARCHAR](1024) NULL,
CONSTRAINT [PK_dbo.ResultAlertFilterCacheResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO

	
GO
/****** Object:  Table [dbo].[ResultAlertDecisionRoleRestriction]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultAlertDecisionRoleRestriction](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[RoleId] [int] NOT NULL,
	[AlertDecision_Id] [int] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultAlertDecisionRoleRestriction_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsAlertDecisionRoleRestriction] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_AlertDecision_Id] ON [dbo].[ResultAlertDecisionRoleRestriction]
(
	[AlertDecision_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAlertDecisionRoleRestriction_CustomerId] ON [dbo].[ResultAlertDecisionRoleRestriction] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAlertFilterRoleRestriction
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAlertFilterRoleRestriction]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultAlertFilterRoleRestriction](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[RoleId] [int] NOT NULL,
	[AlertFilter_Id] [int] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultAlertFilterRoleRestriction_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsAlertFilterRoleRestriction] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_AlertFilter_Id] ON [dbo].[ResultAlertFilterRoleRestriction]
(
	[AlertFilter_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAlertFilterRoleRestriction_CustomerId] ON [dbo].[ResultAlertFilterRoleRestriction] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO


/****** Object:  Table [dbo].[ResultBlockReference]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultBlockReference
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[ResultBlockReference](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[BlockReferenceId] [int] NOT NULL,
	[ResultSet_Id] [bigint] NULL,
	[ResultSet_Id1] [bigint] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultBlockReference_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsBlockReference] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultSet_Id] ON [dbo].[ResultBlockReference]
(
	[ResultSet_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultSet_Id1] ON [dbo].[ResultBlockReference]
(
	[ResultSet_Id1] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultBlockReference_CustomerId] ON [dbo].[ResultBlockReference] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultEntityPhoneNumber
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultEntityPhoneNumber]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultEntityPhoneNumber](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[PhoneType] [int] NOT NULL,
	[Number] [nvarchar](30) NULL,
	[UnformattedNumber] [nvarchar](30) NULL,
	[Instance] [int] NOT NULL,
	[InputEntity_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultEntityPhoneNumber_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsEntityPhoneNumber] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InputEntity_Id] ON [dbo].[ResultEntityPhoneNumber]
(
	[InputEntity_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultEntityPhoneNumber_CustomerId] ON [dbo].[ResultEntityPhoneNumber] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultEntityAddress
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultEntityAddress]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultEntityAddress](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[AddressLine1] [nvarchar](255) NULL,
	[AddressLine2] [nvarchar](255) NULL,
	[Suburb] [nvarchar](128) NULL,
	[District] [nvarchar](128) NULL,
	[City] [nvarchar](128) NULL,
	[State] [nvarchar](100) NULL,
	[PostalCode] [nvarchar](20) NULL,
	[CountryCode] [nvarchar](100) NULL,
	[County] [nvarchar](255) NULL,
	[StreetName] [nvarchar](64) NULL,
	[StreetNumber] [nvarchar](64) NULL,
	[FullAddress] [nvarchar](512) NULL,
	[BuildingNumber] [nvarchar](64) NULL,
	[HouseNumber] [nvarchar](64) NULL,
	[BuildingName] [nvarchar](64) NULL,
	[FloorNumber] [nvarchar](64) NULL,
	[SubBuildingNumber] [nvarchar](64) NULL,
	[UnitDesignation] [nvarchar](30) NULL,
	[UnitNumber] [nvarchar](30) NULL,
	[StreetPreDirection] [nvarchar](10) NULL,
	[StreetPostDirection] [nvarchar](10) NULL,
	[StreetType] [nvarchar](64) NULL,
	[IntlStreetType] [nvarchar](64) NULL,
	[Instance] [int] NOT NULL,
	[InputEntity_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultEntityAddress_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsEntityAddress] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InputEntity_Id] ON [dbo].[ResultEntityAddress]
(
	[InputEntity_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultEntityAddress_CustomerId] ON [dbo].[ResultEntityAddress] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultEntityAdditionalInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultEntityAdditionalInfo]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultEntityAdditionalInfo](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Value] [nvarchar](512) NOT NULL,
	[ParsedValue] [nvarchar](512) NULL,
	[ParsedDate] [datetime] NULL,
	[Instance] [int] NOT NULL,
	[InputEntity_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultEntityAdditionalInfo_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
        [Label] [nvarchar](256) NULL,
 CONSTRAINT [PK_dbo.ResultsEntityAdditionalInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InputEntity_Id] ON [dbo].[ResultEntityAdditionalInfo]
(
	[InputEntity_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultEntityAdditionalInfo_CustomerId] ON [dbo].[ResultEntityAdditionalInfo] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultEFTRecord
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultEFTRecord]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultEFTRecord](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[TransactionId] [nvarchar](255) NULL,
	[EFTId] [nvarchar](72) NULL,
	[RawEFT] [varchar](max) NULL,
	[CompressedRawEFT] IMAGE NULL,
	[Type] [int] NOT NULL,
	[OFACIndicator] [bit] NOT NULL,
	[Amount] [nvarchar](50) NULL,
	[ParsedAmount] decimal(20,2) NULL,
	[FileName] [nvarchar](255) NULL,
	[ReceiverAccountId] [nvarchar](255) NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[ResultSetId] [bigint] NOT NULL,
	[ScreeningListMatchCount] [int] NULL,
    [StandardEntryClassCode] [nvarchar](10) NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultEFTRecord_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsEFTRecord] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultSetId] ON [dbo].[ResultEFTRecord]
(
	[ResultSetId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultEftRecord_EftId] ON [dbo].[ResultEFTRecord]
(
	[EFTId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultEFTRecord_CustomerId] ON [dbo].[ResultEFTRecord] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultDivisionRestriction
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultDivisionRestriction]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultDivisionRestriction](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[DivisionId] [int] NOT NULL,
	[AlertDecision_Id] [int] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultDivisionRestriction_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsDivisionRestriction] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_AlertDecision_Id] ON [dbo].[ResultDivisionRestriction]
(
	[AlertDecision_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultDivisionRestriction_CustomerId] ON [dbo].[ResultDivisionRestriction] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInputEntityIdentification
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInputEntityIdentification]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInputEntityIdentification](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Label] [nvarchar](255) NULL,
	[Number] [nvarchar](255) NULL,
	[UnformattedNumber] [nvarchar](255) NULL,
	[IssuedBy] [nvarchar](255) NULL,
	[IssuedDate] [datetime] NULL,
	[IssuedDateInput] [nvarchar](30) NULL,
	[ExpirationDate] [datetime] NULL,
	[ExpirationDateInput] [nvarchar](30) NULL,
	[MachineReadable] [nvarchar](255) NULL,
	[MachineReadableAlt] [nvarchar](255) NULL,
	[CityOfIssue] [nvarchar](255) NULL,
	[CountyOfIssue] [nvarchar](255) NULL,
	[DistrictOfIssue] [nvarchar](255) NULL,
	[ProvinceOfIssue] [nvarchar](255) NULL,
	[StateOfBirth] [nvarchar](255) NULL,
	[DriverLicenceVersionNumber] [nvarchar](255) NULL,
	[PlaceOfBirth] [nvarchar](255) NULL,
	[CountryOfBirth] [nvarchar](255) NULL,
	[FamilyNameAtBirth] [nvarchar](255) NULL,
	[FamilyNameAtCitizenship] [nvarchar](255) NULL,
	[Instance] [int] NOT NULL,
	[InputEntity_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInputEntityIdentification_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInputEntityIdentification] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InputEntity_Id] ON [dbo].[ResultInputEntityIdentification]
(
	[InputEntity_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInputEntityIdentification_CustomerId] ON [dbo].[ResultInputEntityIdentification] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdBusinessResult
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdBusinessResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultInstantIdBusinessResult](
	[Id] [bigint] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdBusinessResult_CustomerId DEFAULT 0,
	[NAP] [int] NULL,
	[NAS] [int] NULL,
	[OriginalSource] [varbinary](max) NULL,
	[ErrorCd] [nvarchar](20) NULL,
	[ErrorMessage] [nvarchar](512) NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[IsAlert] [bit] NOT NULL,
	[Index] [int] NOT NULL,
	[IndexGeneratedAlert] [bit] NOT NULL,
	[NAPGeneratedAlert] [bit] NOT NULL,
	[NASGeneratedAlert] [bit] NOT NULL,
	[Glba] [int] NOT NULL,
	[Dppa] [int] NOT NULL,
	[IsCompanyNameVerified] [bit] NOT NULL,
	[IsAddressVerified] [bit] NOT NULL,
	[IsCityVerified] [bit] NOT NULL,
	[IsStateVerified] [bit] NOT NULL,
	[IsZipVerified] [bit] NOT NULL,
	[IsPhone10Verified] [bit] NOT NULL,
	[IsFEINVerified] [bit] NOT NULL,
	[PhoneType] [int] NOT NULL,
	[PhoneOfNameAddress] [nvarchar](30) NULL,
	[SOSFilingName] [nvarchar](255) NULL,
	[BankruptcyCount] [int] NOT NULL,
	[RecentBankruptcyFilingDate] [datetime] NULL,
	[RecentBankruptcyType] [nvarchar](100) NULL,
	[UnreleasedLienCounter] [int] NOT NULL,
	[ReleasedLienCounter] [int] NOT NULL,
	[RecentLienFilingDate] [datetime] NULL,
	[RecentLienType] [nvarchar](100) NULL,
	[InputEcho_CompanyName] [nvarchar](512) NULL,
	[InputEcho_FEIN] [nvarchar](30) NULL,
	[InputEcho_PhoneNumber] [nvarchar](30) NULL,
	[InputEcho_CompanyAddress_Type] [int] NOT NULL,
	[InputEcho_CompanyAddress_AddressLine1] [nvarchar](255) NULL,
	[InputEcho_CompanyAddress_AddressLine2] [nvarchar](255) NULL,
	[InputEcho_CompanyAddress_City] [nvarchar](128) NULL,
	[InputEcho_CompanyAddress_State] [nvarchar](100) NULL,
	[InputEcho_CompanyAddress_County] [nvarchar](255) NULL,
	[InputEcho_CompanyAddress_PostalCode] [nvarchar](20) NULL,
	[InputEcho_CompanyAddress_CountryCode] [nvarchar](100) NULL,
	[InputEcho_CompanyAddress_StreetNumber] [nvarchar](64) NULL,
	[InputEcho_CompanyAddress_StreetName] [nvarchar](64) NULL,
	[InputEcho_CompanyAddress_StreetPreDirection] [nvarchar](10) NULL,
	[InputEcho_CompanyAddress_StreetPostDirection] [nvarchar](10) NULL,
	[InputEcho_CompanyAddress_StreetType] [nvarchar](64) NULL,
	[InputEcho_CompanyAddress_FullAddress] [nvarchar](512) NULL,
	[InputEcho_CompanyAddress_SubBuildingNumber] [nvarchar](64) NULL,
	[InputEcho_CompanyAddress_UnitDesignation] [nvarchar](30) NULL,
	[InputEcho_CompanyAddress_UnitNumber] [nvarchar](30) NULL,
	[InputEcho_CompanyAddress_Instance] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdBusinessResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdBusinessResult_CustomerId] ON [dbo].[ResultInstantIdBusinessResult]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultRecord
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultRecord]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultRecord](
	[Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[BlockReferenceId] [bigint] NOT NULL,
	[RecordId] [bigint] NULL,
	[CustomerId] [int] NOT NULL,
	[EFTId] [nvarchar](72) NULL,
	[AlertState] [int] NOT NULL,
	[ErrorMessage] [nvarchar](1024) NULL,
	[ErrorMessageLocalized] [nvarchar](max) NULL,
	[AddedToAcceptList] [bit] NOT NULL,
	[CustomWatchListIds] [nvarchar](512) NULL,
	[IsAlert] [bit] NOT NULL,
	[IsResultFalsePositive] [bit] NOT NULL,
	[IsOfacScreened] [bit] NOT NULL,
	[IsOfacScreened2] [bit] NOT NULL,
	[Origin] [int] NOT NULL,
	[DivisionId] [int] NOT NULL CONSTRAINT "DF_RR_DivisionId" DEFAULT(0),
	[DivisionName] [nvarchar](255) NULL,
	[InUseById] [int] NULL,
	[LockExpiration] [datetime] NULL,
	[ResultSetId] [bigint] NOT NULL,
	[HasOfacReport] [bit] NOT NULL,
	[Account_Type] [nvarchar](500)  NULL,
	[Account_Date] [nvarchar](100) NULL,
	[Account_Amount] [nvarchar](500) NULL,
	[Account_Number] [nvarchar](100) NULL,
	[Account_ProviderId] [nvarchar](255) NULL,
	[Account_GroupId] [nvarchar](50) NULL,
	[Account_MemberId] [nvarchar](100) NULL,
	[Account_OtherData] [nvarchar](255) NULL,
	[ResultStatus_Id] [int] NULL,
	[PredefinedSearchName] [nvarchar](255) NULL,
	[EFTType] [int] NULL,
	[Name] [nvarchar](1000) NULL,
	[IDType] [int] NULL,
	[IDNumber] [nvarchar](255) NULL,
	[OriginOrFileName] [nvarchar](255) NULL,
	[AccountId] [nvarchar](255) NULL,
	[WatchListHits] [int] NULL,
	[AutoDispositioned] [bit] NOT NULL,
	[IndividualMatchDisposition] [bit] NOT NULL,
	[AddedAcceptListName] [nvarchar](255) NULL,
	[AddedAcceptListId] [int] NULL,
	[ResultStatusDate] [datetime] NULL,
	[AlertStateDate] [datetime] NULL,
	[WCHits] [int] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_ResultRecord_IsDeleted" default(0),
	[UseAdvancedRules] [BIT] NOT NULL,
	[InstantIdIndex] [int] NULL,
	[Status] [nvarchar](255) NULL,
	[ResultStatusId] [int] NULL,
	[RecordCheckSum] [binary](16) NULL,
	[AssignedId] [INT] NULL,
	[AssignedUserId] [INT] NULL,
	[AssignedName] VARCHAR(255) NULL,
	[AssignedUserName] VARCHAR(255) NULL,
	[AssignedRoleId] [INT] NULL,
	[AssignedRoleName] VARCHAR(255) NULL,
	[AssignmentType] [INT] NOT NULL CONSTRAINT "DF_ResultRecord_AssignmentType" default(0),
	[LegacyResultId] [BIGINT] NULL,	
	[FprReasonCodes] [VARCHAR](255) NULL,
	[FprMinConfidence] [REAL] NULL,
	[FprMaxConfidence] [REAL] NULL,
 CONSTRAINT [PK_dbo.ResultRecord] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_ResultSetId] ON [dbo].[ResultRecord]
(
	[ResultSetId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultStatus_Id] ON [dbo].[ResultRecord]
(
	[ResultStatus_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultRecord_CustomerId] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Customer_IsDeleted_EftId] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[EFTId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Customer_IsDeleted_AssignId_State_EftId] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[AssignedId] ASC,
	[AlertState] ASC,
	[EFTId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Customer_IsDeleted_Origin] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[Origin] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Customer_IsDeleted_AlertState_AssignType_UserId_Origin] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[AlertState] ASC,
	[AssignmentType] ASC,
	[AssignedId] ASC,
	[Origin] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Customer_IsDeleted_AssignType_AlertState_Origin] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[AssignmentType] ASC,
	[AlertState] ASC,
	[Origin] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultRecord_RecordCheckSum] ON [dbo].[ResultRecord]
(
	[RecordCheckSum] ASC,
	[CustomerId] ASC,
	[AlertState] ASC,
	[IsDeleted] ASC,
	[DivisionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CustomerId_CreatedBy] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
	[CreatedBy] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Customer_IsDel_AlertState_AssigdId_AssigType_Origin] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[AlertState] ASC,
	[AssignedId] ASC,
	[AssignmentType] ASC,
	[Origin] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Customer_IsDel_AssignedId_AssigType_AlertState_Origin] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
	[IsDeleted] ASC,
	[AssignedId] ASC,
	[AssignmentType] ASC,
	[AlertState] ASC,
	[Origin] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultSetId_IsDel_AlertState_AssignedId_Origin] ON [dbo].[ResultRecord]
(
	[ResultSetId] ASC,
	[IsDeleted] ASC,
	[AlertState] ASC,
	[AssignedId] ASC,
	[Origin] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultRecord_CustomerId_DivisionId_IsDeleted_AccountId] ON [dbo].[ResultRecord]
(
	[CustomerId] ASC,
        [DivisionId] ASC,
        [IsDeleted] ASC,
	[AccountId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultRecordAssignment
-- ----------------------------------------------------------------------------

/****** Object:  Table [dbo].[ResultRecordAssignment]    Script Date: 3/5/2014 2:45:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultRecordAssignment](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[DateCreated] DATETIME NOT NULL CONSTRAINT "DF_RRA_DateCreated" DEFAULT CURRENT_TIMESTAMP,
	[AssignmentType] [int] NULL,
	[AssignmentId] [int] NULL,
	[AssignmentName] [nvarchar](256) NULL,
	[ResultRecordId] [bigint] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultRecordAssignment] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON

CREATE NONCLUSTERED INDEX [IX_Customer_Assignment_ResultRecordId] ON [dbo].[ResultRecordAssignment]
(
	[CustomerId] ASC,
	[AssignmentId] ASC,
	[ResultRecordId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultPredefinedSearchRestriction
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultPredefinedSearchRestriction]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultPredefinedSearchRestriction](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[PredefinedSearchUniqueId] [BINARY](16) NULL,
	[AlertDecision_Id] [int] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultPredefinedSearchRestriction_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsPredefinedSearchRestriction] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_AlertDecision_Id] ON [dbo].[ResultPredefinedSearchRestriction]
(
	[AlertDecision_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultPredefinedSearchRestriction_CustomerId] ON [dbo].[ResultPredefinedSearchRestriction] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

/****** Object:  Table [dbo].[ResultFactivaMediaResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultFactivaMediaResult](
	[Id] [bigint] NOT NULL,
	[IsAlert] [bit] NOT NULL,

	[OriginalSource] [varbinary](max) NULL,
	[ErrorCd] [nvarchar](20) NULL,
	[ErrorMessage] [nvarchar](512) NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[Type] [nvarchar](20) NULL,
	[SearchInfo] [nvarchar](200) NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultFactivaMediaResult_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsFactivaMediaResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultFactivaMediaResult_CustomerId] ON [dbo].[ResultFactivaMediaResult] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO

-- ----------------------------------------------------------------------------------------
-- Table BridgerRF.ResultFieldSet
-- ----------------------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFieldSet]    Script Date: 05/23/2019 13:00:000 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [ResultFieldSet] (
  [Id] [INT] NOT NULL IDENTITY(1,1),
  [CustomerId] [INT] NOT NULL DEFAULT 0,
  [Name] [NVARCHAR](100) NOT NULL,  
  [IsDeleted] [BIT] NOT NULL DEFAULT 0,
  [DateCreated] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [CreatedBy] [NVARCHAR](50) NULL,
  [DateModified] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [ModifiedBy] [NVARCHAR](50) NULL,
  [OriginalId] [BIGINT] NULL
   CONSTRAINT [PK_dbo.ResultFieldSet] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- ----------------------------------------------------------------------------------------
-- Table BridgerRF.ResultFieldSetField
-- ----------------------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFieldSetField]    Script Date: 05/23/2019 13:00:000 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [ResultFieldSetField] (
  [Id] [INT] IDENTITY(1,1) NOT NULL,
  [ResultFieldSet_Id] INT NOT NULL DEFAULT 0,
  [CustomerId] [INT] NOT NULL DEFAULT 0,
  [FieldId] INT NOT NULL DEFAULT 0,  
  [IsDeleted] [BIT] NOT NULL DEFAULT 0,
  [Order] [INT] NOT NULL DEFAULT 0,
  [DateCreated] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [CreatedBy] [NVARCHAR](50) NULL,
  [DateModified] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [ModifiedBy] [NVARCHAR](50) NULL,
  [OriginalId] [BIGINT] NULL
   CONSTRAINT [PK_dbo.ResultFieldSetField] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO

-- ----------------------------------------------------------------------------------------
-- Table BridgerRF.ResultFieldSetRole
-- ----------------------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFieldSetRole]    Script Date: 05/23/2019 13:00:000 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [ResultFieldSetRole] (
  [Id] [INT] IDENTITY(1,1) NOT NULL,
  [ResultFieldSet_Id] INT NOT NULL DEFAULT 0,
  [CustomerId] [INT] NOT NULL DEFAULT 0,
  [RoleId] INT NOT NULL DEFAULT 0,  
  [IsDeleted] [BIT] NOT NULL DEFAULT 0,
  [DateCreated] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [CreatedBy] [NVARCHAR](50) NULL,
  [DateModified] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [ModifiedBy] [NVARCHAR](50) NULL,
  [OriginalId] [BIGINT] NULL
   CONSTRAINT [PK_dbo.ResultFieldSetRole] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO


-- ----------------------------------------------------------------------------------------
-- Table BridgerRF.ResultFprReason
-- ----------------------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFprReason]    Script Date: 7/15/2019 9:43:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ResultFprReason](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NULL,
	[Description] [varchar](255) NULL,
	[CustomerId] [int] NULL,
	[DateCreated] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UIX_Code_CustomerId] UNIQUE NONCLUSTERED 
(
	[Code] ASC,
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- ----------------------------------------------------------------------------------------
-- Table BridgerRF.ResultFieldSetPDS
-- ----------------------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFieldSetPDS]    Script Date: 05/23/2019 13:00:000 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [ResultFieldSetPDS] (
  [Id] [INT] IDENTITY(1,1) NOT NULL,
  [ResultFieldSet_Id] INT NOT NULL DEFAULT 0,
  [CustomerId] [INT] NOT NULL DEFAULT 0,
  [PredefinedSearchUniqueId] [BINARY](16) NOT NULL,
  [IsDeleted] [BIT] NOT NULL DEFAULT 0,
  [DateCreated] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [CreatedBy] [NVARCHAR](50) NULL,
  [DateModified] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [ModifiedBy] [NVARCHAR](50) NULL,
  [OriginalId] [BIGINT] NULL
   CONSTRAINT [PK_dbo.ResultFieldSetPDS] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
-- ----------------------------------------------------------------------------------------
-- Table BridgerRF.ResultFieldSetContent
-- ----------------------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFieldSetContent]    Script Date: 05/23/2019 13:00:000 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [ResultFieldSetContent] (
  [Id] [INT] IDENTITY(1,1) NOT NULL,
  [ResultFieldSet_Id] INT NOT NULL DEFAULT 0,
  [CustomerId] [INT] NOT NULL DEFAULT 0,
  [AlertContentId] INT NOT NULL DEFAULT 0,  
  [IsDeleted] [BIT] NOT NULL DEFAULT 0,
  [DateCreated] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [CreatedBy] [NVARCHAR](50) NULL,
  [DateModified] [DATETIME] NOT NULL DEFAULT CURRENT_TIMESTAMP,
  [ModifiedBy] [NVARCHAR](50) NULL,
  [OriginalId] [BIGINT] NULL
   CONSTRAINT [PK_dbo.ResultFieldSetContent] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultWatchListResult
-- ----------------------------------------------------------------------------

/****** Object:  Table [dbo].[ResultWatchListResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultWatchListResult](
	[Id] [bigint] NOT NULL,
	[DateCreated] DATETIME NOT NULL CONSTRAINT "DF_RWL_DateCreated" DEFAULT CURRENT_TIMESTAMP,
	[ErrorMessage] [nvarchar](1024) NULL,
	[ErrorMessageLocalized] [nvarchar](max) NULL,
	[WarningMessage] [nvarchar](1024) NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultWatchListResult_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsWatchListResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultWatchListResult_CustomerId] ON [dbo].[ResultWatchListResult] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

/****** Object:  Table [dbo].[ResultLexisNexisNewsResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
CREATE TABLE [dbo].[ResultLexisNexisNewsResult](
	[Id] [bigint] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultLexisNexisNewsResult_CustomerId DEFAULT 0,
	[ErrorCd] [int] NULL,
	[ErrorMessage] [nvarchar](512) NULL,
	[IsAdhocSearch] [bit] NOT NULL,
	[IsAlert] [bit] NOT NULL,
	[SearchPerformed] [bit] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsLexisNexisNewsResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultLexisNexisNewsResult_CustomerId] ON [dbo].[ResultLexisNexisNewsResult]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE TABLE [dbo].[ResultLexisNexisNewsDocument](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[NewsDocumentContainerId] [bigint] NOT NULL,
	[DocumentId] [nvarchar](250) NOT NULL,
	[Document] [nvarchar](MAX) NULL,
	[CompressedDocument] [varbinary](max) NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[IsAttached] [bit] NOT NULL CONSTRAINT [DF_ResultLexisNexisNewsDocument_IsAttached]  DEFAULT ((0)),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultLexisNexisNewsDocument_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultLexisNexisNewsDocument] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80)
)
GO

CREATE NONCLUSTERED INDEX [IX_RLNND_NDCID] ON [dbo].[ResultLexisNexisNewsDocument]
(
	[NewsDocumentContainerId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultLexisNexisNewsDocument_CustomerId] ON [dbo].[ResultLexisNexisNewsDocument] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

SET ANSI_PADDING OFF
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultOfacReport
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultOfacReport]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultOfacReport](
	[Id] [bigint] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultOfacReport_CustomerId DEFAULT 0,
	[AmountBlocked] [nvarchar](100) NULL,
	[ActionDate] [nvarchar](100) NULL,
	[PreparedDate] [nvarchar](100) NULL,
	[TransactionDate] [nvarchar](100) NULL,
	[ReportType] [int] NOT NULL,
	[lockedId] [int] NOT NULL,
	[AdditionalData] [nvarchar](2000) NULL,
	[AdditionalInfo] [nvarchar](2000) NULL,
	[SignerName] [nvarchar](1000) NULL,
	[Reason] [nvarchar](255) NULL,
	[SignerTitle] [nvarchar](255) NULL,
	[ResultRecord_Id] [bigint] NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsOfacReport] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultRecord_Id] ON [dbo].[ResultOfacReport]
(
	[ResultRecord_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultOfacReport_CustomerId] ON [dbo].[ResultOfacReport]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdIndividualResult
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdIndividualResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultInstantIdIndividualResult](
	[Id] [bigint] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdIndividualResult_CustomerId DEFAULT 0,
	[NAP] [int] NULL,
	[NAS] [int] NULL,
	[Index] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL default CURRENT_TIMESTAMP,
	[OriginalSource] [varbinary](max) NULL,
	[ErrorCd] [nvarchar](20) NULL,
	[ErrorMessage] [nvarchar](512) NULL,
	[IsAlert] [bit] NOT NULL,
	[IsRedFlagsEnabled] [bit] NOT NULL CONSTRAINT "DF_ResultIID_IsRedFlagsEnabled" default(0),
	[IndexGeneratedAlert] [bit]  NOT NULL CONSTRAINT "DF_ResultIID_IndexGeneratedAlert" default(0),
	[NAPGeneratedAlert] [bit]  NOT NULL CONSTRAINT "DF_ResultIID_NAPGeneratedAlert" default(0),
	[NASGeneratedAlert] [bit]  NOT NULL CONSTRAINT "DF_ResultIID_NASGeneratedAlert" default(0),
	[PhoneAtAddress] [nvarchar](30) NULL,
	[Glba] [int] NOT NULL,
	[Dppa] [int] NOT NULL,
	[SearchPerformed] [bit]  NOT NULL CONSTRAINT "DF_ResultIID_SearchPerformed" default(0),
	[UniqueIdentifier] [nvarchar](72) NULL,
	[InputEcho_Name_Title] [nvarchar](255) NULL,
	[InputEcho_Name_First] [nvarchar](255) NULL,
	[InputEcho_Name_Last] [nvarchar](255) NULL,
	[InputEcho_Name_Middle] [nvarchar](255) NULL,
	[InputEcho_Name_Generation] [nvarchar](50) NULL,
	[InputEcho_Name_Full] [nvarchar](1000) NULL,
	[InputEcho_Address_Type] [int] NULL,
	[InputEcho_Address_AddressLine1] [nvarchar](255) NULL,
	[InputEcho_Address_AddressLine2] [nvarchar](255) NULL,
	[InputEcho_Address_City] [nvarchar](128) NULL,
	[InputEcho_Address_State] [nvarchar](100) NULL,
	[InputEcho_Address_County] [nvarchar](255) NULL,
	[InputEcho_Address_PostalCode] [nvarchar](20) NULL,
	[InputEcho_Address_CountryCode] [nvarchar](100) NULL,
	[InputEcho_Address_StreetNumber] [nvarchar](64) NULL,
	[InputEcho_Address_StreetName] [nvarchar](64) NULL,
	[InputEcho_Address_StreetPreDirection] [nvarchar](10) NULL,
	[InputEcho_Address_StreetPostDirection] [nvarchar](10) NULL,
	[InputEcho_Address_StreetType] [nvarchar](10) NULL,
	[InputEcho_Address_FullAddress] [nvarchar](512) NULL,
	[InputEcho_Address_SubBuildingNumber] [nvarchar](64) NULL,
	[InputEcho_Address_UnitDesignation] [nvarchar](30) NULL,
	[InputEcho_Address_UnitNumber] [nvarchar](30) NULL,
	[InputEcho_Address_Instance] [int] NULL,
	[InputEcho_DOB] [datetime] NULL,
	[InputEcho_SSN] [nvarchar](30) NULL,
	[InputEcho_DriverLicenseNumber] [nvarchar](100) NULL,
	[InputEcho_DriverLicenseState] [nvarchar](100) NULL,
	[InputEcho_HomePhone] [nvarchar](30) NULL,
	[InputEcho_WorkPhone] [nvarchar](30) NULL,
	[VerifiedInput_Name_Title] [nvarchar](255) NULL,
	[VerifiedInput_Name_First] [nvarchar](255) NULL,
	[VerifiedInput_Name_Last] [nvarchar](255) NULL,
	[VerifiedInput_Name_Middle] [nvarchar](255) NULL,
	[VerifiedInput_Name_Generation] [nvarchar](50) NULL,
	[VerifiedInput_Name_Full] [nvarchar](1000) NULL,
	[VerifiedInput_CurrentAddress_Type] [int] NULL,
	[VerifiedInput_CurrentAddress_AddressLine1] [nvarchar](255) NULL,
	[VerifiedInput_CurrentAddress_AddressLine2] [nvarchar](255) NULL,
	[VerifiedInput_CurrentAddress_City] [nvarchar](128) NULL,
	[VerifiedInput_CurrentAddress_State] [nvarchar](100) NULL,
	[VerifiedInput_CurrentAddress_County] [nvarchar](255) NULL,
	[VerifiedInput_CurrentAddress_PostalCode] [nvarchar](20) NULL,
	[VerifiedInput_CurrentAddress_CountryCode] [nvarchar](100) NULL,
	[VerifiedInput_CurrentAddress_StreetNumber] [nvarchar](64) NULL,
	[VerifiedInput_CurrentAddress_StreetName] [nvarchar](64) NULL,
	[VerifiedInput_CurrentAddress_StreetPreDirection] [nvarchar](10) NULL,
	[VerifiedInput_CurrentAddress_StreetPostDirection] [nvarchar](10) NULL,
	[VerifiedInput_CurrentAddress_StreetType] [nvarchar](64) NULL,
	[VerifiedInput_CurrentAddress_FullAddress] [nvarchar](512) NULL,
	[VerifiedInput_CurrentAddress_SubBuildingNumber] [nvarchar](64) NULL,
	[VerifiedInput_CurrentAddress_UnitDesignation] [nvarchar](30) NULL,
	[VerifiedInput_CurrentAddress_UnitNumber] [nvarchar](30) NULL,
	[VerifiedInput_CurrentAddress_Instance] [int] NULL,
	[VerifiedInput_SSN] [nvarchar](30) NULL,
	[VerifiedInput_HomePhone] [nvarchar](30) NULL,
	[VerifiedInput_DOB] [datetime] NULL,
	[VerifiedInput_DriverLicenseNumber] [nvarchar](100) NULL,
	[CurrentName_Title] [nvarchar](255) NULL,
	[CurrentName_First] [nvarchar](255) NULL,
	[CurrentName_Last] [nvarchar](255) NULL,
	[CurrentName_Middle] [nvarchar](255) NULL,
	[CurrentName_Generation] [nvarchar](50) NULL,
	[CurrentName_Full] [nvarchar](512) NULL,
	[ReversePhone_Name_Title] [nvarchar](255) NULL,
	[ReversePhone_Name_First] [nvarchar](255) NULL,
	[ReversePhone_Name_Last] [nvarchar](255) NULL,
	[ReversePhone_Name_Middle] [nvarchar](255) NULL,
	[ReversePhone_Name_Generation] [nvarchar](50) NULL,
	[ReversePhone_Name_Full] [nvarchar](1000) NULL,
	[ReversePhone_Address_Type] [int] NULL,
	[ReversePhone_Address_AddressLine1] [nvarchar](255) NULL,
	[ReversePhone_Address_AddressLine2] [nvarchar](255) NULL,
	[ReversePhone_Address_City] [nvarchar](128) NULL,
	[ReversePhone_Address_State] [nvarchar](10) NULL,
	[ReversePhone_Address_County] [nvarchar](255) NULL,
	[ReversePhone_Address_PostalCode] [nvarchar](30) NULL,
	[ReversePhone_Address_CountryCode] [nvarchar](100) NULL,
	[ReversePhone_Address_StreetNumber] [nvarchar](64) NULL,
	[ReversePhone_Address_StreetName] [nvarchar](64) NULL,
	[ReversePhone_Address_StreetPreDirection] [nvarchar](10) NULL,
	[ReversePhone_Address_StreetPostDirection] [nvarchar](10) NULL,
	[ReversePhone_Address_StreetType] [nvarchar](64) NULL,
	[ReversePhone_Address_FullAddress] [nvarchar](512) NULL,
	[ReversePhone_Address_SubBuildingNumber] [nvarchar](64) NULL,
	[ReversePhone_Address_UnitDesignation] [nvarchar](30) NULL,
	[ReversePhone_Address_UnitNumber] [nvarchar](30) NULL,
	[ReversePhone_Address_Instance] [int] NULL,
	[FollowupActions] [int] NOT NULL,
	[SSNInfo_Valid] [bit] NOT NULL CONSTRAINT "DF_ResultIID_SSNInfo_Valid" default(0),
	[SSNInfo_SSN] [nvarchar](30) NULL,
	[SSNInfo_IssuingLocation] [nvarchar](72) NULL,
	[SSNInfo_StartDate] [datetime] NULL,
	[SSNInfo_EndDate] [datetime] NULL,
	[DOBVerified] [BIT] NOT NULL CONSTRAINT "DF_RIID_DOBVerified" Default(0),
	[DOBMatchLevel] [INT] NULL,
	[Version] [nvarchar](6) NOT NULL CONSTRAINT "DF_ResultsInstantIdIndividualVersion" default('1'),
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdIndividualResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdIndividualResult_CustomerId] ON [dbo].[ResultInstantIdIndividualResult]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

SET ANSI_PADDING OFF
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdInternationalResult
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdInternationalResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultInstantIdInternationalResult](
	[Id] [bigint] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdInternationalResult_CustomerId DEFAULT 0,
	[DateCreated] [datetime] NOT NULL CONSTRAINT DF_ResultInstantIdInternationalResult_DateCreated DEFAULT CURRENT_TIMESTAMP,
	[CountryCd] [nvarchar](255) NULL,
	[PermissibleUseCd] [int] NOT NULL,
    [Version] nvarchar(6) NULL,
	[IVI] [int] NULL,
	[CitVL] [int] NULL,
	[ComVL] [int] NULL,
	[ComplianceLevel] int NULL,
	[OriginalSource] [varbinary](max) NULL,
	[ErrorCd] [nvarchar](255) NULL,
	[ErrorMessage] [nvarchar](1024) NULL,
	[IsAlert] [bit] NOT NULL,
	[Glba] [int] NOT NULL,
	[Dppa] [int] NOT NULL,
	VerificationStatus int NULL,
	IsPassportValidated bit NOT NULL CONSTRAINT DF_ResultInstantIdInternationalResult_IsPassportValidated DEFAULT 0,
	IsVisaValidated bit NOT NULL CONSTRAINT DF_ResultInstantIdInternationalResult_IsVisaValidated DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdInternationalResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdInternationalResult_CustomerId] ON [dbo].[ResultInstantIdInternationalResult]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultFraudPointResult
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFraudPointResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultFraudPointResult](
	[Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[IsAlert] [bit] NOT NULL,
	[ScoreGeneratedAlert] [bit] NOT NULL,
	[OriginalSource] [varbinary](max) NULL,
	[ErrorCd] [nvarchar](20) NULL,
	[ErrorMessage] [nvarchar](512) NULL,
	[UniqueIdentifier] [nvarchar](72) NULL,
	[Dppa] [int] NOT NULL,
	[Glba] [int] NOT NULL,
	[Score] [int] NOT NULL,
	[SyntheticIdentityIndex] [int] NOT NULL,
	[StolenIdentityIndex] [int] NOT NULL,
	[ManipulatedIdentityIndex] [int] NOT NULL,
	[VulnerableVictimIndex] [int] NOT NULL,
	[FriendlyFraudIndex] [int] NOT NULL,
	[SuspiciousActivityIndex] [int] NOT NULL,
	[Version] [int] NULL,
	[AddressUsed] [nvarchar](20) NULL,
	[OriginalId] BIGINT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultFraudPointResult_CustomerId DEFAULT 0,
 CONSTRAINT [PK_dbo.ResultsFraudPointResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultFraudPointResult_CustomerId] ON [dbo].[ResultFraudPointResult] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAuditRecord
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAuditRecord]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultAuditRecord](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[LockId] [bigint] NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedByUserId] [int] NULL,
	[Note] [ntext] NULL,
	[Action] [int] NOT NULL,
	[ResultRecord_Id] [bigint] NOT NULL,
	[ResultStatusId] [int] NULL,
	[ModifiedByRoleId] [int] NULL,
	AppliedAlertDecisionId int NULL,
	CustomerId INT NOT NULL DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsAuditRecord] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultRecord_Id] ON [dbo].[ResultAuditRecord]
(
	[ResultRecord_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Action] ON [dbo].[ResultAuditRecord]
(
	[Action] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAuditRecord_Modified_By_User_Id] ON [dbo].[ResultAuditRecord]
(
	[ModifiedByUserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAuditRecord_Result_Status_Id] ON [dbo].[ResultAuditRecord]
(
	[ResultStatusId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RAR_RESULTS_NOT_WORKED] ON [dbo].[ResultAuditRecord]
(
	[Action] ASC,
	[ModifiedByUserId] ASC,
	[ResultRecord_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RAR_RESULTS_WORKED_STATUS_ROLE] ON [dbo].[ResultAuditRecord]
(
	[ResultRecord_Id] ASC,
	[ResultStatusId] ASC,
	[ModifiedByRoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RAR_RESULTS_WORKED_STATUS_USER] ON [dbo].[ResultAuditRecord]
(
	[ResultRecord_Id] ASC,
	[ResultStatusId] ASC,
	[ModifiedByUserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RAR_RESULTS_WORKED_ACTION_ROLE] ON [dbo].[ResultAuditRecord]
(
	[ResultRecord_Id] ASC,
	[Action] ASC,
	[ModifiedByRoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RAR_RESULTS_WORKED_ACTION_USER] ON [dbo].[ResultAuditRecord]
(
	[ResultRecord_Id] ASC,
	[Action] ASC,
	[ModifiedByUserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAuditRecord_AppliedAlertDecisionId] ON [dbo].[ResultAuditRecord]
(
	[AppliedAlertDecisionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAlertAttachment
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAlertAttachment]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultAlertAttachment](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultAlertAttachment_CustomerId DEFAULT 0,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NOT NULL,
	[Attachment] [varbinary](max) NULL,
	[CompressedAttachment] [varbinary](max) NULL,
	[FileName] [nvarchar](255) NULL,
	[FileType] [nvarchar](100) NULL,
	[DateDeleted] [datetime] NULL,
	[Notes] [nvarchar](max) NULL,
	[ResultRecordId] [bigint] NOT NULL,
	[DocumentId] [nvarchar](250) NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsAlertAttachment] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAttachment_CustomerId] ON [dbo].[ResultAlertAttachment]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_ResultRecordId] ON [dbo].[ResultAlertAttachment]
(
	[ResultRecordId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultAdditionalLastName
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultAdditionalLastName]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultAdditionalLastName](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[LastName] [nvarchar](255) NULL,
	[LastSeen] [datetime] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[InstantIdIndividualResult_Id] [bigint] NOT NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultAdditionalLastName_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsAdditionalLastName] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdIndividualResult_Id] ON [dbo].[ResultAdditionalLastName]
(
	[InstantIdIndividualResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultAdditionalLastName_CustomerId] ON [dbo].[ResultAdditionalLastName] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultChronologyHistory
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultChronologyHistory]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultChronologyHistory](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Address_Type] [int] NOT NULL,
	[Address_AddressLine1] [nvarchar](255) NULL,
	[Address_AddressLine2] [nvarchar](255) NULL,
	[Address_City] [nvarchar](128) NULL,
	[Address_State] [nvarchar](100) NULL,
	[Address_County] [nvarchar](255) NULL,
	[Address_PostalCode] [nvarchar](20) NULL,
	[Address_CountryCode] [nvarchar](100) NULL,
	[Address_StreetNumber] [nvarchar](64) NULL,
	[Address_StreetName] [nvarchar](64) NULL,
	[Address_StreetPreDirection] [nvarchar](10) NULL,
	[Address_StreetPostDirection] [nvarchar](10) NULL,
	[Address_StreetType] [nvarchar](64) NULL,
	[Address_FullAddress] [nvarchar](512) NULL,
	[Address_SubBuildingNumber] [nvarchar](64) NULL,
	[Address_UnitDesignation] [nvarchar](30) NULL,
	[Address_UnitNumber] [nvarchar](30) NULL,
	[Address_Instance] [int] NOT NULL,
	[FirstSeen] [datetime] NOT NULL,
	[LastSeen] [datetime] NOT NULL,
	[PhoneNumber] [nvarchar](30) NULL,
	[IsBestAddress] [bit] NOT NULL,
	[InstantIdIndividualResult_Id] [bigint] NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultChronologyHistory_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsChronologyHistory] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdIndividualResult_Id] ON [dbo].[ResultChronologyHistory]
(
	[InstantIdIndividualResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultChronologyHistory_CustomerId] ON [dbo].[ResultChronologyHistory] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultFraudPointRedFlag
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFraudPointRedFlag]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultFraudPointRedFlag](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Category] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[FraudPointResult_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultFraudPointRedFlag_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsFraudPointRedFlag] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_FraudPointResult_Id] ON [dbo].[ResultFraudPointRedFlag]
(
	[FraudPointResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultFraudPointRedFlag_CustomerId] ON [dbo].[ResultFraudPointRedFlag] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultFraudPointRiskIndicator
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFraudPointRiskIndicator]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultFraudPointRiskIndicator](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Code] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
	[FraudPointResult_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultFraudPointRiskIndicator_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsFraudPointRiskIndicator] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_FraudPointResult_Id] ON [dbo].[ResultFraudPointRiskIndicator]
(
	[FraudPointResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultFraudPointRiskIndicator_CustomerId] ON [dbo].[ResultFraudPointRiskIndicator] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdIndividualRiskIndicator
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdIndividualRiskIndicator]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdIndividualRiskIndicator](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Code] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
	[InstantIdIndividualResult_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdIndividualRiskIndicator_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdIndividualRiskIndicator] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdIndividualResult_Id] ON [dbo].[ResultInstantIdIndividualRiskIndicator]
(
	[InstantIdIndividualResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdIndividualRiskIndicator_CustomerId] ON [dbo].[ResultInstantIdIndividualRiskIndicator] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdIndividualRedFlag
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdIndividualRedFlag]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdIndividualRedFlag](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Category] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[InstantIdIndividualResult_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdIndividualRedFlag_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdIndividualRedFlag] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdIndividualResult_Id] ON [dbo].[ResultInstantIdIndividualRedFlag]
(
	[InstantIdIndividualResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdIndividualRedFlag_CustomerId] ON [dbo].[ResultInstantIdIndividualRedFlag] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMatch
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultMatch]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultMatch](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[IsUnstructured] [bit] NOT NULL,
	[SearchWord] [int] NOT NULL,
	[IsAutomaticFalsePositive] [bit] NOT NULL,
	[CountryContext] [nvarchar](512) NULL,
	[NameContext] [nvarchar](1000) NULL,
	[IsEFTMatch] [bit] NOT NULL,
	[IsFalsePositive] [bit] NOT NULL,
	[IsRealert] [bit] NOT NULL,
	[CheckSum] [int] NOT NULL,
	[EntityUniqueID] [nvarchar](72) NULL,
	[IsTypeConflict] [bit] NOT NULL,
	[IsConflict] [bit] NOT NULL,
	[IsBestMatch] [bit] NOT NULL,
	[BestNameMatch] [nvarchar](1000) NULL,
	BestNameScore [int] NOT NULL,
	[IsMatch] [bit] NOT NULL,
	[Score] [int] NOT NULL,
	[EFTContextEnd] [int] NOT NULL,
	[EFTContextStart] [int] NOT NULL,
	[IsMatchGenderConflict] [bit] NOT NULL,
	[IsOfacScreened] [bit] NOT NULL,
	[IsOfacScreened2] [bit] NOT NULL,
	[Collapsed] [bit] NOT NULL,
	[DisplayState] [int] NOT NULL,
	[Name_Title] [nvarchar](1024) NULL,
	[Name_First] [nvarchar](255) NULL,
	[Name_Last] [nvarchar](255) NULL,
	[Name_Middle] [nvarchar](255) NULL,
	[Name_Generation] [nvarchar](50) NULL,
	[Name_Full] [nvarchar](1000) NULL,
	[Country] [nvarchar](255) NULL,
	[Gender] [int] NOT NULL,
	[Type] [int] NOT NULL,
	[Number] [nvarchar](255) NULL,
	[Date] [datetime] NULL,
	[Reason] [nvarchar](255) NULL,
	[NoteData] [varbinary](max) NULL,
	[File_IsCustom] [bit] NOT NULL,
	[File_Build] [datetime] NOT NULL,
	[File_Published] [datetime] NOT NULL,
	[File_Type] [int] NOT NULL,
	[File_SelectionInstance] [int] NOT NULL,
	[File_Name] [nvarchar](255) NULL,
	[File_WatchlistId] [BINARY](16) NOT NULL,
	[WatchListResult_Id] [bigint] NOT NULL,
	[PrevResultID] [bigInt] NULL,
	[IsNameFromAddressMatch] [bit] NULL,
	[DateCreated] [datetime] NOT NULL,
	[ChildrenXML] [nvarchar](max) NULL,
	[IsXMLCompressed] [bit] NOT NULL CONSTRAINT "DF_ResultMatch_IsXMLCompressed" default(0),
	[FalseHitTriggerType] INT NOT NULL CONSTRAINT "DF_ResultMatch_TriggerType" DEFAULT 0,
    [IsFalseMatchUpdate] BIT NOT NULL CONSTRAINT "DF_ResultMatch_IsFalseMatchUpdate" DEFAULT 0,
    [IsGenderMatch] BIT NOT NULL CONSTRAINT "DF_ResultMatch_IsGenderMatch" DEFAULT 0,
    [FalseHitAcceptListId] INT NOT NULL CONSTRAINT "DF_ResultMatch_FalseHitAcceptListId" DEFAULT 0,
    [FalseHitEntityId] INT NOT NULL CONSTRAINT "DF_ResultMatch_FalseHitEntityId" DEFAULT 0,
    [FalseHitMatchId] INT NOT NULL CONSTRAINT "DF_ResultMatch_FalseHitMatchId" DEFAULT 0,
 CONSTRAINT [PK_dbo.ResultsMatch] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_WatchListResult_Id] ON [dbo].[ResultMatch]
(
	[WatchListResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RM_FN] ON [dbo].[ResultMatch]
(
                [file_name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RM_S_IBM] ON [dbo].[ResultMatch]
(
	[Score] ASC,
	[IsBestMatch] ASC
) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RM_Match_DisplayState] ON [dbo].[ResultMatch]
(
                [DisplayState] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_RM_Match_IsReAlert] ON [dbo].[ResultMatch]
(
                [IsReAlert] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMatchDetail
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[ResultMatchDetail](
  [Id] [bigint] NOT NULL,
  [DateCreated] DATETIME NOT NULL CONSTRAINT "DF_RMD_DateCreated" DEFAULT CURRENT_TIMESTAMP,
  -- TODO: Remove MatchData in time:
  [MatchData] varbinary(64) NULL,
  [CustomerId] int NOT NULL,
  [HashedValue] varbinary(64) NOT NULL,
  [HashedNoteDataValue] varbinary(64) NULL,
  [RuleTriggersData] [VarBinary](Max) NULL,
  [CountryInputType] TINYINT NOT NULL CONSTRAINT "DF_RMD_CountryInputType" DEFAULT 0,
  [OriginalId] BIGINT NULL,
CONSTRAINT [PK_dbo.ResultsMatchDetails] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO

CREATE NONCLUSTERED INDEX [IX_RM_Detail_CustomerId] ON [dbo].[ResultMatchDetail]
(
	[CustomerId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMatchNoteDataHash
-- ----------------------------------------------------------------------------
CREATE TABLE [ResultMatchNoteDataHash] (
  CustomerId int NOT NULL,
  HashedValue varbinary(64) NOT NULL,
  ResultMatchNoteDataId BIGINT NULL,
  [OriginalId] BIGINT NULL,
CONSTRAINT [PK_dbo.ResultMatchNoteDataHash] PRIMARY KEY CLUSTERED
(
	[CustomerId] ASC,
	[HashedValue] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
);
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMatchNoteData
-- ----------------------------------------------------------------------------
CREATE TABLE [ResultMatchNoteData]
(
  Id BIGINT NOT NULL IDENTITY(1,1) PRIMARY KEY,
  DateCreated DATETIME NOT NULL,
  CustomerId INT NOT NULL,
  HashedValue varbinary(64) NULL,
  NoteData IMAGE NULL,
  [OriginalId] BIGINT NULL,
);
GO

CREATE NONCLUSTERED INDEX [IX_RM_ResultMatchNoteData_CustomerId_HashedValue] ON [dbo].[ResultMatchNoteData]
(
	[CustomerId] ASC,
	[HashedValue] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMatchUniqueHash
-- ----------------------------------------------------------------------------
CREATE TABLE [ResultMatchUniqueHash] (
  CustomerId int NOT NULL,
  HashedValue varbinary(64) NOT NULL,
  ResultMatchUniqueDetailId BIGINT NULL,
  [OriginalId] BIGINT NULL,
CONSTRAINT [PK_dbo.ResultMatchUniqueHash] PRIMARY KEY CLUSTERED
(
	[CustomerId] ASC,
	[HashedValue] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
);
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMatchUniqueDetail
-- ----------------------------------------------------------------------------
CREATE TABLE [ResultMatchUniqueDetail]
(
  Id BIGINT NOT NULL IDENTITY(1,1) PRIMARY KEY,
  DateCreated DATETIME NOT NULL,
  CustomerId INT NOT NULL,
  HashedValue varbinary(64) NULL,
  MatchData IMAGE NULL,
  [OriginalId] BIGINT NULL,
);
GO

CREATE NONCLUSTERED INDEX [IX_RM_UniqueDetail_CustomerId_HashedValue] ON [dbo].[ResultMatchUniqueDetail]
(
	[CustomerId] ASC,
	[HashedValue] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO


-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMatchFprDetail
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[ResultMatchFprDetail]
(
[Id] BIGINT NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT "DF_ResultMatchFprDetail_DateCreated" DEFAULT CURRENT_TIMESTAMP,
[CustomerId] INT NOT NULL,  
[IsFprFalsePositive] [bit] NOT NULL,   
[Probability] REAL NOT NULL,   
[ReasonCodes] [VARCHAR](255) NULL,  
[OriginalId] BIGINT NULL,  
CONSTRAINT [PK_ResultMatchFprDetail] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultOfacInstitutionInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultOfacInstitutionInfo]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultOfacInstitutionInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Address] [nvarchar](512) NULL,
	[Name] [nvarchar](1000) NULL,
	[Type] [int] NOT NULL,
	[OfacReport_Id] [bigint] NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultOfacInstitutionInfo_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsOfacInstitutionInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_OfacReport_Id] ON [dbo].[ResultOfacInstitutionInfo]
(
	[OfacReport_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultOfacInstitutionInfo_CustomerId] ON [dbo].[ResultOfacInstitutionInfo] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdInternationalRiskIndicator
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdInternationalRiskIndicator]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdInternationalRiskIndicator](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Code] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
	[InstantIdInternationalResult_Id] [bigint] NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdInternationalRiskIndicator_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdInternationalRiskIndicator] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdInternationalResult_Id] ON [dbo].[ResultInstantIdInternationalRiskIndicator]
(
	[InstantIdInternationalResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdInternationalRiskIndicator_CustomerId] ON [dbo].[ResultInstantIdInternationalRiskIndicator] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdInternationalDatasourceResult
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdInternationalDatasourceResult]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdInternationalDatasourceResult](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Status] [int] NOT NULL,
	[InstantIdInternationalResult_Id] [bigint] NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdInternationalDatasourceResult_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultInstantIdInternationalDatasourceResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdInternationalResult_Id] ON [dbo].[ResultInstantIdInternationalDatasourceResult]
(
	[InstantIdInternationalResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdInternationalDatasourceResult_CustomerId] ON [dbo].[ResultInstantIdInternationalDatasourceResult] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO


-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdInternationalInputData
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdInternationalInputData]    Script Date: 05/16/2014 13:26:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ResultInstantIdInternationalInputData](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Name] [nvarchar](150) NOT NULL,
	[Value] [nvarchar](1000) NULL,
	[InstantIdInternationalResult_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdInternationalInputData_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultInstantIdInternationalInputData] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdInternationalResult_Id] ON [dbo].[ResultInstantIdInternationalInputData]
(
	[InstantIdInternationalResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdInternationalInputData_CustomerId] ON [dbo].[ResultInstantIdInternationalInputData] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdInternationalDatasourceField
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdInternationalDatasourceField]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdInternationalDatasourceField](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Status] [int] NOT NULL,
	[InstantIdInternationalDatasourceResult_Id] [bigint] NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdInternationalDatasourceField_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultInstantIdInternationalDatasourceField] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdInternationalDatasourceResult_Id] ON [dbo].[ResultInstantIdInternationalDatasourceField]
(
	[InstantIdInternationalDatasourceResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdInternationalDatasourceField_CustomerId] ON [dbo].[ResultInstantIdInternationalDatasourceField] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdInternationalAppendedField
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdInternationalAppendedField]    Script Date: 05/29/2014 09:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdInternationalAppendedField](
       [Id] [bigint] IDENTITY(2,2) NOT NULL,
       [FieldType] [int] NOT NULL,
       [Value] [nvarchar](512) NOT NULL,
       [InstantIdInternationalDatasourceResult_Id] [bigint] NULL,
       [DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	   [CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdInternationalAppendedField_CustomerId DEFAULT 0,
	   [OriginalId] BIGINT NULL,
CONSTRAINT [PK_dbo.ResultInstantIdInternationalAppendedField] PRIMARY KEY CLUSTERED
(
       [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdInternationalDatasourceResult_Id] ON [dbo].[ResultInstantIdInternationalAppendedField]
(
       [InstantIdInternationalDatasourceResult_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdInternationalAppendedField_CustomerId] ON [dbo].[ResultInstantIdInternationalAppendedField] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultInstantIdIndividualRedFlagRiskIndicator
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultInstantIdIndividualRedFlagRiskIndicator]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultInstantIdIndividualRedFlagRiskIndicator](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Code] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
	[InstantIdIndividualRedFlag_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultInstantIdIndividualRedFlagRiskIndicator_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsInstantIdIndividualRedFlagRiskIndicator] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InstantIdIndividualRedFlag_Id] ON [dbo].[ResultInstantIdIndividualRedFlagRiskIndicator]
(
	[InstantIdIndividualRedFlag_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultInstantIdIndividualRedFlagRiskIndicator_CustomerId] ON [dbo].[ResultInstantIdIndividualRedFlagRiskIndicator] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultFraudPointRedFlagRiskIndicator
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultFraudPointRedFlagRiskIndicator]    Script Date: 08/22/2013 16:01:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultFraudPointRedFlagRiskIndicator](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[Code] [int] NOT NULL,
	[GeneratedAlert] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
	[FraudPointRedFlag_Id] [bigint] NOT NULL,
	[DateCreated] [datetime] NOT NULL DEFAULT GETDATE(),
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultFraudPointRedFlagRiskIndicator_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_dbo.ResultsFraudPointRedFlagRiskIndicator] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_FraudPointRedFlag_Id] ON [dbo].[ResultFraudPointRedFlagRiskIndicator]
(
	[FraudPointRedFlag_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_ResultFraudPointRedFlagRiskIndicator_CustomerId] ON [dbo].[ResultFraudPointRedFlagRiskIndicator] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultProviderLegacy
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultProviderLegacy]    Script Date: 9/20/2013 10:13:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultProviderLegacy](
	[legacy_result_id] [int] IDENTITY(2,2) NOT NULL,
	[result_id] [int] NULL,
	[run_id] [int] NULL,
	[customer_id] [varchar](100) NULL,
	[html_out] [varchar](max) NULL,
	[entity_type_id] [int] NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultProviderLegacy_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_client1_results_legacy] PRIMARY KEY CLUSTERED
(
	[legacy_result_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultProviderLegacy_CustomerId] ON [dbo].[ResultProviderLegacy] 
(
	[CustomerId] ASC,	
	[legacy_result_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultWCResult
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultWCResult]    Script Date: 12/10/2013 12:15:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ResultWCResult](
	[Id] [bigint] NOT NULL,
	[ErrorMessage] [nvarchar](1024) NULL,
	[WarningMessage] [nvarchar](1024) NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultWCResult_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_ResultsWCResult] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_ResultWCResult_CustomerId] ON [dbo].[ResultWCResult] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultWCMatchOccurrence
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[ResultWCMatchOccurrence](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[IsAutomaticFalsePositive] [bit] NULL,
	[IsFalsePositive] [bit] NULL,
	[Ent_ID] [int] NULL,
	[IsMatch] [bit] NULL,
	[DisplayState] [int] NULL,
	[Score] [int] NULL,
	[WCResult_Id] [bigint] NULL,
	[Collapsed] [bit] NULL,
	[Name] [nvarchar](1000) NULL,
	[FirstName] [nvarchar](255) NULL,
	[LastName] [nvarchar](255) NULL,
	[OriginalName] [nvarchar](1000) NULL,
	[OriginalName2] [nvarchar](1000) NULL,
	[OriginalName3] [nvarchar](1000) NULL,
	[NameSource] [nvarchar](255) NULL,
	[EntityType] [int] NULL,
	[EntryCategory] [nvarchar](255) NULL,
	[Positions] [nvarchar](255) NULL,
	[Remarks] [ntext] NULL,
	[DOB] [nvarchar](50) NULL,
	[POB] [nvarchar](255) NULL,
	[Country] [nvarchar](100) NULL,
	[DateEntered] [datetime] NULL,
	[DateUpdated] [datetime] NULL,
	[SourceWebLink] [text] NULL,
	[PassportID] [varchar](255) NULL,
	[NationalID] [varchar](255) NULL,
	[Gender] [int] NULL,
	[CustomerId] INT NOT NULL CONSTRAINT DF_ResultWCMatchOccurrence_CustomerId DEFAULT 0,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_ResultsWCMatchOccurrence] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_ResultWCMatchOccurrence_CustomerId] ON [dbo].[ResultWCMatchOccurrence] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.Rule
-- ----------------------------------------------------------------------------
SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[Rule](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](255) NULL,
	[Expression] [nvarchar](max) NOT NULL,
	[Function] [varbinary](max) NULL,
	[CultureInfo] [nvarchar](100) NOT NULL,
	[GroupId] [BINARY](16) NOT NULL,
	[VersionTimeStamp] [datetime] NOT NULL,
	[VersionId] [int] NOT NULL,
	[Status] [int] NOT NULL,
	[CreatedBy] [nvarchar](50) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[Comment] [nvarchar] (512) NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_RuleEngineRules_1] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.RuleSet
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[RuleSet](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[GroupId] [BINARY](16) NOT NULL,
	[VersionTimeStamp] [datetime] NOT NULL,
	[Active] [bit] NOT NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_RuleEngineRuleSets] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.RuleEngineLookup
-- ----------------------------------------------------------------------------

CREATE TABLE [dbo].[RuleEngineLookup](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[RuleSetId] [int] NOT NULL,
	[RuleId] [int] NOT NULL,
	[RuleSearchInfoId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[RuleOrder] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [nvarchar](50) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_RuleEngineRuleLookup] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.RuleSearchInfo
-- ----------------------------------------------------------------------------

CREATE TABLE [dbo].[RuleSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[PredefinedSearchUniqueId] [BINARY](16) NOT NULL,
	[PredefinedSearchName] [nvarchar](255) NOT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
 CONSTRAINT [PK_RuleSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultEFTField
-- ----------------------------------------------------------------------------

CREATE TABLE [dbo].[ResultEFTField](
     [Id] [bigint] IDENTITY(2,2) NOT NULL,
     [ResultSetId] [bigint] NOT NULL,
     [Tag] [nvarchar] (20) NULL,
     [Sequence] [nvarchar] (20) NULL,
     [SubSequence] [nvarchar] (20) NULL,
     [Qualifier] [nvarchar] (50) NULL,
     [XPath] [nvarchar] (500) NULL,
     [RecordTypeCode] [nvarchar] (20) NULL,
     [AddendaTypeCode] [nvarchar] (20) NULL,
     [Value] [nvarchar] (500) NULL,
	 [CustomerId] INT NOT NULL CONSTRAINT DF_ResultEFTField_CustomerId DEFAULT 0,
	 [OriginalId] BIGINT NULL,
	 [DateCreated] [datetime] NOT NULL,
 CONSTRAINT [PK_ResultEFTField] PRIMARY KEY CLUSTERED
 (
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
CREATE NONCLUSTERED INDEX [IX_ResultEFTField_CustomerId] ON [dbo].[ResultEFTField] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

SET ANSI_PADDING OFF
GO

/* ALTER TABLE [dbo].[RuleEngineLookup]  WITH CHECK ADD  CONSTRAINT [FK__RuleEngineLookup_dbo.RuleSearchInfo__Id] FOREIGN KEY([RuleSearchInfoId])
REFERENCES [dbo].[RuleSearchInfo] ([Id])
GO
ALTER TABLE [dbo].[RuleEngineLookup] CHECK CONSTRAINT [FK__RuleEngineLookup_dbo.RuleSearchInfo__Id]
GO */

/* ALTER TABLE [dbo].[RuleEngineLookup]  WITH CHECK ADD  CONSTRAINT [FK__RuleEngineLookup_dbo.Rule__RuleId] FOREIGN KEY([RuleID])
REFERENCES [dbo].[Rule] ([Id])
GO
ALTER TABLE [dbo].[RuleEngineLookup] CHECK CONSTRAINT [FK__RuleEngineLookup_dbo.Rule__RuleId]
GO */

/* ALTER TABLE [dbo].[RuleEngineLookup]  WITH CHECK ADD  CONSTRAINT [FK__RuleEngineLookup_dbo.RuleSet__RuleSetId] FOREIGN KEY([RuleSetID])
REFERENCES [dbo].[RuleSet] ([Id])
GO
ALTER TABLE [dbo].[RuleEngineLookup] CHECK CONSTRAINT [FK__RuleEngineLookup_dbo.RuleSet__RuleSetId]
GO */

/****** Object:  ForeignKey [FK_dbo.ResultsAdditionalLastName_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultAdditionalLastName]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsAdditionalLastName_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id] FOREIGN KEY([InstantIdIndividualResult_Id])
REFERENCES [dbo].[ResultInstantIdIndividualResult] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultAdditionalLastName] CHECK CONSTRAINT [FK_dbo.ResultsAdditionalLastName_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsAlertAttachment_dbo.ResultRecord_ResultRecordId]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultAlertAttachment]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsAlertAttachment_dbo.ResultRecord_ResultRecordId] FOREIGN KEY([ResultRecordId])
REFERENCES [dbo].[ResultRecord] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultAlertAttachment] CHECK CONSTRAINT [FK_dbo.ResultsAlertAttachment_dbo.ResultRecord_ResultRecordId]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsAlertDecisionRoleRestriction_dbo.ResultsAlertDecision_AlertDecision_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultAlertDecisionRoleRestriction]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsAlertDecisionRoleRestriction_dbo.ResultsAlertDecision_AlertDecision_Id] FOREIGN KEY([AlertDecision_Id])
REFERENCES [dbo].[ResultAlertDecision] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultAlertDecisionRoleRestriction] CHECK CONSTRAINT [FK_dbo.ResultsAlertDecisionRoleRestriction_dbo.ResultsAlertDecision_AlertDecision_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsAlertFilterRoleRestriction_dbo.ResultsAlertFilter_AlertFilter_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultAlertFilterRoleRestriction]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsAlertFilterRoleRestriction_dbo.ResultsAlertFilter_AlertFilter_Id] FOREIGN KEY([AlertFilter_Id])
REFERENCES [dbo].[ResultAlertFilter] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultAlertFilterRoleRestriction] CHECK CONSTRAINT [FK_dbo.ResultsAlertFilterRoleRestriction_dbo.ResultsAlertFilter_AlertFilter_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsAuditRecord_dbo.ResultRecord_ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultAuditRecord]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsAuditRecord_dbo.ResultRecord_ResultRecord_Id] FOREIGN KEY([ResultRecord_Id])
REFERENCES [dbo].[ResultRecord] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultAuditRecord] CHECK CONSTRAINT [FK_dbo.ResultsAuditRecord_dbo.ResultRecord_ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsBlockReference_dbo.ResultSet_ResultSet_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultBlockReference]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsBlockReference_dbo.ResultSet_ResultSet_Id] FOREIGN KEY([ResultSet_Id])
REFERENCES [dbo].[ResultSet] ([Id])
GO
ALTER TABLE [dbo].[ResultBlockReference] CHECK CONSTRAINT [FK_dbo.ResultsBlockReference_dbo.ResultSet_ResultSet_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsBlockReference_dbo.ResultSet_ResultSet_Id1]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultBlockReference]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsBlockReference_dbo.ResultSet_ResultSet_Id1] FOREIGN KEY([ResultSet_Id1])
REFERENCES [dbo].[ResultSet] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultBlockReference] CHECK CONSTRAINT [FK_dbo.ResultsBlockReference_dbo.ResultSet_ResultSet_Id1]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsBusinessInfo_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultBusinessInfo]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsBusinessInfo_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id] FOREIGN KEY([InstantIdBusinessResultId])
REFERENCES [dbo].[ResultInstantIdBusinessResult] ([Id])
GO
ALTER TABLE [dbo].[ResultBusinessInfo] CHECK CONSTRAINT [FK_dbo.ResultsBusinessInfo_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsChronologyHistory_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultChronologyHistory]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsChronologyHistory_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id] FOREIGN KEY([InstantIdIndividualResult_Id])
REFERENCES [dbo].[ResultInstantIdIndividualResult] ([Id])
GO
ALTER TABLE [dbo].[ResultChronologyHistory] CHECK CONSTRAINT [FK_dbo.ResultsChronologyHistory_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsDivisionRestriction_dbo.ResultsAlertDecision_AlertDecision_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultDivisionRestriction]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsDivisionRestriction_dbo.ResultsAlertDecision_AlertDecision_Id] FOREIGN KEY([AlertDecision_Id])
REFERENCES [dbo].[ResultAlertDecision] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultDivisionRestriction] CHECK CONSTRAINT [FK_dbo.ResultsDivisionRestriction_dbo.ResultsAlertDecision_AlertDecision_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsEFTRecord_dbo.ResultSet_ResultSetId]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultEFTRecord]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsEFTRecord_dbo.ResultSet_ResultSetId] FOREIGN KEY([ResultSetId])
REFERENCES [dbo].[ResultSet] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultEFTRecord] CHECK CONSTRAINT [FK_dbo.ResultsEFTRecord_dbo.ResultSet_ResultSetId]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsEntityAdditionalInfo_dbo.ResultsInputEntity_InputEntity_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultEntityAdditionalInfo]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsEntityAdditionalInfo_dbo.ResultsInputEntity_InputEntity_Id] FOREIGN KEY([InputEntity_Id])
REFERENCES [dbo].[ResultInputEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultEntityAdditionalInfo] CHECK CONSTRAINT [FK_dbo.ResultsEntityAdditionalInfo_dbo.ResultsInputEntity_InputEntity_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsEntityAddress_dbo.ResultsInputEntity_InputEntity_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultEntityAddress]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsEntityAddress_dbo.ResultsInputEntity_InputEntity_Id] FOREIGN KEY([InputEntity_Id])
REFERENCES [dbo].[ResultInputEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultEntityAddress] CHECK CONSTRAINT [FK_dbo.ResultsEntityAddress_dbo.ResultsInputEntity_InputEntity_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsEntityPhoneNumber_dbo.ResultsInputEntity_InputEntity_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultEntityPhoneNumber]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsEntityPhoneNumber_dbo.ResultsInputEntity_InputEntity_Id] FOREIGN KEY([InputEntity_Id])
REFERENCES [dbo].[ResultInputEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultEntityPhoneNumber] CHECK CONSTRAINT [FK_dbo.ResultsEntityPhoneNumber_dbo.ResultsInputEntity_InputEntity_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsFactivaMediaResult_dbo.ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultFactivaMediaResult]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsFactivaMediaResult_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
GO
ALTER TABLE [dbo].[ResultFactivaMediaResult] CHECK CONSTRAINT [FK_dbo.ResultsFactivaMediaResult_dbo.ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsFraudPointRedFlag_dbo.ResultsFraudPointResult_FraudPointResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultFraudPointRedFlag]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsFraudPointRedFlag_dbo.ResultsFraudPointResult_FraudPointResult_Id] FOREIGN KEY([FraudPointResult_Id])
REFERENCES [dbo].[ResultFraudPointResult] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultFraudPointRedFlag] CHECK CONSTRAINT [FK_dbo.ResultsFraudPointRedFlag_dbo.ResultsFraudPointResult_FraudPointResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsFraudPointRedFlagRiskIndicator_dbo.ResultsFraudPointRedFlag_FraudPointRedFlag_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultFraudPointRedFlagRiskIndicator]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsFraudPointRedFlagRiskIndicator_dbo.ResultsFraudPointRedFlag_FraudPointRedFlag_Id] FOREIGN KEY([FraudPointRedFlag_Id])
REFERENCES [dbo].[ResultFraudPointRedFlag] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultFraudPointRedFlagRiskIndicator] CHECK CONSTRAINT [FK_dbo.ResultsFraudPointRedFlagRiskIndicator_dbo.ResultsFraudPointRedFlag_FraudPointRedFlag_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsFraudPointResult_dbo.ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultFraudPointResult]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsFraudPointResult_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
GO
ALTER TABLE [dbo].[ResultFraudPointResult] CHECK CONSTRAINT [FK_dbo.ResultsFraudPointResult_dbo.ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsFraudPointRiskIndicator_dbo.ResultsFraudPointResult_FraudPointResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultFraudPointRiskIndicator]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsFraudPointRiskIndicator_dbo.ResultsFraudPointResult_FraudPointResult_Id] FOREIGN KEY([FraudPointResult_Id])
REFERENCES [dbo].[ResultFraudPointResult] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultFraudPointRiskIndicator] CHECK CONSTRAINT [FK_dbo.ResultsFraudPointRiskIndicator_dbo.ResultsFraudPointResult_FraudPointResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInputEntityIdentification_dbo.ResultsInputEntity_InputEntity_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInputEntityIdentification]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInputEntityIdentification_dbo.ResultsInputEntity_InputEntity_Id] FOREIGN KEY([InputEntity_Id])
REFERENCES [dbo].[ResultInputEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultInputEntityIdentification] CHECK CONSTRAINT [FK_dbo.ResultsInputEntityIdentification_dbo.ResultsInputEntity_InputEntity_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdBusinessRedFlag_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdBusinessRedFlag]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdBusinessRedFlag_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id] FOREIGN KEY([InstantIdBusinessResult_Id])
REFERENCES [dbo].[ResultInstantIdBusinessResult] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultInstantIdBusinessRedFlag] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdBusinessRedFlag_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdBusinessRedFlagRiskIndicator_dbo.ResultsInstantIdBusinessRedFlag_InstantIdBusinessRedFlag_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdBusinessRedFlagRiskIndicator]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdBusinessRedFlagRiskIndicator_dbo.ResultsInstantIdBusinessRedFlag_InstantIdBusinessRedFlag_Id] FOREIGN KEY([InstantIdBusinessRedFlag_Id])
REFERENCES [dbo].[ResultInstantIdBusinessRedFlag] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultInstantIdBusinessRedFlagRiskIndicator] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdBusinessRedFlagRiskIndicator_dbo.ResultsInstantIdBusinessRedFlag_InstantIdBusinessRedFlag_Id]
GO */

/* ALTER TABLE [dbo].[ResultInstantIdBusinessResult]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdBusinessResult_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
GO
ALTER TABLE [dbo].[ResultInstantIdBusinessResult] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdBusinessResult_dbo.ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdBusinessRiskIndicator_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdBusinessRiskIndicator]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdBusinessRiskIndicator_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id] FOREIGN KEY([InstantIdBusinessResult_Id])
REFERENCES [dbo].[ResultInstantIdBusinessResult] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultInstantIdBusinessRiskIndicator] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdBusinessRiskIndicator_dbo.ResultsInstantIdBusinessResult_InstantIdBusinessResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdIndividualRedFlag_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdIndividualRedFlag]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdIndividualRedFlag_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id] FOREIGN KEY([InstantIdIndividualResult_Id])
REFERENCES [dbo].[ResultInstantIdIndividualResult] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultInstantIdIndividualRedFlag] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdIndividualRedFlag_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdIndividualRedFlagRiskIndicator_dbo.ResultsInstantIdIndividualRedFlag_InstantIdIndividualRedFlag_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdIndividualRedFlagRiskIndicator]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdIndividualRedFlagRiskIndicator_dbo.ResultsInstantIdIndividualRedFlag_InstantIdIndividualRedFlag_Id] FOREIGN KEY([InstantIdIndividualRedFlag_Id])
REFERENCES [dbo].[ResultInstantIdIndividualRedFlag] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultInstantIdIndividualRedFlagRiskIndicator] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdIndividualRedFlagRiskIndicator_dbo.ResultsInstantIdIndividualRedFlag_InstantIdIndividualRedFlag_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdIndividualResult_dbo.ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdIndividualResult]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdIndividualResult_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
GO
ALTER TABLE [dbo].[ResultInstantIdIndividualResult] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdIndividualResult_dbo.ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdIndividualRiskIndicator_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdIndividualRiskIndicator]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdIndividualRiskIndicator_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id] FOREIGN KEY([InstantIdIndividualResult_Id])
REFERENCES [dbo].[ResultInstantIdIndividualResult] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultInstantIdIndividualRiskIndicator] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdIndividualRiskIndicator_dbo.ResultsInstantIdIndividualResult_InstantIdIndividualResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdInternationalResult_dbo.ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdInternationalResult]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdInternationalResult_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
GO
ALTER TABLE [dbo].[ResultInstantIdInternationalResult] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdInternationalResult_dbo.ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsInstantIdInternationalRiskIndicator_dbo.ResultsInstantIdInternationalResult_InstantIdInternationalResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultInstantIdInternationalRiskIndicator]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsInstantIdInternationalRiskIndicator_dbo.ResultsInstantIdInternationalResult_InstantIdInternationalResult_Id] FOREIGN KEY([InstantIdInternationalResult_Id])
REFERENCES [dbo].[ResultInstantIdInternationalResult] ([Id])
GO
ALTER TABLE [dbo].[ResultInstantIdInternationalRiskIndicator] CHECK CONSTRAINT [FK_dbo.ResultsInstantIdInternationalRiskIndicator_dbo.ResultsInstantIdInternationalResult_InstantIdInternationalResult_Id]
GO
ALTER TABLE [dbo].[ResultInstantIdInternationalInputData]  WITH CHECK ADD  CONSTRAINT [FK_ResultInstantIdInternationalInputData_ResultInstantIdInternationalResult] FOREIGN KEY([InstantIdInternationalResult_Id])
REFERENCES [dbo].[ResultInstantIdInternationalResult] ([Id])
GO
ALTER TABLE [dbo].[ResultInstantIdInternationalDatasourceResult]  WITH CHECK ADD  CONSTRAINT [FK_ResultInstantIdInternationalDatasourceResult_ResultInstantIdInternationalResult] FOREIGN KEY([InstantIdInternationalResult_Id])
REFERENCES [dbo].[ResultInstantIdInternationalResult] ([Id])
GO
ALTER TABLE [dbo].[ResultInstantIdInternationalDatasourceField]  WITH CHECK ADD  CONSTRAINT [FK_ResultInstantIdInternationalDatasourceField_ResultInstantIdInternationalDatasourceResult] FOREIGN KEY([InstantIdInternationalDatasourceResult_Id])
REFERENCES [dbo].[ResultInstantIdInternationalDatasourceResult] ([Id])
GO
ALTER TABLE [dbo].[ResultInstantIdInternationalAppendedField]  WITH CHECK ADD  CONSTRAINT [FK_ResultInstantIdInternationalAppendedField_ResultInstantIdInternationalDatasourceResult] FOREIGN KEY([InstantIdInternationalDatasourceResult_Id])
REFERENCES [dbo].[ResultInstantIdInternationalDatasourceResult] ([Id])
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsLexisNexisNewsResult_dbo.ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultLexisNexisNewsResult]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsLexisNexisNewsResult_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
GO
ALTER TABLE [dbo].[ResultLexisNexisNewsResult] CHECK CONSTRAINT [FK_dbo.ResultsLexisNexisNewsResult_dbo.ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsMatch_dbo.ResultsWatchListResult_WatchListResult_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultMatch]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsMatch_dbo.ResultsWatchListResult_WatchListResult_Id] FOREIGN KEY([WatchListResult_Id])
REFERENCES [dbo].[ResultWatchListResult] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultMatch] CHECK CONSTRAINT [FK_dbo.ResultsMatch_dbo.ResultsWatchListResult_WatchListResult_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsOfacInstitutionInfo_dbo.ResultsOfacReport_OfacReport_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultOfacInstitutionInfo]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsOfacInstitutionInfo_dbo.ResultsOfacReport_OfacReport_Id] FOREIGN KEY([OfacReport_Id])
REFERENCES [dbo].[ResultOfacReport] ([Id])
GO
ALTER TABLE [dbo].[ResultOfacInstitutionInfo] CHECK CONSTRAINT [FK_dbo.ResultsOfacInstitutionInfo_dbo.ResultsOfacReport_OfacReport_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsOfacReport_dbo.ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultOfacReport]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsOfacReport_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
GO
ALTER TABLE [dbo].[ResultOfacReport] CHECK CONSTRAINT [FK_dbo.ResultsOfacReport_dbo.ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsOfacReport_dbo.ResultRecord_ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultOfacReport]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsOfacReport_dbo.ResultRecord_ResultRecord_Id] FOREIGN KEY([ResultRecord_Id])
REFERENCES [dbo].[ResultRecord] ([Id])
GO
ALTER TABLE [dbo].[ResultOfacReport] CHECK CONSTRAINT [FK_dbo.ResultsOfacReport_dbo.ResultRecord_ResultRecord_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsPredefinedSearchRestriction_dbo.ResultsAlertDecision_AlertDecision_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultPredefinedSearchRestriction]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsPredefinedSearchRestriction_dbo.ResultsAlertDecision_AlertDecision_Id] FOREIGN KEY([AlertDecision_Id])
REFERENCES [dbo].[ResultAlertDecision] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultPredefinedSearchRestriction] CHECK CONSTRAINT [FK_dbo.ResultsPredefinedSearchRestriction_dbo.ResultsAlertDecision_AlertDecision_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultRecord_dbo.ResultsInputEntity_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultRecord]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultRecord_dbo.ResultsInputEntity_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultInputEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultRecord] CHECK CONSTRAINT [FK_dbo.ResultRecord_dbo.ResultsInputEntity_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultRecord_dbo.ResultSet_ResultSetId]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultRecord]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultRecord_dbo.ResultSet_ResultSetId] FOREIGN KEY([ResultSetId])
REFERENCES [dbo].[ResultSet] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultRecord] CHECK CONSTRAINT [FK_dbo.ResultRecord_dbo.ResultSet_ResultSetId]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultRecord_dbo.ResultStatus_ResultStatus_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultRecord]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultRecord_dbo.ResultStatus_ResultStatus_Id] FOREIGN KEY([ResultStatus_Id])
REFERENCES [dbo].[ResultStatus] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultRecord] CHECK CONSTRAINT [FK_dbo.ResultRecord_dbo.ResultStatus_ResultStatus_Id]
GO */
/****** Object:  ForeignKey [FK_dbo.ResultsWatchListResult_dbo.ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultWatchListResult]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsWatchListResult_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultWatchListResult] CHECK CONSTRAINT [FK_dbo.ResultsWatchListResult_dbo.ResultRecord_Id]
GO */

/****** Object:  ForeignKey [FK_dbo.ResultsWCResult_dbo.ResultRecord_Id]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultWCResult]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultsWCResult_dbo.ResultRecord_Id] FOREIGN KEY([Id])
REFERENCES [dbo].[ResultRecord] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResultWCResult] CHECK CONSTRAINT [FK_dbo.ResultsWCResult_dbo.ResultRecord_Id]
GO */
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMultAlertProcInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultMultAlertProcInfo]    Script Date: 09/30/2014 18:40:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultMultAlertProcInfo](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[IsDeleted] [BIT] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfo_IsDeleted" DEFAULT(0),
	[CustomerId] [int] NOT NULL,
	[UserId] int NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[DateModified] [datetime] NOT NULL,
	[Name] [nvarchar](200) NULL,
	[DateSubmitted] [datetime] NOT NULL,
	[DateStarted] [datetime] NULL,
	[DateCompleted] [datetime] NULL,
	[Status] [int] NOT NULL,
	[HostName] [nvarchar](200) NULL,
	[EnvironmentType] [int] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfo_EnvironmentType" default(0),
	[Query_AlertFilterId] [int] NOT NULL,
	[Query_AlertFilterName] [nvarchar](100) NULL,
	[Query_TotalResultsToProcess] [bigint] NULL,
	[Query_MaxResultRecordId] [bigint] NOT NULL,
	[Decision_AlertDecisionId] [int] NOT NULL,
	[Decision_AlertDecisionName] [nvarchar](100) NULL,
	[Decision_NotifyAssignee] [bit] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfo_Decision_NotifyAssignee" default(0),
	[Decision_ResultStatusId] [int] NULL,
	[Decision_AlertState] [int] NOT NULL,
	[Decision_AcceptListId] [int] NULL,
	[Decision_AcceptListName] [nvarchar](100) NULL,
	[Decision_CustomWatchListId] [int] NULL,
	[Decision_CustomWatchListName] [nvarchar](100) NULL,
	[Decision_CustomWatchListReason] [nvarchar](255) NULL,
	[Decision_AssignedRoleIds] [nvarchar](500) NULL,
	[Decision_AssignedRoleName] [nvarchar](100) NULL,
	[Decision_AssignedUserIds] [nvarchar](500) NULL,
	[Decision_AssignedUserName] [nvarchar](100) NULL,
	[Decision_AssignedSelection] [int] NOT NULL,
	[Decision_NoteText] [ntext] NULL,
	[Decision_IsRuleAlert] [bit] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfo_Decision_IsRuleAlert" default(0),
	[Decision_TreatUnknownEntityTypeAsIndividual] [bit] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfo_TreatUnknownEntityTypeAsIndividual" default(1),
	[Counts_NumAlertsProcessed] [bigint] NULL,
	[Counts_TotalAlertsToProcess] [bigint] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfo_Counts_TotalAlertsToProcess" default(0),
	[Counts_Successful] [bigint] NULL,
	[Counts_NotProcessed] [bigint] NULL,
	[Counts_NotAddedToAcceptList] [bigint] NULL,
	[Counts_NotAddedToCwl] [bigint] NULL,
	[ReportExportRecord_Filename] [varchar](512) NULL,
	[ReportExportRecord_Transaction] [bit] NULL,
	[ReportExportRecord_MatchSort] [varchar](50) NULL,
	[ReportExportRecord_ReportExportType] [int] NOT NULL,
	[ReportExportRecord_ResultReportType] [int] NOT NULL,
	[ReportExportRecord_UserTimeOffSet] [int] NULL,
	[ReportExportRecord_CultureInfoName] [varchar](25) NULL,
	[ReportExportRecord_LanguageInfoName] [varchar](25) NULL,
	[ReportExportRecord_AcceptMediaType] [varchar](100) NULL,
	[ReportExportRecord_FileDropLocation] [varchar](512) NULL,
	[ReportExportRecord_TimeZoneId] varchar(255) DEFAULT NULL,
	[QueueProcessingType] [int] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfo_QueueProcessingType" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[ProcessingInfo] varbinary(max) NULL,
 CONSTRAINT [PK_dbo.ResultMultAlertProcInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [FK_ResultMAPInfo_AlertFilterId] ON [dbo].[ResultMultAlertProcInfo]
(
	[Query_AlertFilterId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [FK_ResultMAPInfo_AlertDecisionId] ON [dbo].[ResultMultAlertProcInfo]
(
	[Decision_AlertDecisionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CustomerId_IsDeleted] ON [dbo].[ResultMultAlertProcInfo]
(
	[CustomerId] ASC, [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMultAlertProcInfoAlert
-- ----------------------------------------------------------------------------

/****** Object:  Table [dbo].[ResultMultAlertProcInfoAlert]    Script Date: 09/30/2014 18:40:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultMultAlertProcInfoRecord](
	[ResultMultAlertProcInfoId] [bigint] NOT NULL,
	[ResultRecordId] [bigint] NOT NULL,
	[OrderIndex] [bigint] NOT NULL,
	[DateStarted] [datetime] NULL,
	[DateCompleted] [datetime] NULL,
	[Status] [int] NOT NULL,
	[ErrorMessage] [nvarchar](1024) NULL,
	[ValidationMessage] [nvarchar](1024) NULL,
	[ResultCreatedDate] [datetime] NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfoRecord_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
 CONSTRAINT [PK_dbo.ResultMultAlertProcInfoRecord] PRIMARY KEY CLUSTERED
(
	[ResultMultAlertProcInfoId] ASC,
	[ResultRecordId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultMultAlertProcInfoRecord_CustomerId] ON [dbo].[ResultMultAlertProcInfoRecord] 
(
	[CustomerId] ASC, [ResultRecordId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMultAlertProcData
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultMultAlertProcData]    Script Date: 01/03/2016 18:40:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultMultAlertProcData](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[ResultMultAlertProcInfoId] [bigint] NOT NULL,
	[IdsData] [varbinary](max) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NOT NULL,
	[DateModified] [datetime] NULL,
	[ModifiedBy]  VARCHAR(50) NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_ResultMultAlertProcData_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
 CONSTRAINT [PK_dbo.ResultMultAlertProcBlob] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultMultAlertProcData_CustomerId] ON [dbo].[ResultMultAlertProcData] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultMultAlertProcInfoQueue
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[ResultMultAlertProcInfoQueue]    Script Date: 09/30/2014 18:40:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ResultMultAlertProcInfoQueue](
	[ResultMultAlertProcInfoId] [bigint] NOT NULL,
	[DateQueued] [datetime] NOT NULL,
	[EnvironmentType] [INT] NOT NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_ResultMultAlertProcInfoQueue_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
 CONSTRAINT [PK_dbo.ResultMultAlertProcInfoQueue] PRIMARY KEY CLUSTERED
(
	[ResultMultAlertProcInfoId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_ResultMultAlertProcInfoQueue_CustomerId] ON [dbo].[ResultMultAlertProcInfoQueue] 
(
	[CustomerId] ASC, [ResultMultAlertProcInfoId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_PADDING OFF
GO

/****** Object:  ForeignKey [FK_dbo.ResultMultAlertProcInfoAlert_dbo.ResultMultAlertProcInfo_Id_ResultMultAlertProcInfoId]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultMultAlertProcInfoRecord]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultMultAlertProcInfoRecord_dbo.ResultMultAlertProcInfo_Id_ResultMultAlertProcInfoId] FOREIGN KEY([ResultMultAlertProcInfoId])
REFERENCES [dbo].[ResultMultAlertProcInfo] ([Id])
ON DELETE CASCADE
GO */

/****** Object:  ForeignKey [FK_dbo.ResultMultAlertProcInfoQueue_dbo.ResultMultAlertProcInfo_Id_ResultMultAlertProcInfoId]    Script Date: 08/22/2013 16:01:15 ******/
/* ALTER TABLE [dbo].[ResultMultAlertProcInfoQueue]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultMultAlertProcInfoQueue_dbo.ResultMultAlertProcInfo_Id_ResultMultAlertProcInfoId] FOREIGN KEY([ResultMultAlertProcInfoId])
REFERENCES [dbo].[ResultMultAlertProcInfo] ([Id])
ON DELETE CASCADE
GO */


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create VIEW [dbo].[ResultsCriteriaView]
AS
SELECT
	ResultRecord.Id As ResultRecord__Id,
	ResultRecord.DateCreated As ResultRecord__Date,
	ResultRecord.Account_Amount AS ResultRecord__Account_Amount,
	ResultRecord.Account_Date AS ResultRecord__Account_Date,
	ResultRecord.Account_GroupId AS ResultRecord__Account_GroupId,
	ResultRecord.AccountId AS ResultRecord__AccountId,
	ResultRecord.Account_MemberId AS ResultRecord__Account_MemberId,
	ResultRecord.Account_OtherData AS ResultRecord__Account_OtherData,
	ResultRecord.Account_ProviderId AS ResultRecord__Account_ProviderId,
	ResultRecord.Account_Type AS ResultRecord__Account_Type,

	--- These child tables no longer exist
	-- ResultMatchDescription.Type AS ResultMatchAdditionalInfo__Type,
	-- ResultMatchDescription.Value AS ResultMatchAdditionalInfo__Value,
	-- ResultMatchDescription.Value AS ResultMatchAdditionalInfo__ParsedValue,
	---
	-- ResultMatchAddress.City AS ResultMatchAddress__City,
	-- ResultMatchAddress.Country AS ResultMatchAddress__Country,
	-- --ResultMatchAddress.Phone AS ResultMatchAddress__Phone,
	-- ResultMatchAddress.PostalCode AS ResultMatchAddress__PostalCode,
	-- ResultMatchAddress.State AS ResultMatchAddress__State,
	-- ResultMatchAddress.Street1 AS ResultMatchAddress__Street1,
	-- ResultMatchAddress.Street2 AS ResultMatchAddress__Street2,
	---
	ResultMatch.Date AS ResultMatch__Date,
	ResultMatch.Type AS ResultMatch__Type,
	ResultMatch.Name_First AS ResultMatch__Name_First,
	ResultMatch.Name_Full AS ResultMatch__Name_Full,
	ResultMatch.Name_Last AS ResultMatch__Name_Last,
	ResultMatch.Name_Middle AS ResultMatch__Name_Middle,
	ResultMatch.BestNameMatch AS ResultMatch__BestNameMatch,
	---
	ResultEFTRecord.Amount AS ResultEFTRecord__Amount,
	--ResultEFTRecord.DUNS AS ResultEFTRecord__DUNS,
	ResultEFTRecord.OFACIndicator AS ResultEFTRecord__OFACIndicator,
	ResultEFTRecord.TransactionId AS ResultEFTRecord__TransactionId,
	ResultEFTRecord.Type AS ResultEFTRecord__Type,
	---
	ResultFraudPointResult.ErrorMessage AS ResultFraudPointResult__ErrorMessage,
	--ResultFraudPointResult.ProviderErrorOnly AS ResultFraudPointResult__ProviderErrorOnly,
	ResultFraudPointResult.Score AS ResultFraudPointResult__Score,
	---
	ResultFraudPointRedFlag.Category AS ResultFraudPointRedFlag__Category,
	---
	ResultFraudPointRedFlagRiskIndicator.Code AS ResultFraudPointRedFlagRiskIndicator__Code,
	---
	ResultFraudPointRiskIndicator.Code AS ResultFraudPointRiskIndicator__Code,
	---
	-- ResultMatchIdentification.Label AS ResultInputEntityIdentification__Label,
	-- ResultMatchIdentification.Number AS ResultInputEntityIdentification__Number,
	-- ResultMatchIdentification.Type AS ResultInputEntityIdentification__Type,
	---
	ResultInstantIdBusinessResult.[Index] AS ResultInstantIdBusinessResult__Index,
	---
	ResultInstantIdBusinessRiskIndicator.Code AS ResultInstantIdBusinessRiskIndicator__Code,
	---
	ResultInstantIdIndividualResult.[Index] AS ResultInstantIdIndividualResult__Index,
	ResultInstantIdIndividualResult.NAP AS ResultInstantIdIndividualResult__NAP,
	ResultInstantIdIndividualResult.NAS AS ResultInstantIdIndividualResult__NAS,
	---
	ResultInstantIdIndividualRedFlag.Category AS ResultInstantIdIndividualRedFlag__Category,
	ResultInstantIdIndividualRiskIndicator.Code AS ResultInstantIdIndividualRiskIndicator_Code,
	---
	ResultInstantIdIndividualRedFlagRiskIndicator.Code AS ResultInstantIdIndividualRedFlagRiskIndicator__Code,
	---
	ResultInstantIdIndividualResult.ErrorMessage AS ResultInstantIdIndividualResult__ErrorMessage,
	ResultInstantIdIndividualResult.ErrorCd AS ResultInstantIdIndividualResult__ErrorCd,
	--ResultInstantIdIndividualResult.ProviderErrorsOnly AS ResultInstantIdIndividualResult__ProviderErrorsOnly,
	---
	ResultInstantIdBusinessResult.ErrorMessage AS ResultInstantIdBusinessResult__ErrorMessage,
	ResultInstantIdBusinessResult.ErrorCd AS ResultInstantIdBusinessResult__ErrorCd,
	--ResultInstantIdBusinessResult.ProviderErrorsOnly AS ResultInstantIdBusinessResult__ProviderErrorsOnly,
	---
	ResultInstantIdInternationalResult.ErrorMessage AS ResultInstantIdInternationalResult__ErrorMessage,
	ResultInstantIdInternationalResult.ErrorCd AS ResultInstantIdInternationalResult__ErrorCd,
	--ResultInstantIdInternationalResult.ProviderErrorsOnly AS ResultInstantIdInternationalResult__ProviderErrorsOnly,
	---
	ResultRecord.AlertState AS ResultRecord__AlertState,
	ResultRecord.ErrorMessage AS ResultRecord__ErrorMessage,
	--ResultRecord.ErrorMessages AS ResultRecord__ErrorMessages,
	--ResultRecord.ResultAssignment_RoleId AS ResultRecord__ResultAssignment_RoleId,
	--ResultRecord.ResultAssignment_UserId AS ResultRecord__ResultAssignment_UserId,
	ResultRecordAssignment.AssignmentId As ResultRecordAssignment_AssignmentId,
	ResultRecordAssignment.AssignmentType As ResultRecordAssignment_AssignmentType,
	ResultRecord.ResultStatus_Id AS ResultRecord__ResultStatus_Id,
	ResultRecord.AlertStateDate AS ResultRecord__AlertStateDate,
	ResultRecord.ResultStatusDate AS ResultRecord__ResultStatusDate,
	ResultRecord.PredefinedSearchName AS ResultRecord__PredefinedSearchName,
	ResultRecord.ModifiedBy AS ResultRecord__ModifiedBy,
	ResultRecord.IsDeleted AS ResultRecord__IsDeleted,
	ResultRecord.CustomerId AS ResultRecord__CustomerId,
	---
	ResultSet.DivisionId AS ResultSet__DivisionId,
	---
	(SELECT COUNT(*) FROM ResultAlertAttachment raa WHERE raa.Id = ResultRecord.Id and DateDeleted is null) AS ResultAlertAttachment__Count,
	---
	ResultAuditRecord.ResultStatusId AS ResultAuditRecord__ResultStatusId,
	---
	ResultSet.BatchRunId AS ResultSet__BatchRunId,
	--ResultSet.SSNEIN AS ResultSet__SSNEIN,
	---
	ResultWatchListResult.ErrorMessage AS ResultWatchListResult__ErrorMessage,
	---
	ResultMatch.IsMatch AS ResultMatch__IsMatch,
	ResultMatch.IsAutomaticFalsePositive AS ResultMatch__IsAutomaticFalsePositive,
	--ResultMatch.ExcludeIfTrueMatchUpdatesOnly AS ,
	ResultMatch.Reason AS ResultMatch__Reason,
	ResultMatch.Score AS ResultMatch__Score
	--ResultMatch.SearchOnErrors AS ResultMatch__SearchOnErrors,
	--ResultMatch.SourceName AS ResultMatch__SourceName,
	--ResultMatch.TrueMatchUpdatesOnly AS ResultMatch__TrueMatchUpdatesOnly
FROM ResultRecord
	LEFT OUTER JOIN ResultInstantIdIndividualResult ON ResultRecord.Id = ResultInstantIdIndividualResult.Id
	LEFT OUTER JOIN ResultInstantIdIndividualRedFlag ON ResultInstantIdIndividualResult.Id = ResultInstantIdIndividualRedFlag.InstantIdIndividualResult_Id
	LEFT OUTER JOIN ResultInstantIdIndividualRedFlagRiskIndicator ON ResultInstantIdIndividualRedFlag.Id = ResultInstantIdIndividualRedFlagRiskIndicator.InstantIdIndividualRedFlag_Id
	LEFT OUTER JOIN ResultInstantIdIndividualRiskIndicator ON ResultInstantIdIndividualResult.Id = ResultInstantIdIndividualRiskIndicator.InstantIdIndividualResult_Id
	--
	LEFT OUTER JOIN ResultInstantIdInternationalResult ON ResultRecord.Id = ResultInstantIdInternationalResult.Id
	--
	--LEFT OUTER JOIN ResultAlertAttachment ON ResultRecord.Id = ResultAlertAttachment.Id
	--
	LEFT OUTER JOIN ResultInstantIdBusinessResult ON ResultRecord.Id = ResultInstantIdBusinessResult.Id
	LEFT OUTER JOIN ResultInstantIdBusinessRiskIndicator ON ResultInstantIdBusinessResult.Id = ResultInstantIdBusinessRiskIndicator.InstantIdBusinessResult_Id
	--
	LEFT OUTER JOIN ResultSet ON ResultRecord.ResultSetId = ResultSet.Id
	LEFT OUTER JOIN ResultEFTRecord ON ResultSet.Id = ResultEFTRecord.ResultSetId
	--
	LEFT OUTER JOIN ResultAuditRecord ON ResultRecord.Id = ResultAuditRecord.ResultRecord_Id
	--
	LEFT OUTER JOIN ResultFraudPointResult ON ResultRecord.Id = ResultFraudPointResult.Id
	LEFT OUTER JOIN ResultFraudPointRiskIndicator ON ResultFraudPointResult.Id = ResultFraudPointRiskIndicator.FraudPointResult_Id
	LEFT OUTER JOIN ResultFraudPointRedFlag ON ResultFraudPointResult.Id = ResultFraudPointRedFlag.FraudPointResult_Id
	LEFT OUTER JOIN ResultFraudPointRedFlagRiskIndicator ON ResultFraudPointRedFlag.Id = ResultFraudPointRedFlagRiskIndicator.FraudPointRedFlag_Id
	--
	LEFT OUTER JOIN ResultWatchListResult ON ResultRecord.Id = ResultWatchListResult.Id
	LEFT OUTER JOIN ResultMatch ON ResultWatchListResult.Id = ResultMatch.WatchListResult_Id
	-- LEFT OUTER JOIN ResultMatchAddress ON ResultMatch.Id = ResultMatchAddress.Match_Id
	-- LEFT OUTER JOIN ResultMatchDescription ON ResultMatch.Id = ResultMatchDescription.Match_Id
	-- LEFT OUTER JOIN ResultMatchIdentification ON ResultMatch.Id = ResultMatchIdentification.Match_Id
	LEFT OUTER JOIN ResultRecordAssignment ON ResultRecord.Id = ResultRecordAssignment.ResultRecordId

GO

SET QUOTED_IDENTIFIER ON
GO

---CustomWLManager---
--===============================================================================

--+++++++++++C:\Development\trunk\Src\LN.CustomWLManager+++++++++++

--===============================================================================

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ListMapping](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[InternalId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[Type] [int] NOT NULL,
 CONSTRAINT [PK_Lists] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [ind_ListMapping_unique_id] ON [dbo].[ListMapping]
(
	[InternalId] ASC,
	[CustomerId] ASC,
	[Type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlCustomWatchlist](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[UniqueId] [BINARY](16) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CWL_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[Type] [int] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Description] [nvarchar](2048) NULL,
	[PublicationDate] [datetime] NULL,
	[Version] [nvarchar](50) NULL,
	[Comments] [nvarchar](max) NULL,
	[AccountNumbers] [bit] NOT NULL CONSTRAINT "DF_CWL_AccountNumbers" default(0),
	[Encrypt] [bit] NOT NULL CONSTRAINT "DF_CWL_Encrypt" default(0),
	[UserSelectedStatusRequired] [bit] NOT NULL CONSTRAINT "DF_CWL_UserSelectedStatusRequired" default(0),
	[SearchCriteria] [nvarchar](max) NULL,
	[AutomaticallyIndex] [bit] NOT NULL,
	[LastBuilt] [datetime] NULL,
	[SpecialTypes] [smallint] NULL,
	[BuildStatus] [int] NOT NULL CONSTRAINT "DF_CWL_BuildStatus" default(0),
	[BuildStatusSecondary] [int] NOT NULL CONSTRAINT "DF_CWL_BuildStatusSecondary" default(0),
	[IsEnterprise] [bit] NOT NULL CONSTRAINT "DF_CWL_IsEnterprise" default(0),
	[DateModified] [datetime] NULL,
	[AllDivisions] [bit] NOT NULL CONSTRAINT "DF_CWL_AllDivisions" default(0),
	[UseEntityUniqueId] [bit] NOT NULL CONSTRAINT "DF_CWL_UseEntityUniqueId" DEFAULT 0,
	[EntityUniqueIdType] [int] NOT NULL CONSTRAINT "DF_CWL_EntityUniqueIdType" default(0),
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_CwlCustomWatchlist_IsDeleted" DEFAULT 0,
 CONSTRAINT [PK_dbo.CwlCustomWatchlist] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlcustomwatchlist_CustomerId] ON [dbo].[cwlcustomwatchlist] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CustomerID_CustomWatchlistName] ON [CwlCustomWatchlist]
(
	[CustomerId] ASC,
        [Name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CustomWatchlist_CustomerId_IsDeleted] ON [CwlCustomWatchlist]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CwlReason](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Description] [nvarchar](255) NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlReason_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsActive] [bit] NOT NULL,
	[IsInternalType] [bit] NOT NULL,
	[DateModified] [datetime] NULL,
 CONSTRAINT [PK_dbo.CwlReason] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlreason_CustomerId] ON [dbo].[cwlreason] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CWLEntity](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Title] [nvarchar](510) NULL,
	[First] [nvarchar](510) NULL,
	[Middle] [nvarchar](510) NULL,
	[Last] [nvarchar](510) NULL,
	[Generation] [nvarchar](50) NULL,
	[Full] [nvarchar](1636) NULL,
	[Gender] [int] NOT NULL,
	[DateListed] [datetime] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[ReasonListed] [nvarchar](510) NULL,
	[ReferenceNumber] [nvarchar](100) NULL,
	[Comments] [nvarchar](max) NULL,
	[SearchCriteria] [nvarchar](255) NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[CustomWatchlist_Id] [int] NOT NULL,
	[AuditId] [BINARY](16) NULL,
	[City] [nvarchar](240) NULL,
	[State] [nvarchar](100) NULL,
	[Country] [nvarchar](200) NULL,
	[EntityUniqueId] [varchar](48) NULL,
    [CheckSum] [bigint] NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CWLEntity_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_CwlEntity_IsDeleted" DEFAULT 0,
 CONSTRAINT [PK_dbo.CWLEntity] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlentity_CustomerId] ON [dbo].[cwlentity] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlEntity_CwlId] ON [dbo].[CwlEntity]
(
	CustomWatchlist_Id ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CWLEntity_AuditId] ON [dbo].[CwlEntity]
(
	AuditId ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IDX_CWLEntity_CWLId_CheckSum_EntityUniqueId] ON [dbo].[CWLEntity]
(
	CustomWatchlist_Id ASC,
	CheckSum ASC,
	EntityUniqueId ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

CREATE NONCLUSTERED INDEX [IX_CwlEntity_CustomerId_IsDeleted] ON [CwlEntity]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlDeploymentQueue](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[FilePath] [nvarchar](260) NOT NULL,
	[DeploymentStatus] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedDate] [datetime] NULL,
	[CustomWatchlistId] [int] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_CWL_DQ_EnvironmentType" DEFAULT(0),
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlDeploymentQueue_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.CwlDeploymentQueue] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwldeploymentqueue_CustomerId] ON [dbo].[cwldeploymentqueue] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CwlManualBuildQueue](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomWatchlistId] [int] NOT NULL,
	[BuildStatus] [int] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_CWL_MQ_EnvironmentType" DEFAULT(0),
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlManualBuildQueue_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_CwlManualBuildQueue] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
CREATE NONCLUSTERED INDEX [IX_cwlmanualbuildqueue_CustomerId] ON [dbo].[cwlmanualbuildqueue] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlAssignedDivision](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[DivisionId] [int] NOT NULL,
	[CustomWatchlist_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlAssignedDivision_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.CwlAssignedDivision] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlassigneddivision_CustomerId] ON [dbo].[cwlassigneddivision] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlCountryEntity](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Country] [nvarchar](1636) NULL,
	[ReasonListed] [nvarchar](510) NULL,
	[ReferenceNumber] [nvarchar](100) NULL,
	[Comments] [nvarchar](max) NULL,
	[DateListed] [datetime] NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CustomWatchlist_Id] [int] NOT NULL,
	[AuditId] [BINARY](16) NULL,
	[EntityUniqueId] [varchar](48) NULL,
    [CheckSum] [bigint] NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlCountryEntity_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_CwlCountryEntity_IsDeleted" DEFAULT 0,
 CONSTRAINT [PK_dbo.CwlCountryEntity] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlcountryentity_CustomerId] ON [dbo].[cwlcountryentity] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IDX_CWLCountryEntity_CWLId_CheckSum_EntityUniqueId] ON [dbo].[CwlCountryEntity]
(
	CustomWatchlist_Id ASC,
	CheckSum ASC,
	EntityUniqueId ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlCountryEntity_CwlId] ON [dbo].[CwlCountryEntity]
(
	CustomWatchlist_Id ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlCountryEntity_CustomerId_IsDeleted] ON [CwlCountryEntity]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlPhoneNumber](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Number] [nvarchar](60) NULL,
	[NumberUnformatted] [nvarchar](60) NULL,
	[Comments] [nvarchar](max) NULL,
	[Entity_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlPhoneNumber_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] bit NOT NULL CONSTRAINT "DF_CwlPhoneNumber_IsDeleted" DEFAULT 0,
	[DateModified] DateTime NULL,
 CONSTRAINT [PK_dbo.CwlPhoneNumber] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlphonenumber_CustomerId] ON [dbo].[cwlphonenumber] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlPhoneNumber_CustomerId_IsDeleted] ON [CwlPhoneNumber]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlIdentification](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Label] [nvarchar](510) NULL,
	[Number] [nvarchar](510) NULL,
	[NumberUnformatted] [nvarchar](510) NULL,
	[IssuedBy] [nvarchar](510) NULL,
	[IssuedDate] [datetime] NULL,
	[ExpirationDate] [datetime] NULL,
	[Comments] [nvarchar](max) NULL,
	[Entity_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlIdentification_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] bit NOT NULL CONSTRAINT "DF_CwlIdentification_IsDeleted" DEFAULT 0,
	[DateModified] DateTime NULL,
 CONSTRAINT [PK_dbo.CwlIdentification] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlidentification_CustomerId] ON [dbo].[cwlidentification] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX IX_CwlIdentification_EntityId
ON [dbo].[CwlIdentification]
(
	Entity_Id ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlIdentification_CustomerId_IsDeleted] ON [CwlIdentification]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CwlCountryLocation](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Name] [nvarchar](510) NULL,
	[CountryEntity_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlCountryLocation_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] bit NOT NULL CONSTRAINT "DF_CwlCountryLocation_IsDeleted" DEFAULT 0,
	[DateModified] DateTime NULL,
 CONSTRAINT [PK_dbo.CwlCountryLocation] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlcountrylocation_CustomerId] ON [dbo].[cwlcountrylocation] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlCountryLocation_CustomerId_IsDeleted] ON [CwlCountryLocation]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlCountryAka](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Name] [nvarchar](510) NULL,
	[CountryEntity_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlCountryAka_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] bit NOT NULL CONSTRAINT "DF_CwlCountryAka_IsDeleted" DEFAULT 0,
	[DateModified] DateTime NULL,
 CONSTRAINT [PK_dbo.CwlCountryAka] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlcountryaka_CustomerId] ON [dbo].[cwlcountryaka] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlCountryAka_CustomerId_IsDeleted] ON [CwlCountryAka]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlAka](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Category] [nvarchar](100) NULL,
	[Title] [nvarchar](510) NULL,
	[First] [nvarchar](510) NULL,
	[Middle] [nvarchar](510) NULL,
	[Last] [nvarchar](510) NULL,
	[Generation] [nvarchar](100) NULL,
	[Full] [nvarchar](1636) NULL,
	[Comments] [nvarchar](max) NULL,
	[Entity_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlAka_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] bit NOT NULL CONSTRAINT "DF_CwlAka_IsDeleted" DEFAULT 0,
[DateModified] DateTime NULL,
 CONSTRAINT [PK_dbo.CwlAka] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwlaka_CustomerId] ON [dbo].[cwlaka] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlAka_CustomerId_IsDeleted] ON [CwlAka]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlAddress](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[AddressLine1] [nvarchar](510) NULL,
	[AddressLine2] [nvarchar](510) NULL,
	[City] [nvarchar](240) NULL,
	[State] [nvarchar](100) NULL,
	[PostalCode] [nvarchar](40) NULL,
	[Country] [nvarchar](200) NULL,
	[Comments] [nvarchar](max) NULL,
	[Entity_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlAddress_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] bit NOT NULL CONSTRAINT "DF_CwlAddress_IsDeleted" DEFAULT 0,
	[DateModified] DateTime NULL,
 CONSTRAINT [PK_dbo.CwlAddress] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwladdress_CustomerId] ON [dbo].[cwladdress] (CustomerId ASC, Id ASC)
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlAddress_CustomerId_IsDeleted] ON [CwlAddress]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[CwlAdditionalInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Type] [int] NOT NULL,
	[Value] [nvarchar](1024) NULL,
	[ParsedValue] [nvarchar](1024) NULL,
	[ParsedDob] [datetime] NULL,
	[Comments] [nvarchar](max) NULL,
	[Entity_Id] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlAdditionalInfo_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[IsDeleted] bit NOT NULL CONSTRAINT "DF_CwlAdditionalInfo_IsDeleted" DEFAULT 0,
	[DateModified] DateTime NULL,
 CONSTRAINT [PK_dbo.CwlAdditionalInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_cwladditionalinfo_CustomerId] ON [dbo].[cwladditionalinfo] (CustomerId ASC, Id ASC)
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CwlAdditionalInfo_CustomerId_IsDeleted] ON [CwlAdditionalInfo]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO


CREATE TABLE [dbo].[CwlPurgeQueue](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[Name] [varchar](200) NOT NULL,
	[PurgeStatus] [int] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[DeletedDate] [datetime] NULL,
	[EnvironmentType] INT NOT NULL CONSTRAINT "DF_CWL_PQ_EnvironmentType" DEFAULT(0),
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CWL_PQ_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_CwlPurgeQueue] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
CREATE NONCLUSTERED INDEX [IX_cwlpurgequeue_CustomerId] ON [dbo].[cwlpurgequeue] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE TABLE [dbo].[CwlCustomFileFormat](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_CwlCustomFileFormat_IsDeleted" default(0),
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlCustomFileFormat_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
	[FileFormatType] [int] NOT NULL,
	[FormatType] [int] NOT NULL,
	[EncodingType] [int] NOT NULL,
	[EntityType] [int] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[DateFormat] [nvarchar](32) NULL,
	[FirstLineIsColumnHeader] [bit] NOT NULL,
	[MultiRecordField] [bit] NOT NULL,
	[DefaultCountryCode] [nvarchar](32) NULL,
	[DefaultCountryName] [nvarchar](128) NULL,
	[AreFieldsQuoted] [bit] NOT NULL,
	[ParsedAddressFields] [bit] NOT NULL,
	[FieldDelimiter] [nvarchar](10) NULL,
	[LineDelimiter] [nvarchar](10) NULL,
	[Crlf] [bit] NOT NULL,
	[LineLength] [int] NOT NULL,
	[ExampleFileName] [nvarchar](255) NULL,
	[ExampleFileData] [nvarchar](max) NULL,
	[IsInternalType] [bit] NOT NULL,
	[MultiRecordColumnStart] [int] NULL,
	[MultiRecordColumnEnd] [int] NULL,
 CONSTRAINT [PK_dbo.CwlCustomFileFormat] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

CREATE NONCLUSTERED INDEX [IX_cwlcustomfileformat_CustomerId] ON [dbo].[cwlcustomfileformat] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

CREATE TABLE [dbo].[CwlCustomFormatEntity](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[EntityType] [int] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[CustomFileFormatId] [int] NOT NULL,
	[EntityIndex] [int] NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlCustomFormatEntity_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.CwlCustomFormatEntity] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
CREATE NONCLUSTERED INDEX [IX_cwlcustomformatentity_CustomerId] ON [dbo].[cwlcustomformatentity] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

CREATE TABLE [dbo].[CwlCustomFormatField](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[CustomFileFormatId] [int] NOT NULL,
	[EntityIndex] [int] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[FullName] [nvarchar](100) NULL,
	[DataType] [int] NOT NULL,
	[IdType] [int] NOT NULL,
	[IdentificationIdType] [int] NULL,
	[AdditionalInfoIdType] [int] NULL,
	[AddressIdType] [int] NULL,
	[PhoneIdType] [int] NULL,
	[Position] [int] NULL,
	[Start] [int] NULL,
	[End] [int] NULL,
	[CountryLocationIdType] [int] NULL,
	[CountryAkaIdType] [int] NULL,
	[AkaIdType] [int] NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_CwlCustomFormatField_CustomerId" default(0),
	[OriginalId] [bigint] NULL,
 CONSTRAINT [PK_dbo.CwlCustomFormatField] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO
CREATE NONCLUSTERED INDEX [IX_cwlcustomformatfield_CustomerId] ON [dbo].[cwlcustomformatfield] (CustomerId ASC, Id ASC) 
WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
/* ALTER TABLE [dbo].[CwlAdditionalInfo]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlAdditionalInfo_dbo.CWLEntity_Entity_Id] FOREIGN KEY([Entity_Id])
REFERENCES [dbo].[CWLEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlAdditionalInfo] CHECK CONSTRAINT [FK_dbo.CwlAdditionalInfo_dbo.CWLEntity_Entity_Id]
GO */

/* ALTER TABLE [dbo].[CwlAddress]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlAddress_dbo.CWLEntity_Entity_Id] FOREIGN KEY([Entity_Id])
REFERENCES [dbo].[CWLEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlAddress] CHECK CONSTRAINT [FK_dbo.CwlAddress_dbo.CWLEntity_Entity_Id]
GO */

/* ALTER TABLE [dbo].[CwlAka]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlAka_dbo.CWLEntity_Entity_Id] FOREIGN KEY([Entity_Id])
REFERENCES [dbo].[CWLEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlAka] CHECK CONSTRAINT [FK_dbo.CwlAka_dbo.CWLEntity_Entity_Id]
GO */

/* ALTER TABLE [dbo].[CwlAssignedDivision]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlAssignedDivision_dbo.CwlCustomWatchlist_CustomWatchlist_Id] FOREIGN KEY([CustomWatchlist_Id])
REFERENCES [dbo].[CwlCustomWatchlist] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlAssignedDivision] CHECK CONSTRAINT [FK_dbo.CwlAssignedDivision_dbo.CwlCustomWatchlist_CustomWatchlist_Id]
GO */

/* ALTER TABLE [dbo].[CwlCountryAka]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlCountryAka_dbo.CwlCountryEntity_CountryEntity_Id] FOREIGN KEY([CountryEntity_Id])
REFERENCES [dbo].[CwlCountryEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlCountryAka] CHECK CONSTRAINT [FK_dbo.CwlCountryAka_dbo.CwlCountryEntity_CountryEntity_Id]
GO */

/* ALTER TABLE [dbo].[CwlCountryEntity]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlCountryEntity_dbo.CwlCustomWatchlist_CustomWatchlist_Id] FOREIGN KEY([CustomWatchlist_Id])
REFERENCES [dbo].[CwlCustomWatchlist] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlCountryEntity] CHECK CONSTRAINT [FK_dbo.CwlCountryEntity_dbo.CwlCustomWatchlist_CustomWatchlist_Id]
GO */

/* ALTER TABLE [dbo].[CwlCountryLocation]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlCountryLocation_dbo.CwlCountryEntity_CountryEntity_Id] FOREIGN KEY([CountryEntity_Id])
REFERENCES [dbo].[CwlCountryEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlCountryLocation] CHECK CONSTRAINT [FK_dbo.CwlCountryLocation_dbo.CwlCountryEntity_CountryEntity_Id]
GO */

/* ALTER TABLE [dbo].[CWLEntity]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CWLEntity_dbo.CwlCustomWatchlist_CustomWatchlist_Id] FOREIGN KEY([CustomWatchlist_Id])
REFERENCES [dbo].[CwlCustomWatchlist] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CWLEntity] CHECK CONSTRAINT [FK_dbo.CWLEntity_dbo.CwlCustomWatchlist_CustomWatchlist_Id]
GO */

/* ALTER TABLE [dbo].[CwlIdentification]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlIdentification_dbo.CWLEntity_Entity_Id] FOREIGN KEY([Entity_Id])
REFERENCES [dbo].[CWLEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlIdentification] CHECK CONSTRAINT [FK_dbo.CwlIdentification_dbo.CWLEntity_Entity_Id]
GO */

/* ALTER TABLE [dbo].[CwlPhoneNumber]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlPhoneNumber_dbo.CWLEntity_Entity_Id] FOREIGN KEY([Entity_Id])
REFERENCES [dbo].[CWLEntity] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlPhoneNumber] CHECK CONSTRAINT [FK_dbo.CwlPhoneNumber_dbo.CWLEntity_Entity_Id]
GO */

/* ALTER TABLE [dbo].[CwlCustomFormatEntity]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlCustomFormatEntityDbo.CwlCustomFileFormatCustomFileFormatId] FOREIGN KEY([CustomFileFormatId])
REFERENCES [dbo].[CwlCustomFileFormat] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CwlCustomFormatEntity] CHECK CONSTRAINT [FK_dbo.CwlCustomFormatEntityDbo.CwlCustomFileFormatCustomFileFormatId]
GO */

/* ALTER TABLE [dbo].[CwlCustomFormatField]  WITH CHECK ADD  CONSTRAINT [FK_dbo.CwlCustomFormatFieldDbo.CwlCustomFileFormatCustomFileFormatId] FOREIGN KEY([CustomFileFormatId])
REFERENCES [dbo].[CwlCustomFileFormat] ([Id])
ON DELETE CASCADE
ALTER TABLE [dbo].[CwlCustomFormatField] CHECK CONSTRAINT [FK_dbo.CwlCustomFormatFieldDbo.CwlCustomFileFormatCustomFileFormatId]
GO */


--===============================================================================

--+++++++++++C:\Development\trunk\Src\PdsPredefinedSearchFieldSets+++++++++++

--===============================================================================
----PdsPredefinedSearchFieldSets-----

/****** Object:  Table [dbo].[PdsPredefinedSearchFieldSets]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsPredefinedSearchFieldSets](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[IsDefault] [bit] NOT NULL,
	[IndPromptForName] [int] NOT NULL CONSTRAINT "DF_PDS_IndPromptForName" DEFAULT 0,
	[DateModified] [datetime] NULL,

 CONSTRAINT [PK_dbo.PdsPredefinedSearchFieldSets] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsPredefinedSearchInfo
-- ----------------------------------------------------------------------------

/****** Object:  Table [dbo].[PdsPredefinedSearchInfo]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsPredefinedSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[UniqueId] [BINARY](16) NOT NULL,
	[Version] [int] NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Description] [nvarchar](255) NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[DateCreated] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[DateModified] [datetime] NOT NULL,
	[FieldSetId] [int] NULL,
	[UseDefaultFieldSet] [bit] NOT NULL,
	UserCanAddSearchFields [bit] NULL,
	[IsActive] [bit] NOT NULL,
	[IsDefaultSearch] [bit] NOT NULL,
	[IsWireSupported] [bit] NOT NULL,
	[EnableWatchlistSearch] [bit] NOT NULL,
	[EnableWCSearch] [bit] NULL,
	[EnableFraudPointSearch] [bit] NOT NULL,
	[EnableInstantIdSearch] [bit] NOT NULL,
	[EnableInstantIdIntlSearch] [bit] NOT NULL,
	[EnableNewsSearch] [bit] NOT NULL,
	[GDCCountrySelection] [nvarchar](max) NULL,
	[AlertAssignmentType] [int] NOT NULL,
	[AlertAssignResultToSearchingUser] [bit] NOT NULL,
	[AlertAssignedRoles] [nvarchar](max) NULL,
	[AlertAssignmentUser] [int] NULL,
	[SupportedEntityTypes_Individual] [bit] NOT NULL,
	[SupportedEntityTypes_Business] [bit] NOT NULL,
	[SupportedEntityTypes_Unknown] [bit] NOT NULL,
	[SupportedEntityTypes_Text] [bit] NOT NULL,
	[PredefinedEntityType] [int] NOT NULL CONSTRAINT "DF_PDS_PredefinedEntityType" DEFAULT 0,
	[AllDivisions] [bit] NOT NULL CONSTRAINT "DF_PDS_AllDivisions" default(0),
 CONSTRAINT [PK_dbo.PdsPredefinedSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
  ALTER TABLE PdsPredefinedSearchInfo
ADD CONSTRAINT
PDSVersioniqueConstraint UNIQUE NONCLUSTERED
(
    CustomerId,
    UniqueId,
    Version
)
CREATE NONCLUSTERED INDEX [IX_FieldSetId] ON [dbo].[PdsPredefinedSearchInfo]
(
	[FieldSetId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsPredefinedSearchInfo_Name_IsActive] ON [dbo].[PdsPredefinedSearchInfo]
(
	[Name] ASC,
	[IsActive] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsPredefinedSearchInfo_CustomerId_IsActive_Name] ON [dbo].[PdsPredefinedSearchInfo]
(
	[CustomerId] ASC,	
	[IsActive] ASC,
	[Name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsGlobalFalseMatchUpdateSettings
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[PdsGlobalFalseMatchUpdateSettings] (
  [Id] [int] IDENTITY(2,2) NOT NULL,
  [CustomerId] [int] NOT NULL,
  [OriginalId] BIGINT NULL,
  [IsGlobalDefault] [bit] NOT NULL DEFAULT 0,
  [Name] [bit] NOT NULL DEFAULT 0,
  [Dob] [bit] NOT NULL DEFAULT 0,
  [Gender] [bit] NOT NULL DEFAULT 0,
  [Aka] [bit] NOT NULL DEFAULT 0,
  [IdNumbers] [bit] NOT NULL DEFAULT 0,
  [Address] [bit] NOT NULL DEFAULT 0,
  [Country] [bit] NOT NULL DEFAULT 0,
  [Phone] [bit] NOT NULL DEFAULT 0,
  [Citizenship] [bit] NOT NULL DEFAULT 0,
  [PlaceOfBirth] [bit] NOT NULL DEFAULT 0,
  [DateCreated] [datetime] DEFAULT NULL,
  [CreatedBy] varchar(100) DEFAULT NULL,
  [DateModified] datetime DEFAULT NULL,
  [ModifiedBy] varchar(100) DEFAULT NULL,
  CONSTRAINT [PK_dbo.PdsGlobalFalseMatchUpdateSettings] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PdsGlobalFalseMatchUpdatesettings_CustomerId] ON [dbo].[PdsGlobalFalseMatchUpdatesettings]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsBusinessInputGroups
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsBusinessInputGroups]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsBusinessInputGroups](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsBusinessInputGroups_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[ElementId] [nvarchar](max) NULL,
	[Label] [nvarchar](max) NULL,
	[FieldSet_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsBusinessInputGroups] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_FieldSet_Id] ON [dbo].[PdsBusinessInputGroups]
(
	[FieldSet_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsBusinessInputGroups_CustomerId] ON [dbo].[PdsBusinessInputGroups] 
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsIndividualInputGroups
-- ----------------------------------------------------------------------------

/****** Object:  Table [dbo].[PdsIndividualInputGroups]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsIndividualInputGroups](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsIndividualInputGroups_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[ElementId] [nvarchar](max) NULL,
	[Label] [nvarchar](max) NULL,
	[FieldSet_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsIndividualInputGroups] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_FieldSet_Id] ON [dbo].[PdsIndividualInputGroups]
(
	[FieldSet_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsIndividualInputGroups_CustomerId] ON [dbo].[PdsIndividualInputGroups]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsWatchlistSearchInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsWatchlistSearchInfo]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsWatchlistSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsWatchlistSearchInfo_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[ConfigGeneralOptions_IgnoreVessels] [bit] NOT NULL,
	[ConfigGeneralOptions_ScanAddressForBlockedCountries] [bit] NOT NULL,
	[ConfigGeneralOptions_ScanNameForBlockedCountries] [bit] NOT NULL,
	[ConfigGeneralOptions_UseNonWordTokenCountrySearch] [bit] NOT NULL,
	[ConfigGeneralOptions_AlertOnError] [bit] NOT NULL,
	[ConfigGeneralOptions_SaveAllResults] [bit] NOT NULL,
	[ConfigMatchOptions_GenerateOnAddress] [bit] NOT NULL,
	[ConfigMatchOptions_GenerateOnIDs] [bit] NOT NULL,
	[ConfigMatchOptions_GenerateOnName] [bit] NOT NULL,
	[ConfigMatchOptions_GenerateOnPhone] [bit] NOT NULL,
	[ConfigMatchOptions_ScoreInitials] [bit] NOT NULL,
	[ConfigMatchOptions_ScoreSingleWords] [bit] NOT NULL,
	[ConfigMatchOptions_IgnoreGatewayIndicator] [bit] NOT NULL,
	[ConfigMatchOptions_IgnoreSecondaryGatewayIndicator] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_Addresses] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_Citizenship] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_Countries] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_DOB] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_DOBTolerance] [int] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_EntityType] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_Gender] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_IDs] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_Phones] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_SearchWhitelist] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_WriteFalsePositiveMatches] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_AlertOnFalsePositiveMatches] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_DisplayFalsePositiveInAlert] [bit] NOT NULL,
	[ConfigMatchDispositionRules_IndividualMatchDisposition] [bit] NOT NULL,
	[ConfigMatchDispositionRules_AutomaticFalsePositives] [bit] NOT NULL,
	[ConfigMatchDispositionRules_ReAlertOnChange] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_UseAdvancedRules] [bit] NOT NULL,
	[ConfigMatchOptions_ScanAllFieldsForBICs] BIT NOT NULL CONSTRAINT [DF_ScanAllFieldsForBICs] DEFAULT 0,
	[ConfigMatchOptions_ScanAllFieldsForCountryCodes] BIT NOT NULL CONSTRAINT [DF_ScanAllFieldsForCountryCodes] DEFAULT 0,
	[ConfigMatchOptions_ScanAllFieldsForCountryNames] BIT NOT NULL CONSTRAINT [DF_ScanAllFieldsForCountryNames] DEFAULT 0,
	[ConfigMatchOptions_ScanAllFieldsForNames] BIT NOT NULL CONSTRAINT [DF_ScanAllFieldsForNames] DEFAULT 0,
	[ConfigFalseMatchUpdateSettings_Name] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_Name] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_DOB] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_DOB] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_Gender] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_Gender] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_Aka] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_Aka] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_IdNumbers] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_IdNumbers] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_Address] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_Address] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_Country] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_Country] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_Phone] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_Phone] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_Citizenship] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_Citizenship] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_PlaceOfBirth] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_PlaceOfBirth] DEFAULT 0,
	[ConfigFalseMatchUpdateSettings_GenerateFalseMatchUpdate] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_GenerateFalseMatchUpdate] DEFAULT 0,
    [ConfigFalseMatchUpdateSettings_OverrideDefault] BIT NOT NULL CONSTRAINT [DF_FalseMatchUpdateSettings_OverrideDefault] DEFAULT 0,	
	[FPRProbabilityThreshold] REAL NOT NULL CONSTRAINT [DF_PdsWatchlistSearchinfo_FPRProbabilityThreshold] default 0,
	[FPRModelUniqueId] BINARY(16) NULL,

 CONSTRAINT [PK_dbo.PdsWatchlistSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PredefinedSearchId] ON [dbo].[PdsWatchlistSearchInfo]
(
	[PredefinedSearchId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsWatchlistSearchInfo_CustomerId] ON [dbo].[PdsWatchlistSearchInfo]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsRunStatus
-- ----------------------------------------------------------------------------

/****** Object:  Table [dbo].[PdsRunStatus]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsRunStatus](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[ResultSetId] [bigint] NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[State] [int] NOT NULL,
	[Origin] [int] NOT NULL,
	[DateSubmitted] [datetime] NOT NULL,
	[DateCompleted] [datetime] NULL,
	[TotalNumRecords] [int] NOT NULL,
	[NameSearched] [nvarchar](max) NOT NULL,
	[SubmittedBy] [int] NOT NULL,
	[ResultRecordId] [bigint] NULL,
	[MatchCount] [int] NULL,
 CONSTRAINT [PK_dbo.PdsRunStatus] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PredefinedSearchId] ON [dbo].[PdsRunStatus]
(
	[PredefinedSearchId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PDS_RunStatus_ResultSetId] ON [dbo].[PdsRunStatus]
(
	[ResultSetId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PDS_RunStatus_DateSubmitted] ON [dbo].[PdsRunStatus]
(
	[DateSubmitted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsIndividualInputFields
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsIndividualInputFields]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsIndividualInputFields](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsIndividualInputFields_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[ElementId] [nvarchar](max) NULL,
	[Label] [nvarchar](max) NULL,
	[Value] [nvarchar](max) NULL,
	[Show] [bit] NOT NULL CONSTRAINT "DF_PDS_IID_Show" DEFAULT 0,
	[Required] [bit] NOT NULL  CONSTRAINT "DF_PDS_IID_Required" DEFAULT 0,
	[SelectList] [bit] NOT NULL  CONSTRAINT "DF_PDS_IID_SelectList" DEFAULT 0,
	[System] [bit] NOT NULL CONSTRAINT "DF_PDS_IID_System" DEFAULT 0,
	[InputGroup_Id] [int] NOT NULL CONSTRAINT "DF_PDS_IID_InputGroupId" DEFAULT 0,
	[IsInternational] [bit] NOT NULL CONSTRAINT "DF_PDS_IID_IsInternational" DEFAULT 0,
 CONSTRAINT [PK_dbo.PdsIndividualInputFields] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InputGroup_Id] ON [dbo].[PdsIndividualInputFields]
(
	[InputGroup_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsIndividualInputFields_CustomerId] ON [dbo].[PdsIndividualInputFields] 
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsBusinessInputFields
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsBusinessInputFields]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsBusinessInputFields](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsBusinessInputFields_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[ElementId] [nvarchar](max) NULL,
	[Label] [nvarchar](max) NULL,
	[Value] [nvarchar](max) NULL,
	[Show] [bit] NOT NULL CONSTRAINT "DF_PDS_BIID_Show" DEFAULT 0,
	[Required] [bit] NOT NULL CONSTRAINT "DF_PDS_BIID_Required" DEFAULT 0,
	[SelectList] [bit] NOT NULL CONSTRAINT "DF_PDS_BIID_SelectList" DEFAULT 0,
	[System] [bit] NOT NULL CONSTRAINT "DF_PDS_BIID_System" DEFAULT 0,
	[InputGroup_Id] [int] NOT NULL CONSTRAINT "DF_PDS_BIID_InputGroupId" DEFAULT 0,
	[IsInternational] [bit] NOT NULL CONSTRAINT "DF_PDS_BIID_IsInternational" DEFAULT 0,
 CONSTRAINT [PK_dbo.PdsBusinessInputFields] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_InputGroup_Id] ON [dbo].[PdsBusinessInputFields]
(
	[InputGroup_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsBusinessInputFields_CustomerId] ON [dbo].[PdsBusinessInputFields] 
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsAssignedRoles
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsAssignedRoles]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsAssignedRoles](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsAssignedRoles_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[RoleId] [int] NOT NULL,
	[PredefinedSearch_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsAssignedRoles] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PredefinedSearch_Id] ON [dbo].[PdsAssignedRoles]
(
	[PredefinedSearch_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsAssignedRoles_CustomerId] ON [dbo].[PdsAssignedRoles] 
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsAssignedDivisions
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsAssignedDivisions]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsAssignedDivisions](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsAssignedDivisions_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[DivisionId] [int] NOT NULL,
	[PredefinedSearch_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsAssignedDivisions] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PdsAssignedDivisions_CustomerId] ON [dbo].[PdsAssignedDivisions] 
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PredefinedSearch_Id] ON [dbo].[PdsAssignedDivisions]
(
	[PredefinedSearch_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsFraudPointSearchInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsFraudPointSearchInfo]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsFraudPointSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[AlertOnError] [bit] NOT NULL,
	[AlertOnRiskIndicators] [bit] NOT NULL,
	[IncludeRedFlagReport] [bit] NOT NULL,
	[AlertOnRedFlags] [bit] NOT NULL,
	[SearchOption] [int] NOT NULL,
	[SyntheticIdentityIndex] [int] NOT NULL,
	[StolenIdentityIndex] [int] NOT NULL,
	[ManipulatedIdentityIndex] [int] NOT NULL,
	[VulnerableVictimIndex] [int] NOT NULL,
	[FriendlyFraudIndex] [int] NOT NULL,
	[SuspiciousActivityIndex] [int] NOT NULL,
	[ScoreThreshold] [int] NOT NULL,
	[Model] [varchar](100) NULL,
 CONSTRAINT [PK_dbo.PdsFraudPointSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PredefinedSearchId] ON [dbo].[PdsFraudPointSearchInfo]
(
	[PredefinedSearchId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsFraudpointSearchInfo_CustomerId] ON [dbo].[PdsFraudpointSearchInfo]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdIntlSearchInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdIntlSearchInfo]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdIntlSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[AlertOnError] [bit] NOT NULL,
	[AlertOnRiskIndicators] [bit] NOT NULL,
	[IndexThreshold] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdIntlSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PredefinedSearchId] ON [dbo].[PdsInstantIdIntlSearchInfo]
(
	[PredefinedSearchId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsInstantIdIntlSearchInfo_CustomerId] ON [dbo].[PdsInstantIdIntlSearchInfo]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsNewsSearchInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsNewsSearchInfo]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsNewsSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[AlertThreshold] [bit] NOT NULL,
	[IncludeWords] [nvarchar](max) NULL,
	[ExcludeWords] [nvarchar](max) NULL,
	[Source] [int] NOT NULL,
	[MaxItems] [int] NOT NULL,
	[NegativeNews] [bit] NOT NULL,
	[DateRange] [int] NOT NULL,
	[FromDate] [datetime] NOT NULL,
	[ToDate] [datetime] NOT NULL,
	[SortBy] [int] NOT NULL,
	[SearchOperand1] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperand1" DEFAULT 0,
	[SearchOperand2] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperand2" DEFAULT 0,
	[SearchOperand3] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperand3" DEFAULT 0,
	[SearchOperand4] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperand4" DEFAULT 0,
	[SearchOperand5] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperand5" DEFAULT 0,
	[SearchOperand6] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperand6" DEFAULT 0,
	[SearchOperator1] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperator1" DEFAULT 0,
	[SearchOperator2] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperator2" DEFAULT 0,
	[SearchOperator3] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperator3" DEFAULT 0,
	[SearchOperator4] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperator4" DEFAULT 0,
	[SearchOperator5] [int] NOT NULL CONSTRAINT "DF_PDS_News_SearchOperator5" DEFAULT 0,


 CONSTRAINT [PK_dbo.PdsNewsSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PredefinedSearchId] ON [dbo].[PdsNewsSearchInfo]
(
	[PredefinedSearchId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsNewsSearchInfo_CustomerId] ON [dbo].[PdsNewsSearchInfo]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdSearchInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdSearchInfo]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[PredefinedSearchId] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_PredefinedSearchId] ON [dbo].[PdsInstantIdSearchInfo]
(
	[PredefinedSearchId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsInstantIdSearchInfo_CustomerId] ON [dbo].[PdsInstantIdSearchInfo]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdIntlSearchInfoRiskIndicators
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdIntlSearchInfoRiskIndicators]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdIntlSearchInfoRiskIndicators](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsInstantIdIntlSearchInfoRiskIndicators_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[Code] [int] NOT NULL,
	[Sequence] [int] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdIntlSearchInfoRiskIndicators] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsInstantIdIntlSearchInfoRiskIndicators]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsInstantIdIntlSearchInfoRiskIndicators_CustomerId] ON [dbo].[PdsInstantIdIntlSearchInfoRiskIndicators]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsCustomWatchlistSelections
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsCustomWatchlistSelections]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsCustomWatchlistSelections](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsCustomWatchlistSelections_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[WatchlistId] [BINARY](16) NOT NULL,
	[IgnoreWeakAKAs] [bit] NOT NULL,
	[MinScore] [int] NOT NULL,
	[Name] [nvarchar](255) NULL,
	[SearchInfo_Id] [int] NOT NULL,
	[AlwaysMatchOnCitiesAndPorts] [bit] NULL CONSTRAINT "DF_PdsCustomWatchlistSelections_AlwaysMatchOnCitiesAndPorts" default(0),
 CONSTRAINT [PK_dbo.PdsCustomWatchlistSelections] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsCustomWatchlistSelections]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsCustomWatchlistSelections_CustomerId] ON [dbo].[PdsCustomWatchlistSelections] 
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsFraudPointSearchInfoRiskIndicators
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsFraudPointSearchInfoRiskIndicators]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsFraudPointSearchInfoRiskIndicators](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsFraudPointSearchInfoRiskIndicators_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[Code] [int] NOT NULL,
	[Sequence] [int] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsFraudPointSearchInfoRiskIndicators] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsFraudPointSearchInfoRiskIndicators]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsFraudPointSearchInfoRiskIndicators_CustomerId] ON [dbo].[PdsFraudPointSearchInfoRiskIndicators]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsFraudPointSearchInfoRedFlags
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsFraudPointSearchInfoRedFlags]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsFraudPointSearchInfoRedFlags](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsFraudPointSearchInfoRedFlags_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[Category] [int] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsFraudPointSearchInfoRedFlags] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsFraudPointSearchInfoRedFlags]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsFraudPointSearchInfoRedFlags_CustomerId] ON [dbo].[PdsFraudPointSearchInfoRedFlags]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdIndividualSearchInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdIndividualSearchInfo]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdIndividualSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[AlertOnError] [bit] NOT NULL,
	[AlertOnIndexAndNAPNAS] [bit] NOT NULL,
	[AlertOnRedFlags] [bit] NOT NULL,
	[AlertOnRiskIndicators] [bit] NOT NULL,
	[IndexThreshold] [int] NOT NULL,
	[POBoxOverridesIndex] [bit] NOT NULL,
	[MultipleSsnOverridesIndex] [bit] NOT NULL,
	[MultipleIdsOverridesIndex] bit NOT NULL CONSTRAINT "DF_PdsMultipleIdsOverridesIndex" default(0),
	[IncludeDateofBirthScore] bit NOT NULL CONSTRAINT "DF_PdsIncludeDateofBirthScore" default(0),
	[IncludeDriverLicenseInScore] bit NOT NULL CONSTRAINT "DF_PdsIncludeDriverLicenseInScore" default(0),
	[DisableInquiryDerivedVerification] bit NOT NULL CONSTRAINT "DF_PdsDisableInquiryDerivedVerification" default(0),
	[NonPrimarySsnOverridesIndex] [bit] NOT NULL,
	[IsRedFlagsEnabled] [bit] NOT NULL,
	[ReturnAllRiskIndicators] [bit] NOT NULL,
	[ExactMatchLastName] [bit] NOT NULL,
	[ExactMatchFirstName] [bit] NOT NULL,
	[ExactMatchFirstNameOrNickname] [bit] NOT NULL,
	[ExactMatchHomePhone] [bit] NOT NULL,
	[ExactMatchSsn] [bit] NOT NULL,
	[DateOfBirthMatching] [int] NOT NULL,
	[DateOfBirthMatchingRadius] [int] NOT NULL,
	[NAPMustMatch_PhoneOnly] [bit] NOT NULL,
	[NAPMustMatch_FirstNameLastName] [bit] NOT NULL,
	[NAPMustMatch_FirstNameAddress] [bit] NOT NULL,
	[NAPMustMatch_FirstNamePhone] [bit] NOT NULL,
	[NAPMustMatch_LastNameAddress] [bit] NOT NULL,
	[NAPMustMatch_AddressPhone] [bit] NOT NULL,
	[NAPMustMatch_LastNamePhone] [bit] NOT NULL,
	[NAPMustMatch_FirstNameLastNameAddress] [bit] NOT NULL,
	[NAPMustMatch_FirstNameLastNamePhone] [bit] NOT NULL,
	[NAPMustMatch_FirstNameAddressPhone] [bit] NOT NULL,
	[NAPMustMatch_LastNameAddressPhone] [bit] NOT NULL,
	[NAPMustMatch_FirstNameLastNameAddressPhone] [bit] NOT NULL,
	[NASMustMatch_SsnOnly] [bit] NOT NULL,
	[NASMustMatch_FirstNameLastName] [bit] NOT NULL,
	[NASMustMatch_FirstNameAddress] [bit] NOT NULL,
	[NASMustMatch_FirstNameSsn] [bit] NOT NULL,
	[NASMustMatch_LastNameAddress] [bit] NOT NULL,
	[NASMustMatch_AddressSsn] [bit] NOT NULL,
	[NASMustMatch_LastNameSsn] [bit] NOT NULL,
	[NASMustMatch_FirstNameLastNameAddress] [bit] NOT NULL,
	[NASMustMatch_FirstNameLastNameSsn] [bit] NOT NULL,
	[NASMustMatch_FirstNameAddressSsn] [bit] NOT NULL,
	[NASMustMatch_LastNameAddressSsn] [bit] NOT NULL,
	[NASMustMatch_FirstNameLastNameAddressSsn] [bit] NOT NULL,
	[NAPMustMatch_None] [bit] NOT NULL,
	[NASMustMatch_None] [bit] NOT NULL,
	[LastSeenAddress] [BIT] NOT NULL CONSTRAINT "DF_PDS_IID_LastSeenAddress" Default(0),
	[LastSeenAddressThreshold] INT NULL,
	[IIDVersion] [INT] NOT NULL CONSTRAINT "DF_PDS_IID_Version" Default(1),
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdIndividualSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsInstantIdIndividualSearchInfo]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsInstantIdIndividualSearchInfo_CustomerId] ON [dbo].[PdsInstantIdIndividualSearchInfo]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdBusinessSearchInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdBusinessSearchInfo]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdBusinessSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[AlertOnError] [bit] NOT NULL,
	[IndexThreshold] [int] NOT NULL,
	[AlertOnRiskIndicators] [bit] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdBusinessSearchInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsInstantIdBusinessSearchInfo]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

CREATE NONCLUSTERED INDEX [IX_PdsInstantIdBusinessSearchinfo_CustomerId] ON [dbo].[PdsInstantIdBusinessSearchInfo]
(
	[CustomerId] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
/****** Object:  Table [dbo].[PdsOverrideListSelections]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsOverrideListSelections
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[PdsOverrideListSelections](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsOverrideListSelections_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[OverrideListId] [int] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsOverrideListSelections] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsOverrideListSelections]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsOverrideListSelections_CustomerId] ON [dbo].[PdsOverrideListSelections]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsNormalWatchlistSelections
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsNormalWatchlistSelections]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsNormalWatchlistSelections](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsNormalWatchlistSelections_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[WatchlistId] [BINARY](16) NOT NULL,
	[IgnoreWeakAKAs] [bit] NOT NULL,
	[MinScore] [int] NOT NULL,
	[Name] [nvarchar](255) NULL,
	[TopLevelOperator] [int] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
	[AlwaysMatchOnCitiesAndPorts] [bit] NOT NULL CONSTRAINT "DF_PdsNormalWatchlistSelections_AlwaysMatchOnCitiesAndPorts" DEFAULT 0,
 CONSTRAINT [PK_dbo.PdsNormalWatchlistSelections] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsNormalWatchlistSelections]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsNormalWatchlistSelections_CustomerId] ON [dbo].[PdsNormalWatchlistSelections]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsRecordTypeSelections
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsRecordTypeSelections]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsRecordTypeSelections](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsRecordTypeSelections_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[RecordTypeId] [int] NOT NULL,
	[RecordType] [nvarchar](max) NULL,
	[SelectionId] [int] NOT NULL,
	[Selection] [nvarchar](max) NULL,
	[WatchlistSelection_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsRecordTypeSelections] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_WatchlistSelection_Id] ON [dbo].[PdsRecordTypeSelections]
(
	[WatchlistSelection_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsRecordTypeSelections_CustomerId] ON [dbo].[PdsRecordTypeSelections]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdBusinessSearchInfoRiskIndicators
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdBusinessSearchInfoRiskIndicators]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdBusinessSearchInfoRiskIndicators](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsInstantIdBusinessSearchInfoRiskIndicators_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[Code] [int] NOT NULL,
	[Sequence] [int] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdBusinessSearchInfoRiskIndicators] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsInstantIdBusinessSearchInfoRiskIndicators]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsInstantIdBusinessSearchInfoRiskIndicators_CustomerId] ON [dbo].[PdsInstantIdBusinessSearchInfoRiskIndicators]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsFraudPointSearchInfoRedFlagRiskIndicators
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsFraudPointSearchInfoRedFlagRiskIndicators]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsFraudPointSearchInfoRedFlagRiskIndicators](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsFraudPointSearchInfoRedFlagRiskIndicators_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[Code] [int] NOT NULL,
	[Sequence] [int] NOT NULL,
	[RedFlag_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsFraudPointSearchInfoRedFlagRiskIndicators] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_RedFlag_Id] ON [dbo].[PdsFraudPointSearchInfoRedFlagRiskIndicators]
(
	[RedFlag_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsFraudPointSearchInfoRedFlagRiskIndicators_CustomerId] ON [dbo].[PdsFraudPointSearchInfoRedFlagRiskIndicators] 
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdIndividualSearchInfoRiskIndicators
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdIndividualSearchInfoRiskIndicators]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdIndividualSearchInfoRiskIndicators](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsInstantIdIndividualSearchInfoRiskIndicators_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[Code] [int] NOT NULL,
	[Sequence] [int] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdIndividualSearchInfoRiskIndicators] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsInstantIdIndividualSearchInfoRiskIndicators]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsInstantIdIndividualSearchInfoRiskIndicators_CustomerId] ON [dbo].[PdsInstantIdIndividualSearchInfoRiskIndicators]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdIndividualSearchInfoRedFlags
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdIndividualSearchInfoRedFlags]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdIndividualSearchInfoRedFlags](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsInstantIdIndividualSearchInfoRedFlags_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[Category] [int] NOT NULL,
	[SearchInfo_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdIndividualSearchInfoRedFlags] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SearchInfo_Id] ON [dbo].[PdsInstantIdIndividualSearchInfoRedFlags]
(
	[SearchInfo_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsInstantIdIndividualSearchInfoRedFlags_CustomerId] ON [dbo].[PdsInstantIdIndividualSearchInfoRedFlags]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsInstantIdIndividualSearchInfoRedFlagRiskIndicators
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsInstantIdIndividualSearchInfoRedFlagRiskIndicators]    Script Date: 05/28/2013 14:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PdsInstantIdIndividualSearchInfoRedFlagRiskIndicators](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsInstantIdIndividualSearchInfoRFRiskIndicators_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[Code] [int] NOT NULL,
	[Sequence] [int] NOT NULL,
	[RedFlag_Id] [int] NOT NULL,
 CONSTRAINT [PK_dbo.PdsInstantIdIndividualSearchInfoRedFlagRiskIndicators] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_RedFlag_Id] ON [dbo].[PdsInstantIdIndividualSearchInfoRedFlagRiskIndicators]
(
	[RedFlag_Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_PdsInstantIdIndividualSearchInfoRedFlagRiskIndicators_CustomerId] ON [dbo].[PdsInstantIdIndividualSearchInfoRedFlagRiskIndicators]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.PdsWCSearchInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[PdsWCSearchInfo]    Script Date: 11/27/2013 13:19:00 ******/
CREATE TABLE [dbo].[PdsWCSearchInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL CONSTRAINT "DF_PdsWcSearchInfo_CustomerId" DEFAULT 0,
	[OriginalId] BIGINT NULL,
	[PredefinedSearchId] [int] NOT NULL,
	[FuzzyOptions_MinFuzzyLength] [int] NOT NULL,
	[FuzzyOptions_WildInsert] [bit] NOT NULL,
	[FuzzyOptions_WildReplace] [bit] NOT NULL,
	[FuzzyOptions_PairVariations] [bit] NOT NULL,
	[FuzzyOptions_PhoneticRank] [float] NOT NULL,
	[FuzzyOptions_MissingLetterWindowSize] [int] NOT NULL,
	[FuzzyOptions_MinNFFuzzyLength] [int] NOT NULL,
	[FuzzyOptions_FuzzyAlias] [bit] NOT NULL,
	[FuzzyOptions_FuzzyMultiplier] [float] NOT NULL,
	[FuzzyOptions_NonPhoneticFuzzyMultiplier] [float] NOT NULL,
	[FuzzyOptions_ExtraIndexFeatures_UseIgnoreLetterOrder] [bit] NOT NULL,
	[FuzzyOptions_ExtraIndexFeatures_UsePhonetic] [bit] NOT NULL,
	[SearchRanks_MAXRank] [float] NOT NULL,
	[SearchRank_ThisRank] [float] NOT NULL,
	[SearchRank_AliasRank] [float] NOT NULL,
	[SearchRank_PartialMatchRank] [float] NOT NULL,
	[SearchRank_TonicityRank] [float] NOT NULL,
	[SearchRank_MissingWordRank] [float] NOT NULL,
	[SearchRank_JoinNamesRank] [float] NOT NULL,
	[SearchRank_ExactRank] [float] NOT NULL,
	[SearchRank_SamePosRank] [float] NOT NULL,
	[SearchRank_HomophoneRank] [float] NOT NULL,
	[SearchOptions_SinglePairingThreshold] [int] NOT NULL,
	[SearchOptions_PartialMatchCount] [int] NOT NULL,
	[SearchOptions_MissingMatchCount] [int] NOT NULL,
	[SearchOptions_UseAlias] [bit] NOT NULL,
	[SearchOptions_UseCache] [bit] NOT NULL,
	[SearchOptions_UseStopWords] [bit] NOT NULL,
	[SearchOptions_UseNicknames] [bit] NOT NULL,
	[SearchOptions_RepeatedNames] [bit] NOT NULL,
	[SearchOptions_JoinNames] [bit] NOT NULL,
	[SearchOptions_WordOR] [bit] NOT NULL,
	[SearchOptions_KeyOR] [bit] NOT NULL,
	[SearchOptions_UseMatchType] [bit] NOT NULL,
	[SearchOptions_BroadDelta] [int] NOT NULL,
	[SearchOptions_FunkyNames] [smallint] NOT NULL,
	[SearchOptions_UseStopVariation] [bit] NOT NULL,
	[SearchOptions_UseCCC] [bit] NOT NULL,
	[IsEnableWCSearch] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_SearchWhitelist] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_AlertOnFalsePositiveMatches] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_DisplayFalsePositiveInAlert] [bit] NOT NULL,
	[ConfigAutomaticFalsePositiveRules_WriteFalsePositiveMatches] [bit] NOT NULL,
	[ConfigMatchDispositionRules_IndividualMatchDisposition] [bit] NOT NULL,
	[ConfigMatchDispositionRules_AutomaticFalsePositives] [bit] NOT NULL,
	[ConfigMatchDispositionRules_ReAlertOnChange] [bit] NOT NULL,
	[ConfigGeneralOptions_IgnoreVessels] [bit] NOT NULL,
	[ConfigGeneralOptions_AlertOnError] [bit] NOT NULL,
	[ConfigGeneralOptions_SaveAllResults] [bit] NOT NULL,
	[SearchOptions_HomophoneScripts] [varchar](255),
 CONSTRAINT [PK_PdsWCSearchInfo] PRIMARY KEY CLUSTERED
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE NONCLUSTERED INDEX [IX_PdsWcSearchInfo_CustomerId] ON [dbo].[PdsWcSearchInfo]
(
	[CustomerID] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_MinFuzzyLength]  DEFAULT ((5)) FOR [FuzzyOptions_MinFuzzyLength]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_WildInsert]  DEFAULT ((1)) FOR [FuzzyOptions_WildInsert]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_WildReplace]  DEFAULT ((1)) FOR [FuzzyOptions_WildReplace]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_PairVariations]  DEFAULT ((1)) FOR [FuzzyOptions_PairVariations]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_PhoneticRank]  DEFAULT ((0)) FOR [FuzzyOptions_PhoneticRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_MissingLetterWindowSize]  DEFAULT ((1)) FOR [FuzzyOptions_MissingLetterWindowSize]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_MinNFFuzzyLength]  DEFAULT ((3)) FOR [FuzzyOptions_MinNFFuzzyLength]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_FuzzyAlias]  DEFAULT ((0)) FOR [FuzzyOptions_FuzzyAlias]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_FuzzyMultiplier]  DEFAULT ((0.5)) FOR [FuzzyOptions_FuzzyMultiplier]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_NonPhoneticFuzzyMultiplier]  DEFAULT ((0.1)) FOR [FuzzyOptions_NonPhoneticFuzzyMultiplier]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_ExtraIndexFeatures_UseIgnoreLetterOrder]  DEFAULT ((0)) FOR [FuzzyOptions_ExtraIndexFeatures_UseIgnoreLetterOrder]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_FuzzyOptions_ExtraIndexFeatures_UsePhonetic]  DEFAULT ((0)) FOR [FuzzyOptions_ExtraIndexFeatures_UsePhonetic]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRanks_MAXRank]  DEFAULT ((8)) FOR [SearchRanks_MAXRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_ThisRank]  DEFAULT ((0)) FOR [SearchRank_ThisRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_AliasRank]  DEFAULT ((0.05)) FOR [SearchRank_AliasRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_PartialMatchRank]  DEFAULT ((0.03)) FOR [SearchRank_PartialMatchRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_TonicityRank]  DEFAULT ((0.02)) FOR [SearchRank_TonicityRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_MissingWordRank]  DEFAULT ((0.04)) FOR [SearchRank_MissingWordRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_JoinNamesRank]  DEFAULT ((0.04)) FOR [SearchRank_JoinNamesRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_ExactRank]  DEFAULT ((0)) FOR [SearchRank_ExactRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_SamePosRank]  DEFAULT ((0)) FOR [SearchRank_SamePosRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchRank_HomophoneRank]  DEFAULT ((0)) FOR [SearchRank_HomophoneRank]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_SinglePairingThreshold]  DEFAULT ((2)) FOR [SearchOptions_SinglePairingThreshold]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_PartialMatchCount]  DEFAULT ((0)) FOR [SearchOptions_PartialMatchCount]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_MissingMatchCount]  DEFAULT ((0)) FOR [SearchOptions_MissingMatchCount]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_UseAlias]  DEFAULT ((1)) FOR [SearchOptions_UseAlias]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_UseCache]  DEFAULT ((1)) FOR [SearchOptions_UseCache]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_UseStopWords]  DEFAULT ((1)) FOR [SearchOptions_UseStopWords]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_UseNicknames]  DEFAULT ((1)) FOR [SearchOptions_UseNicknames]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_RepeatedNames]  DEFAULT ((1)) FOR [SearchOptions_RepeatedNames]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_JoinNames]  DEFAULT ((1)) FOR [SearchOptions_JoinNames]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_WordOR]  DEFAULT ((0)) FOR [SearchOptions_WordOR]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_KeyOR]  DEFAULT ((0)) FOR [SearchOptions_KeyOR]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_Table_1_SearchType_UseMatchType]  DEFAULT ((0)) FOR [SearchOptions_UseMatchType]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_BroadDelta]  DEFAULT ((0)) FOR [SearchOptions_BroadDelta]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_FunkyNames]  DEFAULT ((0)) FOR [SearchOptions_FunkyNames]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_UseStopVariation]  DEFAULT ((1)) FOR [SearchOptions_UseStopVariation]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_UseCCC]  DEFAULT ((1)) FOR [SearchOptions_UseCCC]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_IsEnableWCSearch]  DEFAULT ((0)) FOR [IsEnableWCSearch]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigAutomaticFalsePositiveRules_SearchWhitelist]  DEFAULT ((0)) FOR [ConfigAutomaticFalsePositiveRules_SearchWhitelist]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigAutomaticFalsePositiveRules_AlertOnFalsePositiveMatches]  DEFAULT ((0)) FOR [ConfigAutomaticFalsePositiveRules_AlertOnFalsePositiveMatches]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigAutomaticFalsePositiveRules_DisplayFalsePositiveInAlert]  DEFAULT ((0)) FOR [ConfigAutomaticFalsePositiveRules_DisplayFalsePositiveInAlert]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigAutomaticFalsePositiveRules_WriteFalsePositiveMatches]  DEFAULT ((0)) FOR [ConfigAutomaticFalsePositiveRules_WriteFalsePositiveMatches]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigMatchDispositionRules_IndividualMatchDisposition]  DEFAULT ((0)) FOR [ConfigMatchDispositionRules_IndividualMatchDisposition]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigMatchDispositionRules_AutomaticFalsePositives]  DEFAULT ((0)) FOR [ConfigMatchDispositionRules_AutomaticFalsePositives]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigMatchDispositionRules_ReAlertOnChange]  DEFAULT ((0)) FOR [ConfigMatchDispositionRules_ReAlertOnChange]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigGeneralOptions_IgnoreVessels]  DEFAULT ((0)) FOR [ConfigGeneralOptions_IgnoreVessels]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigGeneralOptions_AlertOnError]  DEFAULT ((0)) FOR [ConfigGeneralOptions_AlertOnError]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_ConfigGeneralOptions_SaveAllResults]  DEFAULT ((0)) FOR [ConfigGeneralOptions_SaveAllResults]
GO

ALTER TABLE [dbo].[PdsWCSearchInfo] ADD  CONSTRAINT [DF_PdsWCSearchInfo_SearchOptions_HomophoneScripts]  DEFAULT (('')) FOR [SearchOptions_HomophoneScripts]
GO

/* ALTER TABLE [dbo].[PdsWCSearchInfo]  WITH CHECK ADD  CONSTRAINT [FK_PdsWCSearchInfo_PdsWCSearchInfo] FOREIGN KEY([PredefinedSearchId])
REFERENCES [dbo].[PdsPredefinedSearchInfo] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PdsWCSearchInfo] CHECK CONSTRAINT [FK_PdsWCSearchInfo_PdsWCSearchInfo]
GO */

--=====================================================================================================

--+++++++++++++C:\Development\trunk\Src\LN.SystemHistory\LN.SystemHistory.Business+++++++++++++++

--=====================================================================================================
--Src\LN.SystemHistory\LN.SystemHistory.Business
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AuditAction](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[OriginalId] BIGINT NULL,
	[Action] [int] NOT NULL,
	[ActionDescription] [nvarchar](100) NULL,
	[Area] [int] NOT NULL,
	[AreaDescription] [nvarchar](100) NULL,
	[AuditUserId] [int] NULL,
	[AuditUserName] [nvarchar](100) NULL,
	[ActionDate] [datetime] NOT NULL,
	[LongRecordId] [bigint] NOT NULL,
	[Data] [nvarchar](max) NULL,
	[Source] [nvarchar](255) NULL,
 CONSTRAINT [PK_dbo.AuditAction] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/****** Object:  Index [IDX_AA_CI_AD_A_AU]    Script Date: 1/24/2014 12:18:38 PM ******/
CREATE NONCLUSTERED INDEX [IDX_AA_CI_AD_A_AU] ON [dbo].[AuditAction]
(
	[CustomerId] ASC,
	[ActionDate] ASC,
	[Area] ASC,
	[AuditUserId]
)
INCLUDE ([Action]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

/****** Object:  Index [IDX_AA_CI_AD_AD_AD]   Script Date: 1/24/2014 12:18:38 PM ******/
CREATE NONCLUSTERED INDEX [IDX_AA_CI_AD_AD_AD] ON [dbo].[AuditAction]
(
	[CustomerId] ASC,
	[ActionDate] ASC,
	[AreaDescription] ASC,
	[ActionDescription] ASC
)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


--=====================================================================================================

--+++++++++++++C:\Development\trunk\Src\LN.OverrideList+++++++++++++++

--=====================================================================================================
--overridelist
-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlAcceptList
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlAcceptList]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlAcceptList](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[UniqueId] [BINARY](16) NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlAcceptList_CustomerId" DEFAULT(0),
	[Name] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[PublicationDate] [datetime] NULL,
	[Comments] [nvarchar](max) NULL,
	[AccountNumbers] [bit] NOT NULL,
	[Encrypt] [bit] NOT NULL CONSTRAINT "DF_OlAcceptList_Encrypt" default(0),
	[UserSelectedStatusRequired] [bit] NOT NULL CONSTRAINT "DF_OlAcceptList_UserSelectedStatusRequired" default(0),
	[StatusRequired] [bit] NOT NULL,
	[IsDefault] [bit] NOT NULL,
	[SearchCriteria] [nvarchar](255) NULL,
	[AutomaticallyIndex] [bit] NOT NULL,
	[IsEnterprise] [bit] NOT NULL CONSTRAINT "DF_OlAcceptList_IsEnterprise" default(0),
	[DateModified] [datetime] NULL,
	[AllDivisions] [bit] NOT NULL CONSTRAINT "DF_OlAcceptList_AllDivisions" default(0),
	[OriginalId] [BIGINT] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlAcceptList_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.OlAcceptList] PRIMARY KEY CLUSTERED
(
	[Id] ASC
))
GO
CREATE NONCLUSTERED INDEX [IX_Olacceptlist_CustomerId] ON [dbo].[Olacceptlist] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlAcceptList_CustomerId_IsDeleted] ON [OlAcceptList]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CustomerID_AcceptListName] ON [OlAcceptList]
(
	[CustomerId] ASC,
        [Name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlWhiteListInput
-- ----------------------------------------------------------------------------

/****** Object:  Table [dbo].[OlWhiteListInput]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlWhiteListInput](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlWhiteListInput_CustomerId" DEFAULT(0),
	[InputText] [nvarchar](255) NOT NULL,
	[SearchType] [int] NOT NULL,
	[InputIdType] [int] NOT NULL,
	[InputId] [nvarchar](255) NULL,
	[AddedBy] [nvarchar](255) NULL,
	[ModifiedDate] [datetime] NOT NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlWhiteListInput_IsDeleted" default(0),
	[OriginalId] [BIGINT] NULL,
 CONSTRAINT [PK_dbo.OlWhiteListInput] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_Olwhitelistinput_CustomerId] ON [dbo].[Olwhitelistinput] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlWhiteListMatch
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlWhiteListMatch]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlWhiteListMatch](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[WhiteListId] [int] NOT NULL,
	[MatchText] [nvarchar](255) NOT NULL,
	[Source] [nvarchar](255) NULL,
	[SourceNumber] [nvarchar](255) NULL,
	[MinScore] [int] NULL,
	[MaxScore] [int] NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlWhiteListMatch_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
CONSTRAINT [PK_dbo.OlWhiteListMatch] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_WhiteListId] ON [dbo].[OlWhiteListMatch]
(
	[WhiteListId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Olwhitelistmatch_CustomerId] ON [dbo].[Olwhitelistmatch] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlEntities
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlEntities]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlEntities](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[AcceptListId] [int] NOT NULL,
	[TypeId] [int] NOT NULL,
	[Title] [nvarchar](255) NULL,
	[FirstName] [nvarchar](255) NULL,
	[MiddleName] [nvarchar](255) NULL,
	[LastName] [nvarchar](255) NULL,
	[Generation] [nvarchar](255) NULL,
	[FullName] [nvarchar](818) NULL,
	[Gender] [int] NOT NULL,
	[ListedDate] [datetime] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[FileName] [nvarchar](255) NULL,
	[ReasonListed] [nvarchar](255) NULL,
	[ReferenceNumber] [nvarchar](100) NULL,
	[Comments] [nvarchar](max) NULL,
	[SearchCriteria] [nvarchar](255) NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](255) NULL,
	[City] [nvarchar](240) NULL,
	[State] [nvarchar](100) NULL,
	[Country] [nvarchar](200) NULL,
	[ssnEin] [nvarchar](255) NULL,
	[AccountId] [nvarchar](255) NULL,
	[MatchDetails] [varbinary](max) NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlEntities_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlEntities_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.OlEntities] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_AcceptListId] ON [dbo].[OlEntities]
(
	[AcceptListId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Olentities_CustomerId] ON [dbo].[Olentities] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlEntities_CustomerId_IsDeleted] ON [OlEntities]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlDivisions
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlDivisions]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlDivisions](
	[AcceptListId] [int] NOT NULL,
	[DivisionId] [int] NOT NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlDivisions_CustomerId" DEFAULT(0),
 CONSTRAINT [PK_dbo.OlDivisions] PRIMARY KEY CLUSTERED
(
	[AcceptListId] ASC,
	[DivisionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_AcceptListId] ON [dbo].[OlDivisions]
(
	[AcceptListId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CustomerId] ON [dbo].[Oldivisions] 
(
	[CustomerId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlPhoneNumbers
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlPhoneNumbers]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlPhoneNumbers](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[EntityId] [int] NOT NULL,
	[TypeId] [int] NOT NULL,
	[Number] [nvarchar](30) NULL,
	[NumberUnformatted] [nvarchar](30) NULL,
	[Comments] [nvarchar](max) NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlPhoneNumbers_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
        [DateModified] [DateTime] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlPhoneNumbers_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.OlPhoneNumbers] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_EntityId] ON [dbo].[OlPhoneNumbers]
(
	[EntityId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Olphonenumbers_CustomerId] ON [dbo].[Olphonenumbers] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlPhoneNumbers_CustomerId_IsDeleted] ON [OlPhoneNumbers]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF._ResultFprModelReason
-- ----------------------------------------------------------------------------
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResultFprModelReason] (
  [FprModelId] [int] NOT NULL, 
  [FprReasonId] [bigint] NOT NULL,
  CONSTRAINT [PK_ResultFprModelReason] PRIMARY KEY CLUSTERED
  (
	[FprModelId] ASC, FprReasonId ASC
  )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlMatchData
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlMatchData]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlMatchData](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[EntityId] [int] NOT NULL,
	[WLEntityId] [nvarchar](48) NULL,
	[InputHash] [nvarchar](200) NULL,
	[IsCustomerFile] [bit] NOT NULL,
	[EntityName] [nvarchar](818) NULL,
	[EntityScore] [int] NULL,
	[IsBestName] [bit] NOT NULL,
	[IsTrueMatch] [bit] NOT NULL,
	[BestName] [nvarchar](818) NULL,
	[FileName] [nvarchar](2000) NULL,
	[FileDate] [datetime] NULL,
	[PublishedDate] [datetime] NULL,
	[CheckSum] [int] NULL,
	[LastAlertResultId] [bigint] NULL,
	[OriginatingResultId] [bigint] NULL,
	[WasCheckSumUpdated] [bit] NOT NULL DEFAULT 0,
	[ResultMatchId] [bigint] NOT NULL DEFAULT 0,
    [HasFalseHitAlerted] BIT NOT NULL DEFAULT 0,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlMatchData_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
        [DateModified] [DateTime] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlMatchData_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.OlMatchData] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_EntityId] ON [dbo].[OlMatchData]
(
	[EntityId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlMatchData_WLEntityId] ON [dbo].[OlMatchData]
(
	[WLEntityId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Olmatchdata_CustomerId] ON [dbo].[Olmatchdata] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlMatchData_CustomerId_IsDeleted] ON [OlMatchData]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlIdentifications
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlIdentifications]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlIdentifications](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[EntityId] [int] NOT NULL,
	[TypeId] [int] NOT NULL,
	[Label] [nvarchar](255) NULL,
	[Number] [nvarchar](255) NULL,
	[NumberUnformatted] [nvarchar](255) NULL,
	[IssueBy] [nvarchar](255) NULL,
	[IssuedDate] [datetime] NULL,
	[IssuedDateParsed] [nvarchar](255) NULL,
	[ExpirationDate] [datetime] NULL,
	[ExpirationDateParsed] [nvarchar](255) NULL,
	[Comments] [nvarchar](max) NULL,
	[HashCode] [nvarchar](50) NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlIdentifications_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
        [DateModified] [DateTime] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlIdentifications_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.OlIdentifications] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_EntityId] ON [dbo].[OlIdentifications]
(
	[EntityId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlIdentifications_Hashcode] ON [dbo].[OlIdentifications]
(
	[Hashcode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Olidentifications_CustomerId] ON [dbo].[Olidentifications] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlIdentifications_CustomerId_IsDeleted] ON [OlIdentifications]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlAkas
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlAkas]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlAkas](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[EntityId] [int] NOT NULL,
	[TypeId] [int] NOT NULL,
	[Category] [nvarchar](50) NULL,
	[Title] [nvarchar](255) NULL,
	[FirstName] [nvarchar](255) NULL,
	[MiddleName] [nvarchar](255) NULL,
	[LastName] [nvarchar](255) NULL,
	[Generation] [nvarchar](50) NULL,
	[FullName] [nvarchar](818) NULL,
	[Comments] [nvarchar](max) NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlAkas_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
        [DateModified] [DateTime] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlAkas_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.OlAkas] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_EntityId] ON [dbo].[OlAkas]
(
	[EntityId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Olakas_CustomerId] ON [dbo].[Olakas] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlAkas_CustomerId_IsDeleted] ON [OlAkas]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlAddresses
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlAddresses]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlAddresses](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[EntityId] [int] NOT NULL,
	[TypeId] [int] NOT NULL,
	[AddressLine1] [nvarchar](255) NULL,
	[AddressLine2] [nvarchar](255) NULL,
	[City] [nvarchar](120) NULL,
	[State] [nvarchar](50) NULL,
	[PostalCode] [nvarchar](20) NULL,
	[Country] [nvarchar](100) NULL,
	[Comments] [nvarchar](max) NULL,
	[HashCode] [nvarchar](50) NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlAddresses_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
        [DateModified] [DateTime] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlAddresses_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.OlAddresses] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_EntityId] ON [dbo].[OlAddresses]
(
	[EntityId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlAddresses_Hashcode] ON [dbo].[OlAddresses]
(
	[Hashcode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Oladdresses_CustomerId] ON [dbo].[Oladdresses] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlAddresses_CustomerId_IsDeleted] ON [OlAddresses]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
-- ----------------------------------------------------------------------------
-- Table BridgerRF.OlAdditionalInfo
-- ----------------------------------------------------------------------------
/****** Object:  Table [dbo].[OlAdditionalInfo]    Script Date: 01/09/2014 12:12:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OlAdditionalInfo](
	[Id] [int] IDENTITY(2,2) NOT NULL,
	[EntityId] [int] NOT NULL,
	[TypeId] [int] NOT NULL,
	[Value] [nvarchar](512) NULL,
	[ParsedValue] [nvarchar](512) NULL,
	[ParsedDob] [datetime] NULL,
	[Comments] [nvarchar](max) NULL,
	[CustomerId] [INT] NOT NULL CONSTRAINT "DF_OlAdditionalInfo_CustomerId" DEFAULT(0),
	[OriginalId] [BIGINT] NULL,
        [DateModified] [DateTime] NULL,
	[IsDeleted] [bit] NOT NULL CONSTRAINT "DF_OlAdditionalInfo_IsDeleted" default(0),
 CONSTRAINT [PK_dbo.OlAdditionalInfo] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_EntityId] ON [dbo].[OlAdditionalInfo]
(
	[EntityId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Oladditionalinfo_CustomerId] ON [dbo].[Oladditionalinfo] 
(
	[CustomerId] ASC, [Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OlAdditionalInfo_CustomerId_IsDeleted] ON [OlAdditionalInfo]
(
	[CustomerId] ASC,
        [IsDeleted] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

CREATE TABLE [dbo].[RuleResultsTrigger] (
  [Id] int NOT NULL IDENTITY(2,2),
  [RuleId] int NOT NULL,
  [RuleSetId] int NOT NULL,
  [RuleName] varchar(100) NOT NULL,
  [RuleDescription] varchar(255) DEFAULT NULL,
  [RuleOrder] int NOT NULL,
  [Triggered] bit NOT NULL,
  [RuleVersion] int NOT NULL,
  [ResultRecordId] bigint NOT NULL,
  [WouldHaveTriggered] bit NOT NULL,
  [RuleUniqueId] BINARY(16) NULL,
  [CustomerId] INT NOT NULL CONSTRAINT DF_RuleResultsTrigger_CustomerId DEFAULT 0,
  [OriginalId] BIGINT NULL,
  CONSTRAINT [PK_dbo.RuleResultsTrigger] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_RuleResultsTrigger_CustomerId] ON [dbo].[RuleResultsTrigger] 
(
	[CustomerId] ASC,	
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.CustomerScreeningListMatches
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[CustomerScreeningListMatches] (
  [Id] [int] IDENTITY(2,2) NOT NULL,
  [CustomerId] INT NOT NULL CONSTRAINT "DF_SLM_CustomerId" DEFAULT 0,
  [ScreeningListName] VARCHAR(255) NOT NULL,
  CONSTRAINT [PK_dbo.CustomerScreeningListMatches] PRIMARY KEY CLUSTERED
  (
	[Id] ASC
  )
)
GO
CREATE NONCLUSTERED INDEX [IX_CSLM_CustomerId_ScreeningListName] ON [dbo].[customerscreeninglistmatches]
(
	[CustomerId] ASC,
	[ScreeningListName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ClientUsageTimes
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[ClientUsageTimes] (
  [Id] BIGINT NOT NULL IDENTITY(1,1),
  [DateCreated] DATETIME  NOT NULL,
  [HourCreated] INT NOT NULL,
  [State] TINYINT NOT NULL,
  CONSTRAINT [PK_dbo.ClientUsageTimes] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)
)
GO
  

-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultScreeningListMatches
-- ----------------------------------------------------------------------------
CREATE TABLE [dbo].[ResultScreeningListMatches] (
  [Id] [int] IDENTITY(2,2) NOT NULL,
  [ResultRecordId] BIGINT NOT NULL CONSTRAINT "DF_RSLM_RRID" DEFAULT 0,
  [CustomerScreeningListMatchId] INT NOT NULL CONSTRAINT "DF_RSLM_CSLMID" DEFAULT 0,
  [CustomerId] INT NOT NULL CONSTRAINT "DF_Result_ScreeningList_Matches_CustomerId" DEFAULT 0,
  [DateCreated] DATETIME NOT NULL CONSTRAINT "DF_RSLM_DateCreated" DEFAULT CURRENT_TIMESTAMP,
  [OriginalId] BIGINT NULL,
  CONSTRAINT [PK_dbo.ResultScreeningListMatches] PRIMARY KEY CLUSTERED
  (
	[Id] ASC,
	[DateCreated] ASC
  )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_RSLM_RRId_CSLMId] ON [dbo].[resultscreeninglistmatches]
(
	[ResultRecordId] ASC,
	[CustomerScreeningListMatchId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO


CREATE TABLE [dbo].[_LegacyTableTypes] (
  [Id] SMALLINT NOT NULL,
  [Table_Name] varchar(50) NOT NULL,
  PRIMARY KEY ([Id])
)
GO

-- Common Tables
insert into _LegacyTableTypes(Table_Name,Id) values('usermgmtcustomers',1),('usermgmtdivisions',2),('usermgmtroles',3),('usermgmtusers',4);
-- System Tables
insert into _LegacyTableTypes(Table_Name,Id) values('batchconfiguration',5),('batchcustomfileformat',6),('batchrun',7),('cwladditionalinfo',8),('cwladdress',9),('cwlaka',10),('cwlassigneddivision',11),
				('cwlcountryaka',12),('cwlcountryentity',13),('cwlcountrylocation',14),('cwlcustomfileformat',15),('cwlcustomformatentity',16),('cwlcustomformatfield',17),('cwlcustomwatchlist',18),
                ('cwldeploymentqueue',19),('cwlentity',20),('cwlidentification',21),('cwlmanualbuildqueue',22),('cwlphonenumber',23),('cwlpurgequeue',24),('cwlreason',25),('olacceptlist',26),
                ('oladditionalinfo',27),('oladdresses',28),('olakas',29),('oldivisions',30),('olentities',31),('olidentifications',32),('olmatchdata',33),('olphonenumbers',34),('olwhitelistinput',35),
                ('olwhitelistmatch',36),('pdspredefinedsearchinfo',37),('pdsrunstatus',38),('resultalertattachment',39),('resultalertfilter',40),('resultauditrecord',41),('resultentityadditionalinfo',42),
                ('resultentityaddress',43),('resultentityphonenumber',44),('resultinputentity',45),('resultinputentityidentification',46),('resultmatch',47),('resultrecord',48),('resultset',49),('resultstatus',50), 
				('auditaction',51), ('resultaccounttype',52),('batchrunwatchlist',53);
				
								

CREATE TABLE [dbo].[_LegacyIDs] (
  [Id] BIGINT NOT NULL IDENTITY(2,2),
  [Table_Type] SMALLINT NOT NULL CONSTRAINT "DF_LegacyIDs_Table_Type" DEFAULT 0,
  [Customer_Id] INT NOT NULL,
  [ID4X] BIGINT NOT NULL,
  [ID5X] BIGINT NOT NULL,
  [LegacyRecordValue] VARCHAR(255) NULL,
  PRIMARY KEY ([Id])
)
GO
CREATE NONCLUSTERED INDEX [IX_LegacyIds_Customer_ID4X] ON [dbo].[_LegacyIDs]
(
	[Customer_Id] ASC,
	[ID4X] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO
CREATE NONCLUSTERED INDEX [IX_LegacyIds_Customer_ID5X] ON [dbo].[_LegacyIDs]
(
	[Customer_Id] ASC,
	[ID5X] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
GO

CREATE TABLE [dbo].[ResultMatchIndicatorRange](
	[Id] [bigint] IDENTITY(2,2) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[DateModified] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[EntityName] [nvarchar](255) NULL,
	[EntityValueType] [int] NOT NULL,
	[EntityValue] [int] NOT NULL,
	[MaxValue] [int] NOT NULL,
	[OriginalId] [BIGINT] NULL
	 CONSTRAINT [PK_dbo.ResultMatchIndicatorRange] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ResultMatchIndicatorRange] ADD  CONSTRAINT [DF_ResultMatchIndicatorRange_CustomerId]  DEFAULT ((0)) FOR [CustomerId]
GO


/****** Object:  Table [dbo].[GetResultRecordDTO]    Script Date: 01/09/2014 12:12:07 ******/
if OBJECTPROPERTY(object_id('dbo.GetResultRecordDTO'), N'IsProcedure') is null exec sp_executesql N'CREATE PROCEDURE dbo.GetResultRecordDTO(@rid bigint) AS begin return; end';
go

ALTER PROCEDURE [dbo].[GetResultRecordDTO]
(
	@rid bigint
)
as
	set nocount on;

	-- Result Record
	select TOP 1 ResultRecord.*, ResultSet.PredefinedSearchId, ResultSet.AppliedModelId, ResultSet.CustomFormatUsed, ResultSet.BatchFileName, ResultSet.BatchRunId, EftRecord.RawEFT UnstructuredEFT, EftRecord.CompressedRawEFT CompressedUnstructuredEFT
	from ResultRecord with (NOLOCK)
	inner join ResultSet ResultSet with (NOLOCK) on ResultSet.Id = ResultRecord.ResultSetId
	left join ResultEFTRecord EftRecord with (NOLOCK) on EftRecord.EFTId = ResultRecord.EFTId
	where ResultRecord.Id = @rid;

   -- =========== Input  ======================================
	select *, [Text] as Context from ResultInputEntity with (NOLOCK) where Id = @rid;
	if @@ROWCOUNT > 0
	begin
		select Name_First [First], Name_Full [Full], Name_Generation Generation, Name_Last Last, Name_Middle Middle, Maiden, SecondSurname, Name_Title Title from ResultInputEntity with (NOLOCK) where Id = @rid;
		select ResultRecord.Account_Amount as [Amount], ResultRecord.Account_Date as [Date], ResultRecord.Account_GroupId as [GroupId], ResultRecord.Account_MemberId as [MemberId], ResultRecord.Account_Number as [Number], ResultRecord.Account_OtherData as [OtherData], ResultRecord.Account_ProviderId as [ProviderId], ResultRecord.Account_Type as [Type], ResultRecord.Account_Number as [UnformattedNumber] from ResultRecord with (NOLOCK) where Id = @rid and (Account_Amount is not null OR Account_Date is not null OR Account_GroupId is not null OR Account_MemberId is not null OR Account_Number is not null OR Account_OtherData is not null OR Account_ProviderId is not null OR Account_Type is not null);
		select * from ResultEntityAdditionalInfo with (NOLOCK) where InputEntity_Id = @rid;
		select * from ResultEntityAddress entityAddr with (NOLOCK) where entityAddr.InputEntity_Id = @rid;
		select * from ResultInputEntityIdentification with (NOLOCK) where InputEntity_Id = @rid;
		select Id, PhoneType as [Type], Number, UnformattedNumber, Instance, InputEntity_Id from ResultEntityPhoneNumber with (NOLOCK) where InputEntity_Id = @rid;
	end

	-- =========== Other Data ======================================
    -- result.AlertAttachments = multi.Read<AlertAttachmentDTO>().ToList();
	select Id, DateCreated, CreatedBy, DateModified, ModifiedBy, FileName, FileType, Notes, DateDeleted, ResultRecordId from ResultAlertAttachment with (NOLOCK) where ResultRecordId = @rid and DateDeleted is null; -- don't return the attachment data!

	-- result.AuditRecords = multi.Read<AuditRecordDTO>().ToList();
	select *, @rid as ResultRecordId from ResultAuditRecord with (NOLOCK) where ResultRecord_Id = @rid;

	-- result.ResultAssignments = multi.Read<ResultAssignmentDTO>().ToList();
	select * from ResultRecordAssignment with (NOLOCK) where ResultRecordId = @rid;

	-- result.OfacReport = multi.Read<OfacReportDTO>().FirstOrDefault();
	select * from ResultOfacReport with (NOLOCK) where id = @rid;
	if @@ROWCOUNT > 0
	begin
		select ResultOfacInstitutionInfo.*
		from ResultOfacReport with (NOLOCK)
		inner join ResultOfacInstitutionInfo with (NOLOCK) on OfacReport_Id = ResultOfacReport.Id
		where ResultOfacReport.id = @rid;
	end

	-- This is for the World Compliance Plugin that was developed but is not currently used:
    -- result.WCResult = multi.Read<WCResultDTO>().FirstOrDefault();
	-- select * from ResultWcResult where ResultWcResult.Id = @id;
	-- if @@ROWCOUNT > 0
	-- then
		-- select ResultWCMatchOccurrence.*
		-- from ResultWcResult
		-- inner join ResultWCMatchOccurrence on WCResult_Id = ResultWcResult.Id;
	-- end if;

	-- =========== WatchListResult ======================================
	select * from ResultWatchListResult where Id = @rid;
	if @@ROWCOUNT > 0
	begin
		-- select Id into #matchIds from ResultMatch with (NOLOCK) where WatchListResult_Id = @rid;
	 select m.Id as Id, IsUnstructured, SearchWord, IsAutomaticFalsePositive, CountryContext, NameContext, IsEFTMatch, IsFalsePositive, IsRealert, m.CheckSum, EntityUniqueID,
     IsTypeConflict, IsConflict, IsBestMatch, BestNameMatch, BestNameScore, IsMatch, Score, EFTContextEnd, EFTContextStart, IsMatchGenderConflict, IsOfacScreened, IsOfacScreened2, Collapsed, DisplayState,
     Country, Gender, [Type], Number, [Date], Reason, NoteData.NoteData as NoteBytes, WatchListResult_Id, PrevResultID, IsNameFromAddressMatch, m.DateCreated as DateCreated, m.ChildrenXML, IsXmlCompressed,
	 FalseHitTriggerType, IsFalseMatchUpdate, IsGenderMatch, FalseHitAcceptListId, OAL.Name as FalseHitAcceptListName, FalseHitEntityId, FalseHitMatchId, OMD.LastAlertResultId as FalseHitLastAlertId,
	 -- rename Name columns, Id is needed too for the dapper multi-read
     m.Id as Id, Name_First First, Name_Full [Full], Name_Generation Generation, Name_Last Last, Name_Middle Middle, Name_Title Title,
	 -- rename File columns, Id is needed too for the dapper multi-read
     m.Id as Id, File_Build Build, File_IsCustom IsCustom, File_Name Name, File_Published Published, File_SelectionInstance SelectionInstance, File_Type FileType, File_WatchlistId WatchlistIdBytes,
	 -- get ResultMatchDetail columns, Id is needed too for the dapper multi-read
     m.Id as Id, m.DateCreated as DateCreated, UniqueDetail.MatchData, ResultMatchDetail.CustomerId, ResultMatchDetail.HashedValue, ResultMatchDetail.RuleTriggersData, ResultMatchDetail.CountryInputType,
	 -- get ResultMatchFprDetail columns, Id is needed too for the dapper multi-read
	 ResultMatchFprDetail.Id as Id, ResultMatchFprDetail.DateCreated as DateCreated, ResultMatchFprDetail.CustomerId, ResultMatchFprDetail.IsFprFalsePositive, ResultMatchFprDetail.Probability, ResultMatchFprDetail.ReasonCodes

	 from
		ResultMatch m with (NOLOCK)
		left join ResultMatchDetail with (NOLOCK) on m.Id = ResultMatchDetail.Id
		left join ResultMatchUniqueDetail AS UniqueDetail WITH(NOLOCK) ON ResultMatchDetail.CustomerId = UniqueDetail.CustomerId AND ResultMatchDetail.HashedValue = UniqueDetail.HashedValue
		left join ResultMatchUniqueHash AS UniqueHash WITH(NOLOCK) ON ResultMatchDetail.CustomerId = UniqueHash.CustomerId AND ResultMatchDetail.HashedValue = UniqueHash.HashedValue
		left join ResultMatchNoteData AS NoteData WITH(NOLOCK) ON ResultMatchDetail.CustomerId = NoteData.CustomerId AND ResultMatchDetail.HashedNoteDataValue = NoteData.HashedValue
		left join ResultMatchNoteDataHash AS NoteDataHash WITH(NOLOCK) ON ResultMatchDetail.CustomerId = NoteDataHash.CustomerId AND ResultMatchDetail.HashedNoteDataValue = NoteDataHash.HashedValue
		left join ResultMatchFprDetail ON m.Id = ResultMatchFprDetail.Id
		left join OlAcceptList as OAL on m.FalseHitAcceptListId = OAL.Id
        left join OlMatchData as OMD on m.FalseHitMatchId = OMD.Id
		where WatchListResult_Id = @rid order by m.Id;
	end

	-- =========== FactivaMediaResult ======================================
	select * from ResultFactivaMediaResult with (NOLOCK) where Id = @rid;

	-- =========== FraudPointResult ======================================
	select * from ResultFraudPointResult with (NOLOCK) where Id = @rid;
	if @@ROWCOUNT > 0
	begin
		select * from ResultFraudPointRiskIndicator with (NOLOCK) where FraudPointResult_Id = @rid;
		select * from ResultFraudPointRedFlag with (NOLOCK) where FraudPointResult_Id = @rid order by Id;
		select ResultFraudPointRedFlagRiskIndicator.*, FraudPointRedFlag_Id RedFlagId
		from ResultFraudPointRedFlag redFlag with (NOLOCK)
		inner join ResultFraudPointRedFlagRiskIndicator with (NOLOCK) on FraudPointRedFlag_Id = redFlag.Id
		where FraudPointResult_Id = @rid
		order by redFlag.Id;
	end

	-- =========== InstantIdBusinessResult ======================================
	select *,
		Id, InputEcho_CompanyName CompanyName, InputEcho_FEIN FEIN, InputEcho_PhoneNumber PhoneNumber,
		Id, InputEcho_CompanyAddress_Type Type, InputEcho_CompanyAddress_AddressLine1 AddressLine1, InputEcho_CompanyAddress_AddressLine2 AddressLine2, InputEcho_CompanyAddress_City City, InputEcho_CompanyAddress_State State, InputEcho_CompanyAddress_County County, InputEcho_CompanyAddress_PostalCode PostalCode, InputEcho_CompanyAddress_CountryCode CountryCode, InputEcho_CompanyAddress_StreetNumber StreetNumber, InputEcho_CompanyAddress_StreetName StreetName, InputEcho_CompanyAddress_StreetPreDirection StreetPreDirection, InputEcho_CompanyAddress_StreetPostDirection StreetPostDirection, InputEcho_CompanyAddress_StreetType StreetType, InputEcho_CompanyAddress_FullAddress FullAddress, InputEcho_CompanyAddress_SubBuildingNumber SubBuildingNumber, InputEcho_CompanyAddress_UnitDesignation UnitDesignation, InputEcho_CompanyAddress_UnitNumber UnitNumber, InputEcho_CompanyAddress_Instance Instance
		from ResultInstantIdBusinessResult with (NOLOCK) where Id = @rid;
	if @@ROWCOUNT > 0
	begin
		select *, Id, Address_Type Type, Address_AddressLine1 AddressLine1, Address_AddressLine2 AddressLine2, Address_City City, Address_State State, Address_County County, Address_PostalCode PostalCode, Address_CountryCode CountryCode, Address_StreetNumber StreetNumber, Address_StreetName StreetName, Address_StreetPreDirection StreetPreDirection, Address_StreetPostDirection StreetPostDirection, Address_StreetType StreetType, Address_FullAddress FullAddress, Address_SubBuildingNumber SubBuildingNumber, Address_UnitDesignation UnitDesignation, Address_UnitNumber UnitNumber, Address_Instance Instance
			from ResultBusinessInfo with (NOLOCK) where InstantIdBusinessResultId = @rid;
		select * from ResultInstantIdBusinessRiskIndicator with (NOLOCK) where InstantIdBusinessResult_Id = @rid;
		select * from ResultInstantIdBusinessRedFlag with (NOLOCK) where InstantIdBusinessResult_Id = @rid order by Id;
		select ResultInstantIdBusinessRedFlagRiskIndicator.*, InstantIdBusinessRedFlag_Id RedFlagId
		from ResultInstantIdBusinessRedFlag redFlag with (NOLOCK)
		inner join ResultInstantIdBusinessRedFlagRiskIndicator with (NOLOCK) on InstantIdBusinessRedFlag_Id = redFlag.Id
		where InstantIdBusinessResult_Id = @rid
		order by redFlag.Id;
	end

	-- =========== InstantIdIndividualResult ======================================
	-- Dapper can only do 7 objects so break up the main select
	select Id, NAP, NAS, [Index], DateCreated, OriginalSource, ErrorCd, ErrorMessage, IsAlert, IsRedFlagsEnabled, IndexGeneratedAlert, NAPGeneratedAlert, NASGeneratedAlert, PhoneAtAddress, Glba, Dppa, SearchPerformed, [UniqueIdentifier], FollowupActions, [Version], [DOBMatchLevel], [DOBVerified],
		/* CurrentName */ Id, CurrentName_First [First], CurrentName_Full [Full], CurrentName_Generation Generation, CurrentName_Last [Last], CurrentName_Middle Middle, CurrentName_Title Title,
		/* SSNInfo */ Id, SSNInfo_Valid Valid, SSNInfo_SSN SSN, SSNInfo_IssuingLocation IssuingLocation, SSNInfo_StartDate StartDate, SSNInfo_EndDate EndDate,
		/* Input Echo */ Id, InputEcho_DOB DOB, InputEcho_SSN SSN, InputEcho_HomePhone HomePhone, InputEcho_WorkPhone WorkPhone, InputEcho_DriverLicenseNumber DriverLicenseNumber, InputEcho_DriverLicenseState DriverLicenseState,
		/* Input Echo.Address */ Id, InputEcho_Address_Type Type, InputEcho_Address_AddressLine1 AddressLine1, InputEcho_Address_AddressLine2 AddressLine2, InputEcho_Address_City City, InputEcho_Address_State State, InputEcho_Address_County County, InputEcho_Address_PostalCode PostalCode, InputEcho_Address_CountryCode CountryCode, InputEcho_Address_StreetNumber StreetNumber, InputEcho_Address_StreetName StreetName, InputEcho_Address_StreetPreDirection StreetPreDirection, InputEcho_Address_StreetPostDirection StreetPostDirection, InputEcho_Address_StreetType StreetType, InputEcho_Address_FullAddress FullAddress, InputEcho_Address_SubBuildingNumber SubBuildingNumber, InputEcho_Address_UnitDesignation UnitDesignation, InputEcho_Address_UnitNumber UnitNumber, InputEcho_Address_Instance Instance,
		/* Input Echo.Name */ Id, InputEcho_Name_First [First], InputEcho_Name_Full [Full], InputEcho_Name_Generation Generation, InputEcho_Name_Last [Last], InputEcho_Name_Middle Middle, InputEcho_Name_Title Title
		from ResultInstantIdIndividualResult with (NOLOCK) where Id = @rid;
	if @@ROWCOUNT > 0
	begin
		select
			/* VerifiedInput */ Id, VerifiedInput_SSN SSN, VerifiedInput_HomePhone HomePhone, VerifiedInput_DOB DOB, VerifiedInput_DriverLicenseNumber DriverLicenseNumber,
			/* VerifiedInput.Name */ Id, VerifiedInput_Name_First [First], VerifiedInput_Name_Full [Full], VerifiedInput_Name_Generation Generation, VerifiedInput_Name_Last [Last], VerifiedInput_Name_Middle Middle, VerifiedInput_Name_Title Title,
			/* VerifiedInput.Address */ Id, VerifiedInput_CurrentAddress_Type Type, VerifiedInput_CurrentAddress_AddressLine1 AddressLine1, VerifiedInput_CurrentAddress_AddressLine2 AddressLine2, VerifiedInput_CurrentAddress_City City, VerifiedInput_CurrentAddress_State State, VerifiedInput_CurrentAddress_County County, VerifiedInput_CurrentAddress_PostalCode PostalCode, VerifiedInput_CurrentAddress_CountryCode CountryCode, VerifiedInput_CurrentAddress_StreetNumber StreetNumber, VerifiedInput_CurrentAddress_StreetName StreetName, VerifiedInput_CurrentAddress_StreetPreDirection StreetPreDirection, VerifiedInput_CurrentAddress_StreetPostDirection StreetPostDirection, VerifiedInput_CurrentAddress_StreetType StreetType, VerifiedInput_CurrentAddress_FullAddress FullAddress, VerifiedInput_CurrentAddress_SubBuildingNumber SubBuildingNumber, VerifiedInput_CurrentAddress_UnitDesignation UnitDesignation, VerifiedInput_CurrentAddress_UnitNumber UnitNumber, VerifiedInput_CurrentAddress_Instance Instance,
			/* ReversePhone */ Id, ReversePhone_Address_Type Type, ReversePhone_Address_AddressLine1 AddressLine1, ReversePhone_Address_AddressLine2 AddressLine2, ReversePhone_Address_City City, ReversePhone_Address_State [State], ReversePhone_Address_County County, ReversePhone_Address_PostalCode PostalCode, ReversePhone_Address_CountryCode CountryCode, ReversePhone_Address_StreetNumber StreetNumber, ReversePhone_Address_StreetName StreetName, ReversePhone_Address_StreetPreDirection StreetPreDirection, ReversePhone_Address_StreetPostDirection StreetPostDirection, ReversePhone_Address_StreetType StreetType, ReversePhone_Address_FullAddress FullAddress, ReversePhone_Address_SubBuildingNumber SubBuildingNumber, ReversePhone_Address_UnitDesignation UnitDesignation, ReversePhone_Address_UnitNumber UnitNumber, ReversePhone_Address_Instance Instance,
			/* ReversePhone.Name */ Id, ReversePhone_Name_First [First], ReversePhone_Name_Full [Full], ReversePhone_Name_Generation Generation, ReversePhone_Name_Last [Last], ReversePhone_Name_Middle Middle, ReversePhone_Name_Title Title,
			/* ReversePhone.Address */ Id, ReversePhone_Address_Type Type, ReversePhone_Address_AddressLine1 AddressLine1, ReversePhone_Address_AddressLine2 AddressLine2, ReversePhone_Address_City City, ReversePhone_Address_State State, ReversePhone_Address_County County, ReversePhone_Address_PostalCode PostalCode, ReversePhone_Address_CountryCode CountryCode, ReversePhone_Address_StreetNumber StreetNumber, ReversePhone_Address_StreetName StreetName, ReversePhone_Address_StreetPreDirection StreetPreDirection, ReversePhone_Address_StreetPostDirection StreetPostDirection, ReversePhone_Address_StreetType StreetType, ReversePhone_Address_FullAddress FullAddress, ReversePhone_Address_SubBuildingNumber SubBuildingNumber, ReversePhone_Address_UnitDesignation UnitDesignation, ReversePhone_Address_UnitNumber UnitNumber, ReversePhone_Address_Instance Instance
			from ResultInstantIdIndividualResult with (NOLOCK) where Id = @rid;
		select * from ResultAdditionalLastName with (NOLOCK) where InstantIdIndividualResult_Id = @rid;
		select Id, FirstSeen, LastSeen, PhoneNumber, IsBestAddress,
			Id, Address_Type Type, Address_AddressLine1 AddressLine1, Address_AddressLine2 AddressLine2, Address_City City, Address_State State, Address_County County, Address_PostalCode PostalCode, Address_CountryCode CountryCode, Address_StreetNumber StreetNumber, Address_StreetName StreetName, Address_StreetPreDirection StreetPreDirection, Address_StreetPostDirection StreetPostDirection, Address_StreetType StreetType, Address_FullAddress FullAddress, Address_SubBuildingNumber SubBuildingNumber, Address_UnitDesignation UnitDesignation, Address_UnitNumber UnitNumber, Address_Instance Instance
			from ResultChronologyHistory with (NOLOCK) where InstantIdIndividualResult_Id = @rid;
		select * from ResultInstantIdIndividualRiskIndicator with (NOLOCK) where InstantIdIndividualResult_Id = @rid;
		select * from ResultInstantIdIndividualRedFlag with (NOLOCK) where InstantIdIndividualResult_Id = @rid order by Id;
		select ResultInstantIdIndividualRedFlagRiskIndicator.*, InstantIdIndividualRedFlag_Id RedFlagId
			from ResultInstantIdIndividualRedFlag redFlag with (NOLOCK)
			inner join ResultInstantIdIndividualRedFlagRiskIndicator with (NOLOCK) on InstantIdIndividualRedFlag_Id = redFlag.Id
			where InstantIdIndividualResult_Id = @rid
			order by redFlag.Id;
	end

	-- =========== InstantIdInternationalResult ======================================
	select * from ResultInstantIdInternationalResult with (NOLOCK) where Id = @rid;
	if @@ROWCOUNT > 0
	begin
		select * from ResultInstantIdInternationalRiskIndicator with (NOLOCK) where InstantIdInternationalResult_Id = @rid;
		select * from ResultInstantIdInternationalInputData with (NOLOCK) where InstantIdInternationalResult_Id = @rid;
		select * from ResultInstantIdInternationalDatasourceResult with (NOLOCK) where InstantIdInternationalResult_Id = @rid order by Id;
		select ResultInstantIdInternationalAppendedField.*, InstantIdInternationalDatasourceResult_Id DataSourceId
			from ResultInstantIdInternationalDatasourceResult dataSource with (NOLOCK)
			inner join ResultInstantIdInternationalAppendedField with (NOLOCK) on InstantIdInternationalDatasourceResult_Id = dataSource.Id
			where InstantIdInternationalResult_Id = @rid
			order by dataSource.Id;
		select ResultInstantIdInternationalDatasourceField.*, InstantIdInternationalDatasourceResult_Id DataSourceId
			from ResultInstantIdInternationalDatasourceResult dataSource with (NOLOCK)
			inner join ResultInstantIdInternationalDatasourceField with (NOLOCK) on InstantIdInternationalDatasourceResult_Id = dataSource.Id
			where InstantIdInternationalResult_Id = @rid
			order by dataSource.Id;
	end

	return;

go

CREATE ROLE db_executor
GO

GRANT EXECUTE TO db_executor
GO

-- GRANT EXECUTE on GetResultRecordDTO to cdbr_e;
-- GO


-- ----------------------------------------------------------------------------
-- Table BridgerRF.ResultRecordAssignment
-- ----------------------------------------------------------------------------

--ResultsManagement
--/****** Object:  Table [dbo].[ResultRecordAssignment]    Script Date: 3/5/2014 2:45:14 PM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--CREATE TABLE [dbo].[ResultRecordAssignment](
--	[Id] [bigint] IDENTITY(2,2) NOT NULL,
--	[AssignmentType] [int] NULL,
--	[AssignmentId] [int] NULL,
--	[AssignmentName] [nvarchar](256) NULL,
--	[ResultRecordId] [bigint] NOT NULL,
-- CONSTRAINT [PK_dbo.ResultRecordAssignment] PRIMARY KEY CLUSTERED
--(	[Id] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
--)

--GO
--SET ANSI_PADDING ON

--GO
--/****** Object:  Index [IX_RA_AT_AI_AN]    Script Date: 3/5/2014 2:45:14 PM ******/
--CREATE NONCLUSTERED INDEX [IX_RA_AT_AI_AN] ON [dbo].[ResultRecordAssignment]
--(
--	[AssignmentType] ASC,
--	[AssignmentId] ASC,
--	[AssignmentName] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
--GO
--SET ANSI_PADDING ON

--GO
--/****** Object:  Index [IX_RRA_RRI]    Script Date: 3/5/2014 2:45:14 PM ******/
--CREATE NONCLUSTERED INDEX [IX_RRA_RRI] ON [dbo].[ResultRecordAssignment]
--(
--	[ResultRecordId] ASC
--)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
--GO
--SET ANSI_PADDING ON

--GO
--/****** Object:  Index [IX_RRA_AT_AN]    Script Date: 3/5/2014 2:45:14 PM ******/
--CREATE NONCLUSTERED INDEX [IX_RRA_AT_AN] ON [dbo].[ResultRecordAssignment]
--(
--	[AssignmentType] ASC,
--	[AssignmentName] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
--GO
--ALTER TABLE [dbo].[ResultRecordAssignment]  WITH CHECK ADD  CONSTRAINT [FK_dbo.ResultRecordAssignment_dbo.ResultRecord_ResultRecordId] FOREIGN KEY([ResultRecordId])
--REFERENCES [dbo].[ResultRecord] ([Id])
--ON DELETE CASCADE
--GO
--ALTER TABLE [dbo].[ResultRecordAssignment] CHECK CONSTRAINT [FK_dbo.ResultRecordAssignment_dbo.ResultRecord_ResultRecordId]
--GO

---- ----------------------------------------------------------------------------
---- Table BridgerRF.ResultPredefinedSearchRestriction
---- ----------------------------------------------------------------------------
--/****** Object:  Table [dbo].[ResultPredefinedSearchRestriction]    Script Date: 08/22/2013 16:01:15 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--CREATE TABLE [dbo].[ResultPredefinedSearchRestriction](
--	[Id] [int] IDENTITY(2,2) NOT NULL,
--	[PredefinedSearchUniqueId] [BINARY](16) NULL,
--	[AlertDecision_Id] [int] NOT NULL,

-- CONSTRAINT [PK_dbo.ResultsPredefinedSearchRestriction] PRIMARY KEY CLUSTERED
--(
--	[Id] ASC
--)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
--)
--GO
--CREATE NONCLUSTERED INDEX [IX_AlertDecision_Id] ON [dbo].[ResultPredefinedSearchRestriction]
--(
--	[AlertDecision_Id] ASC
--)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
--GO
--/****** Object:  Table [dbo].[ResultFactivaMediaResult]    Script Date: 08/22/2013 16:01:15 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--SET ANSI_PADDING ON
--GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'tr_OlAcceptList_ins') BEGIN
	DROP TRIGGER tr_OlAcceptList_ins
END
GO
CREATE TRIGGER tr_OlAcceptList_ins
ON dbo.[OlAcceptList]
FOR INSERT
AS
	DECLARE @Id INT, @Type INT, @CustomerId INT;
	SET @Type = 999;
	SELECT @Id = Id, @CustomerId = CustomerId FROM INSERTED
	IF NOT EXISTS(SELECT 1 FROM dbo.[ListMapping] WHERE [InternalId] = @Id AND [Type] = @Type AND [CustomerId] = @CustomerId) BEGIN
		INSERT INTO [dbo].[ListMapping] ([InternalId], [Type], [CustomerId]) VALUES (@Id, @Type, @CustomerId)
	END
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'tr_OlAcceptList_upd') BEGIN
	DROP TRIGGER tr_OlAcceptList_upd
END
GO
CREATE TRIGGER tr_OlAcceptList_upd
ON dbo.[OlAcceptList]
FOR UPDATE
AS
	DECLARE @Id INT, @Type INT, @CustomerId INT;
	SET @Type = 999;
	SELECT @Id = Id, @CustomerId = CustomerId FROM INSERTED
	IF NOT EXISTS(SELECT 1 FROM dbo.[ListMapping] WHERE [InternalId] = @Id AND [Type] = @Type AND [CustomerId] = @CustomerId) BEGIN
		INSERT INTO [dbo].[ListMapping] ([InternalId], [Type], [CustomerId]) VALUES (@Id, @Type, @CustomerId)
	END
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'tr_OlAcceptList_del') BEGIN
	DROP TRIGGER tr_OlAcceptList_del
END
GO
CREATE TRIGGER tr_OlAcceptList_del
ON dbo.[OlAcceptList]
FOR DELETE
AS
	DECLARE @Id INT, @CustomerId INT;
	SELECT @Id = Id, @CustomerId = CustomerId FROM DELETED
	DELETE FROM [dbo].[ListMapping] WHERE [CustomerId] = @CustomerId AND [InternalId] = @Id
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECTPROPERTY(object_id('dbo.OlAcceptListSearch'), N'IsProcedure') is null exec sp_executesql N'CREATE PROCEDURE [dbo].[OlAcceptListSearch] as return 0';
GO
ALTER PROCEDURE [dbo].[OlAcceptListSearch]
(
	@CustomerId AS INT,
	@ListId AS INT,
	@Divisions AS VARCHAR(MAX),
	@CriteriaDateListedEnd AS DATETIME = NULL,
	@CriteriaDateListedStart AS DATETIME = NULL,
	@CriteriaCountryName  AS VARCHAR(MAX) = NULL,
	@CriteriaCountryAlternateName  AS VARCHAR(MAX) = NULL,
	@CriteriaReasonListed AS VARCHAR(MAX) = NULL,
	@CriteriaReferenceNumber AS VARCHAR(MAX) = NULL,
	@CriteriaCountryCity  AS VARCHAR(MAX) = NULL,
	@CriteriaCountryCode  AS VARCHAR(MAX) = NULL,
	@CriteriaEntityEntityType AS INT = 0,
	@CriteriaEntityEntityAddedBy  AS VARCHAR(MAX) = NULL,
	@CriteriaEntityFirstName AS VARCHAR(MAX) = NULL,
	@CriteriaEntityMiddleName AS VARCHAR(MAX) = NULL,
	@CriteriaEntityLastName AS VARCHAR(MAX) = NULL,
	@CriteriaEntityFullName AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAdditionalInfoType AS INT = 0,
	@CriteriaEntityAdditionalInfoValue1 AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAdditionalInfoValue2 AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressStreet1 AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressStreet2 AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressCity AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressCountry AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressPostalCode AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressStateProvinceDistrict AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressPhone AS VARCHAR(MAX) = NULL,
	@CriteriaEntityIDType AS INT = 0,
	@CriteriaEntityIDLabel AS VARCHAR(MAX) = NULL,
	@CriteriaEntityIDNumber AS VARCHAR(MAX) = NULL,
	@CriteriaEntityTrueMatchesOnly AS INT = 0,
    @CriteriaEntityExcludeIfTrueMatchesOnly AS INT = 0,
	@CwlCustomWatchlistType AS INT = 0,
    @FalseMatchUpdateBaselineValuesOnly AS INT = 0
)
AS
BEGIN
	IF @CriteriaEntityEntityType IS NULL
		SET @CriteriaEntityEntityType = 0;

	IF @CriteriaEntityAdditionalInfoType IS NULL
		SET @CriteriaEntityAdditionalInfoType = 0;

	IF @CriteriaEntityIDType IS NULL
		SET @CriteriaEntityIDType = 0;

	IF @FalseMatchUpdateBaselineValuesOnly IS NULL
		SET @FalseMatchUpdateBaselineValuesOnly = 0;

	SET @CriteriaReasonListed = RTRIM(LTRIM(@CriteriaReasonListed))
	SET @CriteriaReasonListed = CASE WHEN @CriteriaReasonListed IS NULL OR LEN(@CriteriaReasonListed) = 0 THEN NULL ELSE @CriteriaReasonListed END;
	SET @CriteriaReasonListed = REPLACE (@CriteriaReasonListed ,'*' ,'%')
	SET @CriteriaReasonListed = REPLACE (@CriteriaReasonListed ,'?' ,'_')
	DECLARE @CriteriaReasonListed_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaReasonListed) > 0 OR CHARINDEX('_', @CriteriaReasonListed) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaReasonListed_WildCardAny AS BIT = CASE WHEN @CriteriaReasonListed_HasWildCard = 1 AND @CriteriaReasonListed = '%' THEN 1 ELSE 0 END;

	SET @CriteriaReferenceNumber = RTRIM(LTRIM(@CriteriaReferenceNumber))
	SET @CriteriaReferenceNumber = CASE WHEN @CriteriaReferenceNumber IS NULL OR LEN(@CriteriaReferenceNumber) = 0 THEN NULL ELSE @CriteriaReferenceNumber END;
	SET @CriteriaReferenceNumber = REPLACE (@CriteriaReferenceNumber ,'*' ,'%')
	SET @CriteriaReferenceNumber = REPLACE (@CriteriaReferenceNumber ,'?' ,'_')
	DECLARE @CriteriaReferenceNumber_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaReferenceNumber) > 0 OR CHARINDEX('_', @CriteriaReferenceNumber) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaReferenceNumber_WildCardAny AS BIT = CASE WHEN @CriteriaReferenceNumber_HasWildCard = 1 AND @CriteriaReferenceNumber = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityFirstName = RTRIM(LTRIM(@CriteriaEntityFirstName))
	SET @CriteriaEntityFirstName = CASE WHEN @CriteriaEntityFirstName IS NULL OR LEN(@CriteriaEntityFirstName) = 0 THEN NULL ELSE @CriteriaEntityFirstName END;
	SET @CriteriaEntityFirstName = REPLACE (@CriteriaEntityFirstName ,'*' ,'%')
	SET @CriteriaEntityFirstName = REPLACE (@CriteriaEntityFirstName ,'?' ,'_')
	DECLARE @CriteriaEntityFirstName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityFirstName) > 0 OR CHARINDEX('_', @CriteriaEntityFirstName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityFirstName_WildCardAny AS BIT = CASE WHEN @CriteriaEntityFirstName_HasWildCard = 1 AND @CriteriaEntityFirstName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityMiddleName = RTRIM(LTRIM(@CriteriaEntityMiddleName))
	SET @CriteriaEntityMiddleName = CASE WHEN @CriteriaEntityMiddleName IS NULL OR LEN(@CriteriaEntityMiddleName) = 0 THEN NULL ELSE @CriteriaEntityMiddleName END;
	SET @CriteriaEntityMiddleName = REPLACE (@CriteriaEntityMiddleName ,'*' ,'%')
	SET @CriteriaEntityMiddleName = REPLACE (@CriteriaEntityMiddleName ,'?' ,'_')
	DECLARE @CriteriaEntityMiddleName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityMiddleName) > 0 OR CHARINDEX('_', @CriteriaEntityMiddleName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityMiddleName_WildCardAny AS BIT = CASE WHEN @CriteriaEntityMiddleName_HasWildCard = 1 AND @CriteriaEntityMiddleName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityLastName = RTRIM(LTRIM(@CriteriaEntityLastName))
	SET @CriteriaEntityLastName = CASE WHEN @CriteriaEntityLastName IS NULL OR LEN(@CriteriaEntityLastName) = 0 THEN NULL ELSE @CriteriaEntityLastName END;
	SET @CriteriaEntityLastName = REPLACE (@CriteriaEntityLastName ,'*' ,'%')
	SET @CriteriaEntityLastName = REPLACE (@CriteriaEntityLastName ,'?' ,'_')
	DECLARE @CriteriaEntityLastName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityLastName) > 0 OR CHARINDEX('_', @CriteriaEntityLastName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityLastName_WildCardAny AS BIT = CASE WHEN @CriteriaEntityLastName_HasWildCard = 1 AND @CriteriaEntityLastName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityFullName = RTRIM(LTRIM(@CriteriaEntityFullName))
	SET @CriteriaEntityFullName = CASE WHEN @CriteriaEntityFullName IS NULL OR LEN(@CriteriaEntityFullName) = 0 THEN NULL ELSE @CriteriaEntityFullName END;
	SET @CriteriaEntityFullName = REPLACE (@CriteriaEntityFullName ,'*' ,'%')
	SET @CriteriaEntityFullName = REPLACE (@CriteriaEntityFullName ,'?' ,'_')
	DECLARE @CriteriaEntityFullName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityFullName) > 0 OR CHARINDEX('_', @CriteriaEntityFullName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityFullName_WildCardAny AS BIT = CASE WHEN @CriteriaEntityFullName_HasWildCard = 1 AND @CriteriaEntityFullName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAdditionalInfoValue1 = RTRIM(LTRIM(@CriteriaEntityAdditionalInfoValue1))
	SET @CriteriaEntityAdditionalInfoValue1 = CASE WHEN @CriteriaEntityAdditionalInfoValue1 IS NULL OR LEN(@CriteriaEntityAdditionalInfoValue1) = 0 THEN NULL ELSE @CriteriaEntityAdditionalInfoValue1 END;
	SET @CriteriaEntityAdditionalInfoValue1 = REPLACE (@CriteriaEntityAdditionalInfoValue1 ,'*' ,'%')
	SET @CriteriaEntityAdditionalInfoValue1 = REPLACE (@CriteriaEntityAdditionalInfoValue1 ,'?' ,'_')
	DECLARE @CriteriaEntityAdditionalInfoValue1_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAdditionalInfoValue1) > 0 OR CHARINDEX('_', @CriteriaEntityAdditionalInfoValue1) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAdditionalInfoValue1_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAdditionalInfoValue1_HasWildCard = 1 AND @CriteriaEntityAdditionalInfoValue1 = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAdditionalInfoValue2 = RTRIM(LTRIM(@CriteriaEntityAdditionalInfoValue2))
	SET @CriteriaEntityAdditionalInfoValue2 = CASE WHEN @CriteriaEntityAdditionalInfoValue2 IS NULL OR LEN(@CriteriaEntityAdditionalInfoValue2) = 0 THEN NULL ELSE @CriteriaEntityAdditionalInfoValue2 END;
	SET @CriteriaEntityAdditionalInfoValue2 = REPLACE (@CriteriaEntityAdditionalInfoValue2 ,'*' ,'%')
	SET @CriteriaEntityAdditionalInfoValue2 = REPLACE (@CriteriaEntityAdditionalInfoValue2 ,'?' ,'_')
	DECLARE @CriteriaEntityAdditionalInfoValue2_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAdditionalInfoValue2) > 0 OR CHARINDEX('_', @CriteriaEntityAdditionalInfoValue2) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAdditionalInfoValue2_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAdditionalInfoValue2_HasWildCard = 1 AND @CriteriaEntityAdditionalInfoValue2 = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressStreet1 = RTRIM(LTRIM(@CriteriaEntityAddressStreet1))
	SET @CriteriaEntityAddressStreet1 = CASE WHEN @CriteriaEntityAddressStreet1 IS NULL OR LEN(@CriteriaEntityAddressStreet1) = 0 THEN NULL ELSE @CriteriaEntityAddressStreet1 END;
	SET @CriteriaEntityAddressStreet1 = REPLACE (@CriteriaEntityAddressStreet1 ,'*' ,'%')
	SET @CriteriaEntityAddressStreet1 = REPLACE (@CriteriaEntityAddressStreet1 ,'?' ,'_')
	DECLARE @CriteriaEntityAddressStreet1_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressStreet1) > 0 OR CHARINDEX('_', @CriteriaEntityAddressStreet1) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressStreet1_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressStreet1_HasWildCard = 1 AND @CriteriaEntityAddressStreet1 = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressStreet2 = RTRIM(LTRIM(@CriteriaEntityAddressStreet2))
	SET @CriteriaEntityAddressStreet2 = CASE WHEN @CriteriaEntityAddressStreet2 IS NULL OR LEN(@CriteriaEntityAddressStreet2) = 0 THEN NULL ELSE @CriteriaEntityAddressStreet2 END;
	SET @CriteriaEntityAddressStreet2 = REPLACE (@CriteriaEntityAddressStreet2 ,'*' ,'%')
	SET @CriteriaEntityAddressStreet2 = REPLACE (@CriteriaEntityAddressStreet2 ,'?' ,'_')
	DECLARE @CriteriaEntityAddressStreet2_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressStreet2) > 0 OR CHARINDEX('_', @CriteriaEntityAddressStreet2) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressStreet2_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressStreet2_HasWildCard = 1 AND @CriteriaEntityAddressStreet2 = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressCity = RTRIM(LTRIM(@CriteriaEntityAddressCity))
	SET @CriteriaEntityAddressCity = CASE WHEN @CriteriaEntityAddressCity IS NULL OR LEN(@CriteriaEntityAddressCity) = 0 THEN NULL ELSE @CriteriaEntityAddressCity END;
	SET @CriteriaEntityAddressCity = REPLACE (@CriteriaEntityAddressCity ,'*' ,'%')
	SET @CriteriaEntityAddressCity = REPLACE (@CriteriaEntityAddressCity ,'?' ,'_')
	DECLARE @CriteriaEntityAddressCity_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressCity) > 0 OR CHARINDEX('_', @CriteriaEntityAddressCity) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressCity_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressCity_HasWildCard = 1 AND @CriteriaEntityAddressCity = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressCountry = RTRIM(LTRIM(@CriteriaEntityAddressCountry))
	SET @CriteriaEntityAddressCountry = CASE WHEN @CriteriaEntityAddressCountry IS NULL OR LEN(@CriteriaEntityAddressCountry) = 0 THEN NULL ELSE @CriteriaEntityAddressCountry END;
	SET @CriteriaEntityAddressCountry = REPLACE (@CriteriaEntityAddressCountry ,'*' ,'%')
	SET @CriteriaEntityAddressCountry = REPLACE (@CriteriaEntityAddressCountry ,'?' ,'_')
	DECLARE @CriteriaEntityAddressCountry_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressCountry) > 0 OR CHARINDEX('_', @CriteriaEntityAddressCountry) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressCountry_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressCountry_HasWildCard = 1 AND @CriteriaEntityAddressCountry = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressPostalCode = RTRIM(LTRIM(@CriteriaEntityAddressPostalCode))
	SET @CriteriaEntityAddressPostalCode = CASE WHEN @CriteriaEntityAddressPostalCode IS NULL OR LEN(@CriteriaEntityAddressPostalCode) = 0 THEN NULL ELSE @CriteriaEntityAddressPostalCode END;
	SET @CriteriaEntityAddressPostalCode = REPLACE (@CriteriaEntityAddressPostalCode ,'*' ,'%')
	SET @CriteriaEntityAddressPostalCode = REPLACE (@CriteriaEntityAddressPostalCode ,'?' ,'_')
	DECLARE @CriteriaEntityAddressPostalCode_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressPostalCode) > 0 OR CHARINDEX('_', @CriteriaEntityAddressPostalCode) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressPostalCode_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressPostalCode_HasWildCard = 1 AND @CriteriaEntityAddressPostalCode = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressStateProvinceDistrict = RTRIM(LTRIM(@CriteriaEntityAddressStateProvinceDistrict))
	SET @CriteriaEntityAddressStateProvinceDistrict = CASE WHEN @CriteriaEntityAddressStateProvinceDistrict IS NULL OR LEN(@CriteriaEntityAddressStateProvinceDistrict) = 0 THEN NULL ELSE @CriteriaEntityAddressStateProvinceDistrict END;
	SET @CriteriaEntityAddressStateProvinceDistrict = REPLACE (@CriteriaEntityAddressStateProvinceDistrict ,'*' ,'%')
	SET @CriteriaEntityAddressStateProvinceDistrict = REPLACE (@CriteriaEntityAddressStateProvinceDistrict ,'?' ,'_')
	DECLARE @CriteriaEntityAddressStateProvinceDistrict_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressStateProvinceDistrict) > 0 OR CHARINDEX('_', @CriteriaEntityAddressStateProvinceDistrict) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressStateProvinceDistrict_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressStateProvinceDistrict_HasWildCard = 1 AND @CriteriaEntityAddressStateProvinceDistrict = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressPhone = RTRIM(LTRIM(@CriteriaEntityAddressPhone));
	SET @CriteriaEntityAddressPhone = CASE WHEN @CriteriaEntityAddressPhone IS NULL OR LEN(@CriteriaEntityAddressPhone) = 0 THEN NULL ELSE @CriteriaEntityAddressPhone END;
	SET @CriteriaEntityAddressPhone = REPLACE (@CriteriaEntityAddressPhone ,'*' ,'%');
	SET @CriteriaEntityAddressPhone = REPLACE (@CriteriaEntityAddressPhone ,'?' ,'_');
	DECLARE @CriteriaEntityAddressPhone_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressPhone) > 0 OR CHARINDEX('_', @CriteriaEntityAddressPhone) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressPhone_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressPhone_HasWildCard = 1 AND @CriteriaEntityAddressPhone = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityIDLabel = RTRIM(LTRIM(@CriteriaEntityIDLabel))
	SET @CriteriaEntityIDLabel = CASE WHEN @CriteriaEntityIDLabel IS NULL OR LEN(@CriteriaEntityIDLabel) = 0 THEN NULL ELSE @CriteriaEntityIDLabel END;
	SET @CriteriaEntityIDLabel = REPLACE (@CriteriaEntityIDLabel ,'*' ,'%')
	SET @CriteriaEntityIDLabel = REPLACE (@CriteriaEntityIDLabel ,'?' ,'_')
	DECLARE @CriteriaEntityIDLabel_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityIDLabel) > 0 OR CHARINDEX('_', @CriteriaEntityIDLabel) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityIDLabel_WildCardAny AS BIT = CASE WHEN @CriteriaEntityIDLabel_HasWildCard = 1 AND @CriteriaEntityIDLabel = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityIDNumber = RTRIM(LTRIM(@CriteriaEntityIDNumber))
	SET @CriteriaEntityIDNumber = CASE WHEN @CriteriaEntityIDNumber IS NULL OR LEN(@CriteriaEntityIDNumber) = 0 THEN NULL ELSE @CriteriaEntityIDNumber END;
	SET @CriteriaEntityIDNumber = REPLACE (@CriteriaEntityIDNumber ,'*' ,'%')
	SET @CriteriaEntityIDNumber = REPLACE (@CriteriaEntityIDNumber ,'?' ,'_')
	DECLARE @CriteriaEntityIDNumber_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityIDNumber) > 0 OR CHARINDEX('_', @CriteriaEntityIDNumber) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityIDNumber_WildCardAny AS BIT = CASE WHEN @CriteriaEntityIDNumber_HasWildCard = 1 AND @CriteriaEntityIDNumber = '%' THEN 1 ELSE 0 END;

	DECLARE @CriteriaEntityEntityAddedByUserName AS VARCHAR(255);
	SET @CriteriaEntityEntityAddedByUserName = '';
	IF @CriteriaEntityEntityAddedBy IS NOT NULL
	BEGIN
		SELECT  @CriteriaEntityEntityAddedByUserName=profile.FullName FROM bridgerrfcommon.dbo.UserMgmtUsers as [user]
		inner join  bridgerrfcommon.dbo.UserMgmtUserProfiles as profile on [user].id=profile.id
		where loginName = @CriteriaEntityEntityAddedBy and customer_id= @CustomerId and [user].IsDeleted = 0 and [user].isActive=1;
	END

	DECLARE @CriteriaEntityAdditionalInfoValue1AsDecimal AS DECIMAL(18,4);
	DECLARE @CriteriaEntityAdditionalInfoValue2AsDecimal AS DECIMAL(18,4);
	DECLARE @CriteriaEntityAdditionalInfoValue1AsDatetime AS DATETIME;
	DECLARE @CriteriaEntityAdditionalInfoValue2AsDatetime AS DATETIME;

	IF @CriteriaEntityAdditionalInfoType IN (20,18,12,7)
	BEGIN
		IF @CriteriaEntityAdditionalInfoValue1 IS NOT NULL
			SET @CriteriaEntityAdditionalInfoValue1AsDecimal = CAST(@CriteriaEntityAdditionalInfoValue1 AS DECIMAL(18,4));
		ELSE
			SET @CriteriaEntityAdditionalInfoValue1AsDecimal = NULL;

		IF @CriteriaEntityAdditionalInfoValue2 IS NOT NULL
			SET @CriteriaEntityAdditionalInfoValue2AsDecimal = CAST(@CriteriaEntityAdditionalInfoValue2 AS DECIMAL(18,4));
		ELSE
			SET @CriteriaEntityAdditionalInfoValue2AsDecimal = NULL;
	END
	ELSE
	IF @CriteriaEntityAdditionalInfoType IN (4)
	BEGIN
		IF @CriteriaEntityAdditionalInfoValue1 IS NOT NULL
			SET @CriteriaEntityAdditionalInfoValue1AsDatetime = CAST(@CriteriaEntityAdditionalInfoValue1 AS DATETIME);
		ELSE
			SET @CriteriaEntityAdditionalInfoValue1AsDatetime = NULL;


		IF @CriteriaEntityAdditionalInfoValue2 IS NOT NULL
			SET @CriteriaEntityAdditionalInfoValue2AsDatetime = CAST(@CriteriaEntityAdditionalInfoValue2 AS DATETIME);
		ELSE
			SET @CriteriaEntityAdditionalInfoValue2AsDatetime = NULL;

	END

	SELECT entity.Id FROM dbo.OlEntities AS entity
		INNER JOIN dbo.OlAcceptList al ON entity.AcceptListId = al.Id AND al.IsDeleted = 0 
	WHERE al.Id = @ListId AND al.CustomerId = @CustomerId  AND entity.IsDeleted = 0 AND ((MatchDetails IS NOT NULL AND DATALENGTH(MatchDetails) > 0) OR 0 = @FalseMatchUpdateBaselineValuesOnly)

	AND
	(
		@CriteriaEntityEntityType = 0 OR entity.TypeId = @CriteriaEntityEntityType
	)
	AND
	(
		@CriteriaDateListedEnd IS NULL OR entity.ListedDate <= @CriteriaDateListedEnd
	)
	AND
	(
		@CriteriaDateListedStart IS NULL OR entity.ListedDate >= @CriteriaDateListedStart
	)
	AND
	(
		@CriteriaEntityEntityAddedBy IS NULL OR ( entity.CreatedBy = @CriteriaEntityEntityAddedBy ) OR ( entity.CreatedBy = @CriteriaEntityEntityAddedByUserName)
	)
	AND
	(
		@CriteriaEntityFirstName IS NULL
		OR
		(
			@CriteriaEntityFirstName IS NOT NULL
			AND
			(
				@CriteriaEntityFirstName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.FirstName))) > 0
				OR
				(
					@CriteriaEntityFirstName_WildCardAny = 0
					AND
					(
						@CriteriaEntityFirstName_HasWildCard = 1 AND RTRIM(LTRIM(entity.FirstName)) LIKE @CriteriaEntityFirstName
						OR
						@CriteriaEntityFirstName_HasWildCard = 0 AND RTRIM(LTRIM(entity.FirstName)) = @CriteriaEntityFirstName
					)
				)
			)
		)
		OR
		(
			@CriteriaEntityFirstName IS NOT NULL
			AND
			EXISTS(SELECT 1 FROM dbo.OlAkas aka
				WHERE aka.EntityId = entity.Id AND aka.IsDeleted = 0
				AND
				(
					@CriteriaEntityFirstName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.FirstName))) > 0
					OR
					(
						@CriteriaEntityFirstName_WildCardAny = 0
						AND
						(
							@CriteriaEntityFirstName_HasWildCard = 1 AND RTRIM(LTRIM(aka.FirstName)) LIKE @CriteriaEntityFirstName
							OR
							@CriteriaEntityFirstName_HasWildCard = 0 AND RTRIM(LTRIM(aka.FirstName)) = @CriteriaEntityFirstName
						)
					)
				)
			)
		)
	)
	AND
	(
		@CriteriaEntityMiddleName IS NULL
		OR
		(
			@CriteriaEntityMiddleName IS NOT NULL
			AND
			(
				@CriteriaEntityMiddleName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.MiddleName))) > 0
				OR
				(
					@CriteriaEntityMiddleName_WildCardAny = 0
					AND
					(
						@CriteriaEntityMiddleName_HasWildCard = 1 AND RTRIM(LTRIM(entity.MiddleName)) LIKE @CriteriaEntityMiddleName
						OR
						@CriteriaEntityMiddleName_HasWildCard = 0 AND RTRIM(LTRIM(entity.MiddleName)) = @CriteriaEntityMiddleName
					)
				)
			)
		)
		OR
		(
			@CriteriaEntityMiddleName IS NOT NULL
			AND
			EXISTS(SELECT 1 FROM dbo.OlAkas aka
				WHERE aka.EntityId = entity.Id AND aka.IsDeleted = 0
				AND
				(
					@CriteriaEntityMiddleName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.MiddleName))) > 0
					OR
					(
						@CriteriaEntityMiddleName_WildCardAny = 0
						AND
						(
							@CriteriaEntityMiddleName_HasWildCard = 1 AND RTRIM(LTRIM(aka.MiddleName)) LIKE @CriteriaEntityMiddleName
							OR
							@CriteriaEntityMiddleName_HasWildCard = 0 AND RTRIM(LTRIM(aka.MiddleName)) = @CriteriaEntityMiddleName
						)
					)
				)
			)
		)
	)
	AND
	(
		@CriteriaEntityLastName IS NULL
		OR
		(
			@CriteriaEntityLastName IS NOT NULL
			AND
			(
				@CriteriaEntityLastName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.LastName))) > 0
				OR
				(
					@CriteriaEntityLastName_WildCardAny = 0
					AND
					(
						@CriteriaEntityLastName_HasWildCard = 1 AND RTRIM(LTRIM(entity.LastName)) LIKE @CriteriaEntityLastName
						OR
						@CriteriaEntityLastName_HasWildCard = 0 AND RTRIM(LTRIM(entity.LastName)) = @CriteriaEntityLastName
					)
				)
			)
		)
		OR
		(
			@CriteriaEntityLastName IS NOT NULL
			AND
			EXISTS(SELECT 1 FROM dbo.OlAkas aka
				WHERE aka.EntityId = entity.Id AND aka.IsDeleted = 0
				AND
				(
					@CriteriaEntityLastName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.LastName))) > 0
					OR
					(
						@CriteriaEntityLastName_WildCardAny = 0
						AND
						(
							@CriteriaEntityLastName_HasWildCard = 1 AND RTRIM(LTRIM(aka.LastName)) LIKE @CriteriaEntityLastName
							OR
							@CriteriaEntityLastName_HasWildCard = 0 AND RTRIM(LTRIM(aka.LastName)) = @CriteriaEntityLastName
						)
					)
				)
			)
		)
	)
	AND
	(
		@CriteriaEntityFullName IS NULL
		OR
		(
			@CriteriaEntityFullName IS NOT NULL
			AND
			(
				@CriteriaEntityFullName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.FullName))) > 0
				OR
				(
					@CriteriaEntityFullName_WildCardAny = 0
					AND
					(
						@CriteriaEntityFullName_HasWildCard = 1 AND RTRIM(LTRIM(entity.FullName)) LIKE @CriteriaEntityFullName
						OR
						@CriteriaEntityFullName_HasWildCard = 0 AND RTRIM(LTRIM(entity.FullName)) = @CriteriaEntityFullName
					)
				)
			)
		)
		OR
		@CriteriaEntityFullName IS NOT NULL
		AND
		EXISTS(SELECT 1 FROM dbo.OlAkas aka
			WHERE aka.EntityId = entity.Id AND aka.IsDeleted = 0
			AND
			(
				@CriteriaEntityFullName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.FullName))) > 0
				OR
				(
					@CriteriaEntityFullName_WildCardAny = 0
					AND
					(
						@CriteriaEntityFullName_HasWildCard = 1 AND RTRIM(LTRIM(aka.FullName)) LIKE @CriteriaEntityFullName
						OR
						@CriteriaEntityFullName_HasWildCard = 0 AND RTRIM(LTRIM(aka.FullName)) = @CriteriaEntityFullName
					)
				)
			)
		)
	)
	AND
	(
        (@CriteriaEntityTrueMatchesOnly = 0  AND @CriteriaEntityExcludeIfTrueMatchesOnly = 0)
		OR
        (@CriteriaEntityTrueMatchesOnly = 1
		AND
			EXISTS (SELECT 1 FROM OlMatchData md where md.EntityId=entity.Id and IsTrueMatch=1 AND IsDeleted = 0))
		OR
            (@CriteriaEntityExcludeIfTrueMatchesOnly = 1
			AND
			NOT EXISTS (SELECT 1 FROM OlMatchData md where md.EntityId=entity.Id and IsTrueMatch=1 AND IsDeleted = 0))
	)
	AND
	(
		(
			@CriteriaEntityAdditionalInfoType IS NULL
			OR @CriteriaEntityAdditionalInfoType = 0
			OR @CriteriaEntityAdditionalInfoValue1 IS NULL AND @CriteriaEntityAdditionalInfoValue2 IS NULL
		)
		OR
		(
			@CriteriaEntityAdditionalInfoType IS NOT NULL
			AND @CriteriaEntityAdditionalInfoType > 0
			AND
			(
				@CriteriaEntityAdditionalInfoValue1 IS NOT NULL
				OR
				@CriteriaEntityAdditionalInfoValue2 IS NOT NULL
			)
			AND
			EXISTS(SELECT 1 FROM dbo.OlAdditionalInfo info
				WHERE info.EntityId = entity.Id
				AND info.TypeId = @CriteriaEntityAdditionalInfoType
				AND info.IsDeleted = 0
				AND
				(
					@CriteriaEntityAdditionalInfoType IN (4)
						AND (@CriteriaEntityAdditionalInfoValue1AsDatetime IS NOT NULL OR @CriteriaEntityAdditionalInfoValue2AsDatetime IS NOT NULL)
						AND (@CriteriaEntityAdditionalInfoValue1AsDatetime IS NULL OR @CriteriaEntityAdditionalInfoValue1AsDatetime IS NOT NULL AND @CriteriaEntityAdditionalInfoValue1AsDatetime <= CAST(info.Value AS DATETIME))
						AND (@CriteriaEntityAdditionalInfoValue2AsDatetime IS NULL OR @CriteriaEntityAdditionalInfoValue2AsDatetime IS NOT NULL AND @CriteriaEntityAdditionalInfoValue2AsDatetime >= CAST(info.Value AS DATETIME))
					OR
					@CriteriaEntityAdditionalInfoType NOT IN (4)
						AND (@CriteriaEntityAdditionalInfoValue1 IS NOT NULL OR @CriteriaEntityAdditionalInfoValue2 IS NOT NULL)
						AND
						(
							@CriteriaEntityAdditionalInfoValue1 IS NOT NULL
							AND
							(
								@CriteriaEntityAdditionalInfoValue1_WildCardAny = 1 AND LEN(RTRIM(LTRIM(info.Value))) > 0
								OR
								(
									@CriteriaEntityAdditionalInfoValue1_WildCardAny = 0
									AND
									(
										@CriteriaEntityAdditionalInfoValue1_HasWildCard = 1 AND RTRIM(LTRIM(info.Value)) LIKE @CriteriaEntityAdditionalInfoValue1
										OR
										@CriteriaEntityAdditionalInfoValue1_HasWildCard = 0 AND RTRIM(LTRIM(info.Value)) = @CriteriaEntityAdditionalInfoValue1
									)
								)
							)
							OR
							@CriteriaEntityAdditionalInfoValue2 IS NOT NULL
							AND
							(
								@CriteriaEntityAdditionalInfoValue2_WildCardAny = 1 AND LEN(RTRIM(LTRIM(info.Value))) > 0
								OR
								(
									@CriteriaEntityAdditionalInfoValue2_WildCardAny = 0
									AND
									(
										@CriteriaEntityAdditionalInfoValue2_HasWildCard = 1 AND RTRIM(LTRIM(info.Value)) LIKE @CriteriaEntityAdditionalInfoValue2
										OR
										@CriteriaEntityAdditionalInfoValue2_HasWildCard = 0 AND RTRIM(LTRIM(info.Value)) = @CriteriaEntityAdditionalInfoValue2
									)
								)
							)
						)
				)
			)
		)
	)
	AND
	(
		(
			@CriteriaEntityAddressStreet1 IS NULL
			AND @CriteriaEntityAddressStreet2 IS NULL
			AND @CriteriaEntityAddressCity IS NULL
			AND @CriteriaEntityAddressCountry IS NULL
			AND @CriteriaEntityAddressPostalCode IS NULL
			AND @CriteriaEntityAddressStateProvinceDistrict IS NULL
		)
		OR EXISTS(SELECT 1 FROM dbo.OlAddresses addr
			WHERE addr.EntityId = entity.Id AND addr.IsDeleted = 0
			AND
			(
				(
					@CriteriaEntityAddressStreet1 IS NULL
					OR
					(
						@CriteriaEntityAddressStreet1 IS NOT NULL
						AND
						(
							@CriteriaEntityAddressStreet1_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.AddressLine1))) > 0
							OR
							(
								@CriteriaEntityAddressStreet1_WildCardAny = 0
								AND
								(
									@CriteriaEntityAddressStreet1_HasWildCard = 1 AND RTRIM(LTRIM(addr.AddressLine1)) LIKE @CriteriaEntityAddressStreet1
									OR
									@CriteriaEntityAddressStreet1_HasWildCard = 0 AND RTRIM(LTRIM(addr.AddressLine1)) = @CriteriaEntityAddressStreet1
								)
							)
						)
					)
				)
				AND
				(
					@CriteriaEntityAddressStreet2 IS NULL
					OR
					(
						@CriteriaEntityAddressStreet2 IS NOT NULL
						AND
						(
							@CriteriaEntityAddressStreet2_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.AddressLine2))) > 0
							OR
							(
								@CriteriaEntityAddressStreet2_WildCardAny = 0
								AND
								(
									@CriteriaEntityAddressStreet2_HasWildCard = 1 AND RTRIM(LTRIM(addr.AddressLine2)) LIKE @CriteriaEntityAddressStreet2
									OR
									@CriteriaEntityAddressStreet2_HasWildCard = 0 AND RTRIM(LTRIM(addr.AddressLine2)) = @CriteriaEntityAddressStreet2
								)
							)
						)
					)
				)
				AND
				(
					@CriteriaEntityAddressCity IS NULL
					OR
					(
						@CriteriaEntityAddressCity IS NOT NULL
						AND
						(
							@CriteriaEntityAddressCity_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.City))) > 0
							OR
							(
								@CriteriaEntityAddressCity_WildCardAny = 0
								AND
								(
									@CriteriaEntityAddressCity_HasWildCard = 1 AND RTRIM(LTRIM(addr.City)) LIKE @CriteriaEntityAddressCity
									OR
									@CriteriaEntityAddressCity_HasWildCard = 0 AND RTRIM(LTRIM(addr.City)) = @CriteriaEntityAddressCity
								)
							)
						)
					)
				)
				AND
				(
					@CriteriaEntityAddressCountry IS NULL
					OR
					(
						@CriteriaEntityAddressCountry IS NOT NULL
						AND
						(
							@CriteriaEntityAddressCountry_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.Country))) > 0
							OR
							(
								@CriteriaEntityAddressCountry_WildCardAny = 0
								AND
								(
									@CriteriaEntityAddressCountry_HasWildCard = 1 AND RTRIM(LTRIM(addr.Country)) LIKE @CriteriaEntityAddressCountry
									OR
									@CriteriaEntityAddressCountry_HasWildCard = 0 AND RTRIM(LTRIM(addr.Country)) = @CriteriaEntityAddressCountry
								)
							)
						)
					)
				)
				AND
				(
					@CriteriaEntityAddressPostalCode IS NULL
					OR
					(
						@CriteriaEntityAddressPostalCode IS NOT NULL
						AND
						(
							@CriteriaEntityAddressPostalCode_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.PostalCode))) > 0
							OR
							(
								@CriteriaEntityAddressPostalCode_WildCardAny = 0
								AND
								(
									@CriteriaEntityAddressPostalCode_HasWildCard = 1 AND RTRIM(LTRIM(addr.PostalCode)) LIKE @CriteriaEntityAddressPostalCode
									OR
									@CriteriaEntityAddressPostalCode_HasWildCard = 0 AND RTRIM(LTRIM(addr.PostalCode)) = @CriteriaEntityAddressPostalCode
								)
							)
						)
					)
				)
				AND
				(
					@CriteriaEntityAddressStateProvinceDistrict IS NULL
					OR
					(
						@CriteriaEntityAddressStateProvinceDistrict IS NOT NULL
						AND
						(
							@CriteriaEntityAddressStateProvinceDistrict_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.[State]))) > 0
							OR
							(
								@CriteriaEntityAddressStateProvinceDistrict_WildCardAny = 0
								AND
								(
									@CriteriaEntityAddressStateProvinceDistrict_HasWildCard = 1 AND RTRIM(LTRIM(addr.[State])) LIKE @CriteriaEntityAddressStateProvinceDistrict
									OR
									@CriteriaEntityAddressStateProvinceDistrict_HasWildCard = 0 AND RTRIM(LTRIM(addr.[State])) = @CriteriaEntityAddressStateProvinceDistrict
								)
							)
						)
					)
				)
			)
		)
	)
	AND
		(
			(
				@CriteriaEntityAddressPhone IS null
				OR
				@CriteriaEntityAddressPhone IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM olphonenumbers phone
					WHERE phone.EntityId = entity.Id  AND phone.IsDeleted = 0
					AND
					(
						@CriteriaEntityAddressPhone_WildCardAny = 1 AND LEN(RTRIM(LTRIM(phone.Number))) > 0
						OR
						(
							@CriteriaEntityAddressPhone_WildCardAny = 0
							AND
							(
								@CriteriaEntityAddressPhone_HasWildCard = 1 AND RTRIM(LTRIM(phone.Number)) LIKE @CriteriaEntityAddressPhone
								OR
								@CriteriaEntityAddressPhone_HasWildCard = 0 AND RTRIM(LTRIM(phone.Number)) = @CriteriaEntityAddressPhone
							)
						)
					)
				)
			)
		)
	AND
	(
		(
			@CriteriaEntityIDType IS NULL
			OR @CriteriaEntityIDType = 0
			OR @CriteriaEntityIDLabel IS NULL AND @CriteriaEntityIDNumber IS NULL
		)
		OR EXISTS(SELECT 1 FROM dbo.OlIdentifications id
			WHERE id.EntityId = entity.Id  AND id.IsDeleted = 0
			AND id.TypeId = @CriteriaEntityIDType
			AND
			(
				(
					@CriteriaEntityIDLabel IS NULL
					OR
					(
						@CriteriaEntityIDLabel IS NOT NULL
						AND
						(
							@CriteriaEntityIDLabel_WildCardAny = 1 AND LEN(RTRIM(LTRIM(id.Label))) > 0
							OR
							(
								@CriteriaEntityIDLabel_WildCardAny = 0
								AND
								(
									@CriteriaEntityIDLabel_HasWildCard = 1 AND RTRIM(LTRIM(id.Label)) LIKE @CriteriaEntityIDLabel
									OR
									@CriteriaEntityIDLabel_HasWildCard = 0 AND RTRIM(LTRIM(id.Label)) = @CriteriaEntityIDLabel
								)
							)
						)
					)
				)
				AND
				(
					@CriteriaEntityIDNumber IS NULL
					OR
					(
						@CriteriaEntityIDNumber IS NOT NULL
						AND
						(
							@CriteriaEntityIDNumber_WildCardAny = 1 AND LEN(RTRIM(LTRIM(id.Number))) > 0
							OR
							(
								@CriteriaEntityIDNumber_WildCardAny = 0
								AND
								(
									@CriteriaEntityIDNumber_HasWildCard = 1 AND REPLACE(RTRIM(LTRIM(id.Number)),'-','') LIKE REPLACE(RTRIM(LTRIM(@CriteriaEntityIDNumber)),'-','')
									OR
									@CriteriaEntityIDNumber_HasWildCard = 0 AND REPLACE(RTRIM(LTRIM(id.Number)),'-','') = REPLACE(RTRIM(LTRIM(@CriteriaEntityIDNumber)),'-','')
									OR
                                    @CriteriaEntityIDNumber_HasWildCard = 1 AND RTRIM(LTRIM(id.NumberUnformatted)) LIKE REPLACE(RTRIM(LTRIM(@CriteriaEntityIDNumber)),'-','')
									OR
									@CriteriaEntityIDNumber_HasWildCard = 0 AND RTRIM(LTRIM(id.NumberUnformatted)) = REPLACE(RTRIM(LTRIM(@CriteriaEntityIDNumber)),'-','')

								)
							)
						)
					)
				)
			)
		)
	)
	AND
	(
		@CriteriaReasonListed IS NULL
		OR
		(
			@CriteriaReasonListed IS NOT NULL
			AND
			(
				@CriteriaReasonListed_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.ReasonListed))) > 0
				OR
				(
					@CriteriaReasonListed_WildCardAny = 0
					AND
					(
						@CriteriaReasonListed_HasWildCard = 1 AND RTRIM(LTRIM(entity.ReasonListed)) LIKE @CriteriaReasonListed
						OR
						@CriteriaReasonListed_HasWildCard = 0 AND RTRIM(LTRIM(entity.ReasonListed)) = @CriteriaReasonListed
					)
				)
			)
		)
	)
	AND
	(
		@CriteriaReferenceNumber IS NULL
		OR
		(
			@CriteriaReferenceNumber IS NOT NULL
			AND
			(
				@CriteriaReferenceNumber_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.ReferenceNumber))) > 0
				OR
				(
					@CriteriaReferenceNumber_WildCardAny = 0
					AND
					(
						@CriteriaReferenceNumber_HasWildCard = 1 AND RTRIM(LTRIM(entity.ReferenceNumber)) LIKE @CriteriaReferenceNumber
						OR
						@CriteriaReferenceNumber_HasWildCard = 0 AND RTRIM(LTRIM(entity.ReferenceNumber)) = @CriteriaReferenceNumber
					)
				)
			)
		)
	)
	ORDER BY Id ASC;
END
GO

-- GRANT EXECUTE ON [dbo].[OlAcceptListSearch] TO cdbr_E;
-- GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'tr_CwlCustomWatchlist_del') BEGIN
	DROP TRIGGER tr_CwlCustomWatchlist_ins
END
GO
CREATE TRIGGER tr_CwlCustomWatchlist_ins
ON dbo.[CwlCustomWatchlist]
FOR INSERT
AS
	DECLARE @Id INT, @Type INT, @CustomerId INT;
	SELECT @Id = Id, @CustomerId = CustomerId, @Type = Type FROM INSERTED
	IF NOT EXISTS(SELECT 1 FROM dbo.[ListMapping] WHERE [InternalId] = @Id AND [Type] = @Type AND [CustomerId] = @CustomerId) BEGIN
		INSERT INTO [dbo].[ListMapping] ([InternalId], [Type], [CustomerId]) VALUES (@Id, @Type, @CustomerId)
	END
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'tr_CwlCustomWatchlist_upd') BEGIN
	DROP TRIGGER tr_CwlCustomWatchlist_upd
END
GO
CREATE TRIGGER tr_CwlCustomWatchlist_upd
ON dbo.[CwlCustomWatchlist]
FOR UPDATE
AS
	DECLARE @Id INT, @Type INT, @CustomerId INT;
	SELECT @Id = Id, @CustomerId = CustomerId, @Type = Type FROM INSERTED
	IF NOT EXISTS(SELECT 1 FROM dbo.[ListMapping] WHERE [InternalId] = @Id AND [Type] = @Type AND [CustomerId] = @CustomerId) BEGIN
		INSERT INTO [dbo].[ListMapping] ([InternalId], [Type], [CustomerId]) VALUES (@Id, @Type, @CustomerId)
	END
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'tr_CwlCustomWatchlist_del') BEGIN
	DROP TRIGGER tr_CwlCustomWatchlist_del
END
GO
CREATE TRIGGER tr_CwlCustomWatchlist_del
ON dbo.[CwlCustomWatchlist]
FOR DELETE
AS
	DECLARE @Id INT, @Type INT, @CustomerId INT;
	SELECT @Id = Id, @CustomerId = CustomerId, @Type = Type FROM DELETED
	DELETE FROM [dbo].[ListMapping] WHERE [CustomerId] = @CustomerId AND [InternalId] = @Id AND [Type] = @Type
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECTPROPERTY(object_id('dbo.CwlCustomWatchlistSearch'), N'IsProcedure') is null exec sp_executesql N'CREATE PROCEDURE [dbo].[CwlCustomWatchlistSearch] as return 0';
GO

ALTER PROCEDURE [dbo].[CwlCustomWatchlistSearch]
(
	@CustomerId AS INT,
	@ListId AS INT,
	@Divisions AS VARCHAR(MAX),
	@CriteriaDateListedEnd AS DATETIME = NULL,
	@CriteriaDateListedStart AS DATETIME = NULL,
	@CriteriaCountryName AS VARCHAR(MAX) = NULL,
	@CriteriaCountryAlternateName AS VARCHAR(MAX) = NULL,
	@CriteriaReasonListed AS VARCHAR(MAX) = NULL,
	@CriteriaReferenceNumber AS VARCHAR(MAX) = NULL,
	@CriteriaCountryCity AS VARCHAR(MAX) = NULL,
	@CriteriaCountryCode AS VARCHAR(MAX) = NULL,
	@CriteriaEntityEntityType AS INT = NULL,
	@CriteriaEntityEntityAddedBy AS VARCHAR(MAX) = NULL,
	@CriteriaEntityFirstName AS VARCHAR(MAX) = NULL,
	@CriteriaEntityMiddleName AS VARCHAR(MAX) = NULL,
	@CriteriaEntityLastName AS VARCHAR(MAX) = NULL,
	@CriteriaEntityFullName AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAdditionalInfoType AS INT = NULL,
	@CriteriaEntityAdditionalInfoValue1 AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAdditionalInfoValue2 AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressStreet1 AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressStreet2 AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressCity AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressCountry AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressPostalCode AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressStateProvinceDistrict AS VARCHAR(MAX) = NULL,
	@CriteriaEntityAddressPhone AS VARCHAR(MAX) = NULL,
	@CriteriaEntityIDType AS INT = NULL,
	@CriteriaEntityIDLabel AS VARCHAR(MAX) = NULL,
	@CriteriaEntityIDNumber AS VARCHAR(MAX) = NULL,
	@CwlCustomWatchlistType AS BIT = 1
)
AS
BEGIN

	/*
	DECLARE @UserDivisions TABLE (Id INT, DivisionId INT);
	INSERT INTO @UserDivisions (Id, DivisionId)
		SELECT Id, CAST(Data AS INT) FROM dbo.Split(@Divisions, ',');
	*/

	SET @CriteriaCountryName = RTRIM(LTRIM(@CriteriaCountryName))
	SET @CriteriaCountryName = CASE WHEN (@CriteriaCountryName IS NULL OR LEN(@CriteriaCountryName) = 0) THEN NULL ELSE @CriteriaCountryName END;
	SET @CriteriaCountryName = REPLACE (@CriteriaCountryName ,'*' ,'%')
	SET @CriteriaCountryName = REPLACE (@CriteriaCountryName ,'?' ,'_')
	DECLARE @CriteriaCountryName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaCountryName) > 0 OR CHARINDEX('_', @CriteriaCountryName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaCountryName_WildCardAny AS BIT = CASE WHEN @CriteriaCountryName_HasWildCard = 1 AND @CriteriaCountryName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaCountryAlternateName = RTRIM(LTRIM(@CriteriaCountryAlternateName))
	SET @CriteriaCountryAlternateName = CASE WHEN @CriteriaCountryAlternateName IS NULL OR LEN(@CriteriaCountryAlternateName) = 0 THEN NULL ELSE @CriteriaCountryAlternateName END;
	SET @CriteriaCountryAlternateName = REPLACE (@CriteriaCountryAlternateName ,'*' ,'%')
	SET @CriteriaCountryAlternateName = REPLACE (@CriteriaCountryAlternateName ,'?' ,'_')
	DECLARE @CriteriaCountryAlternateName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaCountryAlternateName) > 0 OR CHARINDEX('_', @CriteriaCountryAlternateName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaCountryAlternateName_WildCardAny AS BIT = CASE WHEN @CriteriaCountryAlternateName_HasWildCard = 1 AND @CriteriaCountryAlternateName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaReasonListed = RTRIM(LTRIM(@CriteriaReasonListed))
	SET @CriteriaReasonListed = CASE WHEN @CriteriaReasonListed IS NULL OR LEN(@CriteriaReasonListed) = 0 THEN NULL ELSE @CriteriaReasonListed END;
	SET @CriteriaReasonListed = REPLACE (@CriteriaReasonListed ,'*' ,'%')
	SET @CriteriaReasonListed = REPLACE (@CriteriaReasonListed ,'?' ,'_')
	DECLARE @CriteriaReasonListed_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaReasonListed) > 0 OR CHARINDEX('_', @CriteriaReasonListed) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaReasonListed_WildCardAny AS BIT = CASE WHEN @CriteriaReasonListed_HasWildCard = 1 AND @CriteriaReasonListed = '%' THEN 1 ELSE 0 END;

	SET @CriteriaReferenceNumber = RTRIM(LTRIM(@CriteriaReferenceNumber))
	SET @CriteriaReferenceNumber = CASE WHEN @CriteriaReferenceNumber IS NULL OR LEN(@CriteriaReferenceNumber) = 0 THEN NULL ELSE @CriteriaReferenceNumber END;
	SET @CriteriaReferenceNumber = REPLACE (@CriteriaReferenceNumber ,'*' ,'%')
	SET @CriteriaReferenceNumber = REPLACE (@CriteriaReferenceNumber ,'?' ,'_')
	DECLARE @CriteriaReferenceNumber_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaReferenceNumber) > 0 OR CHARINDEX('_', @CriteriaReferenceNumber) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaReferenceNumber_WildCardAny AS BIT = CASE WHEN @CriteriaReferenceNumber_HasWildCard = 1 AND @CriteriaReferenceNumber = '%' THEN 1 ELSE 0 END;

	SET @CriteriaCountryCity = RTRIM(LTRIM(@CriteriaCountryCity))
	SET @CriteriaCountryCity = CASE WHEN @CriteriaCountryCity IS NULL OR LEN(@CriteriaCountryCity) = 0 THEN NULL ELSE @CriteriaCountryCity END;
	SET @CriteriaCountryCity = REPLACE (@CriteriaCountryCity ,'*' ,'%')
	SET @CriteriaCountryCity = REPLACE (@CriteriaCountryCity ,'?' ,'_')
	DECLARE @CriteriaCountryCity_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaCountryCity) > 0 OR CHARINDEX('_', @CriteriaCountryCity) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaCountryCity_WildCardAny AS BIT = CASE WHEN @CriteriaCountryCity_HasWildCard = 1 AND @CriteriaCountryCity = '%' THEN 1 ELSE 0 END;

	SET @CriteriaCountryCode = RTRIM(LTRIM(@CriteriaCountryCode))
	SET @CriteriaCountryCode = CASE WHEN @CriteriaCountryCode IS NULL OR LEN(@CriteriaCountryCode) = 0 THEN NULL ELSE @CriteriaCountryCode END;
	SET @CriteriaCountryCode = REPLACE (@CriteriaCountryCode ,'*' ,'%')
	SET @CriteriaCountryCode = REPLACE (@CriteriaCountryCode ,'?' ,'_')
	DECLARE @CriteriaCountryCode_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaCountryCode) > 0 OR CHARINDEX('_', @CriteriaCountryCode) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaCountryCode_WildCardAny AS BIT = CASE WHEN @CriteriaCountryCode_HasWildCard = 1 AND @CriteriaCountryCode = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityEntityAddedBy = RTRIM(LTRIM(@CriteriaEntityEntityAddedBy))
	SET @CriteriaEntityEntityAddedBy = CASE WHEN @CriteriaEntityEntityAddedBy IS NULL OR LEN(@CriteriaEntityEntityAddedBy) = 0 THEN NULL ELSE @CriteriaEntityEntityAddedBy END;
	SET @CriteriaEntityEntityAddedBy = REPLACE (@CriteriaEntityEntityAddedBy ,'*' ,'%')
	SET @CriteriaEntityEntityAddedBy = REPLACE (@CriteriaEntityEntityAddedBy ,'?' ,'_')
	DECLARE @CriteriaEntityEntityAddedBy_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityEntityAddedBy) > 0 OR CHARINDEX('_', @CriteriaEntityEntityAddedBy) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityEntityAddedBy_WildCardAny AS BIT = CASE WHEN @CriteriaEntityEntityAddedBy_HasWildCard = 1 AND @CriteriaEntityEntityAddedBy = '%' THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityEntityAddedByUserName AS VARCHAR(255);
	SET @CriteriaEntityEntityAddedByUserName = '';
	IF @CriteriaEntityEntityAddedBy IS NOT NULL 
	BEGIN
		SELECT  @CriteriaEntityEntityAddedByUserName=profile.FullName FROM BridgerRFCommon.dbo.UserMgmtUsers as [user]
		inner join  BridgerRFCommon.dbo.UserMgmtUserProfiles as profile on [user].id=profile.id
		where loginName = @CriteriaEntityEntityAddedBy  and customer_id= @CustomerId and [user].IsDeleted = 0 and [user].isActive=1;
	END 
	




	SET @CriteriaEntityFirstName = RTRIM(LTRIM(@CriteriaEntityFirstName))
	SET @CriteriaEntityFirstName = CASE WHEN @CriteriaEntityFirstName IS NULL OR LEN(@CriteriaEntityFirstName) = 0 THEN NULL ELSE @CriteriaEntityFirstName END;
	SET @CriteriaEntityFirstName = REPLACE (@CriteriaEntityFirstName ,'*' ,'%')
	SET @CriteriaEntityFirstName = REPLACE (@CriteriaEntityFirstName ,'?' ,'_')
	DECLARE @CriteriaEntityFirstName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityFirstName) > 0 OR CHARINDEX('_', @CriteriaEntityFirstName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityFirstName_WildCardAny AS BIT = CASE WHEN @CriteriaEntityFirstName_HasWildCard = 1 AND @CriteriaEntityFirstName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityMiddleName = RTRIM(LTRIM(@CriteriaEntityMiddleName))
	SET @CriteriaEntityMiddleName = CASE WHEN @CriteriaEntityMiddleName IS NULL OR LEN(@CriteriaEntityMiddleName) = 0 THEN NULL ELSE @CriteriaEntityMiddleName END;
	SET @CriteriaEntityMiddleName = REPLACE (@CriteriaEntityMiddleName ,'*' ,'%')
	SET @CriteriaEntityMiddleName = REPLACE (@CriteriaEntityMiddleName ,'?' ,'_')
	DECLARE @CriteriaEntityMiddleName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityMiddleName) > 0 OR CHARINDEX('_', @CriteriaEntityMiddleName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityMiddleName_WildCardAny AS BIT = CASE WHEN @CriteriaEntityMiddleName_HasWildCard = 1 AND @CriteriaEntityMiddleName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityLastName = RTRIM(LTRIM(@CriteriaEntityLastName))
	SET @CriteriaEntityLastName = CASE WHEN @CriteriaEntityLastName IS NULL OR LEN(@CriteriaEntityLastName) = 0 THEN NULL ELSE @CriteriaEntityLastName END;
	SET @CriteriaEntityLastName = REPLACE (@CriteriaEntityLastName ,'*' ,'%')
	SET @CriteriaEntityLastName = REPLACE (@CriteriaEntityLastName ,'?' ,'_')
	DECLARE @CriteriaEntityLastName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityLastName) > 0 OR CHARINDEX('_', @CriteriaEntityLastName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityLastName_WildCardAny AS BIT = CASE WHEN @CriteriaEntityLastName_HasWildCard = 1 AND @CriteriaEntityLastName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityFullName = RTRIM(LTRIM(@CriteriaEntityFullName))
	SET @CriteriaEntityFullName = CASE WHEN @CriteriaEntityFullName IS NULL OR LEN(@CriteriaEntityFullName) = 0 THEN NULL ELSE @CriteriaEntityFullName END;
	SET @CriteriaEntityFullName = REPLACE (@CriteriaEntityFullName ,'*' ,'%')
	SET @CriteriaEntityFullName = REPLACE (@CriteriaEntityFullName ,'?' ,'_')
	DECLARE @CriteriaEntityFullName_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityFullName) > 0 OR CHARINDEX('_', @CriteriaEntityFullName) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityFullName_WildCardAny AS BIT = CASE WHEN @CriteriaEntityFullName_HasWildCard = 1 AND @CriteriaEntityFullName = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAdditionalInfoValue1 = RTRIM(LTRIM(@CriteriaEntityAdditionalInfoValue1))
	SET @CriteriaEntityAdditionalInfoValue1 = CASE WHEN @CriteriaEntityAdditionalInfoValue1 IS NULL OR LEN(@CriteriaEntityAdditionalInfoValue1) = 0 THEN NULL ELSE @CriteriaEntityAdditionalInfoValue1 END;
	SET @CriteriaEntityAdditionalInfoValue1 = REPLACE (@CriteriaEntityAdditionalInfoValue1 ,'*' ,'%')
	SET @CriteriaEntityAdditionalInfoValue1 = REPLACE (@CriteriaEntityAdditionalInfoValue1 ,'?' ,'_')
	DECLARE @CriteriaEntityAdditionalInfoValue1_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAdditionalInfoValue1) > 0 OR CHARINDEX('_', @CriteriaEntityAdditionalInfoValue1) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAdditionalInfoValue1_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAdditionalInfoValue1_HasWildCard = 1 AND @CriteriaEntityAdditionalInfoValue1 = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAdditionalInfoValue2 = RTRIM(LTRIM(@CriteriaEntityAdditionalInfoValue2))
	SET @CriteriaEntityAdditionalInfoValue2 = CASE WHEN @CriteriaEntityAdditionalInfoValue2 IS NULL OR LEN(@CriteriaEntityAdditionalInfoValue2) = 0 THEN NULL ELSE @CriteriaEntityAdditionalInfoValue2 END;
	SET @CriteriaEntityAdditionalInfoValue2 = REPLACE (@CriteriaEntityAdditionalInfoValue2 ,'*' ,'%')
	SET @CriteriaEntityAdditionalInfoValue2 = REPLACE (@CriteriaEntityAdditionalInfoValue2 ,'?' ,'_')
	DECLARE @CriteriaEntityAdditionalInfoValue2_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAdditionalInfoValue2) > 0 OR CHARINDEX('_', @CriteriaEntityAdditionalInfoValue2) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAdditionalInfoValue2_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAdditionalInfoValue2_HasWildCard = 1 AND @CriteriaEntityAdditionalInfoValue2 = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressStreet1 = RTRIM(LTRIM(@CriteriaEntityAddressStreet1))
	SET @CriteriaEntityAddressStreet1 = CASE WHEN @CriteriaEntityAddressStreet1 IS NULL OR LEN(@CriteriaEntityAddressStreet1) = 0 THEN NULL ELSE @CriteriaEntityAddressStreet1 END;
	SET @CriteriaEntityAddressStreet1 = REPLACE (@CriteriaEntityAddressStreet1 ,'*' ,'%')
	SET @CriteriaEntityAddressStreet1 = REPLACE (@CriteriaEntityAddressStreet1 ,'?' ,'_')
	DECLARE @CriteriaEntityAddressStreet1_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressStreet1) > 0 OR CHARINDEX('_', @CriteriaEntityAddressStreet1) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressStreet1_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressStreet1_HasWildCard = 1 AND @CriteriaEntityAddressStreet1 = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressStreet2 = RTRIM(LTRIM(@CriteriaEntityAddressStreet2))
	SET @CriteriaEntityAddressStreet2 = CASE WHEN @CriteriaEntityAddressStreet2 IS NULL OR LEN(@CriteriaEntityAddressStreet2) = 0 THEN NULL ELSE @CriteriaEntityAddressStreet2 END;
	SET @CriteriaEntityAddressStreet2 = REPLACE (@CriteriaEntityAddressStreet2 ,'*' ,'%')
	SET @CriteriaEntityAddressStreet2 = REPLACE (@CriteriaEntityAddressStreet2 ,'?' ,'_')
	DECLARE @CriteriaEntityAddressStreet2_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressStreet2) > 0 OR CHARINDEX('_', @CriteriaEntityAddressStreet2) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressStreet2_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressStreet2_HasWildCard = 1 AND @CriteriaEntityAddressStreet2 = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressCity = RTRIM(LTRIM(@CriteriaEntityAddressCity))
	SET @CriteriaEntityAddressCity = CASE WHEN @CriteriaEntityAddressCity IS NULL OR LEN(@CriteriaEntityAddressCity) = 0 THEN NULL ELSE @CriteriaEntityAddressCity END;
	SET @CriteriaEntityAddressCity = REPLACE (@CriteriaEntityAddressCity ,'*' ,'%')
	SET @CriteriaEntityAddressCity = REPLACE (@CriteriaEntityAddressCity ,'?' ,'_')
	DECLARE @CriteriaEntityAddressCity_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressCity) > 0 OR CHARINDEX('_', @CriteriaEntityAddressCity) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressCity_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressCity_HasWildCard = 1 AND @CriteriaEntityAddressCity = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressCountry = RTRIM(LTRIM(@CriteriaEntityAddressCountry))
	SET @CriteriaEntityAddressCountry = CASE WHEN @CriteriaEntityAddressCountry IS NULL OR LEN(@CriteriaEntityAddressCountry) = 0 THEN NULL ELSE @CriteriaEntityAddressCountry END;
	SET @CriteriaEntityAddressCountry = REPLACE (@CriteriaEntityAddressCountry ,'*' ,'%')
	SET @CriteriaEntityAddressCountry = REPLACE (@CriteriaEntityAddressCountry ,'?' ,'_')
	DECLARE @CriteriaEntityAddressCountry_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressCountry) > 0 OR CHARINDEX('_', @CriteriaEntityAddressCountry) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressCountry_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressCountry_HasWildCard = 1 AND @CriteriaEntityAddressCountry = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressPostalCode = RTRIM(LTRIM(@CriteriaEntityAddressPostalCode))
	SET @CriteriaEntityAddressPostalCode = CASE WHEN @CriteriaEntityAddressPostalCode IS NULL OR LEN(@CriteriaEntityAddressPostalCode) = 0 THEN NULL ELSE @CriteriaEntityAddressPostalCode END;
	SET @CriteriaEntityAddressPostalCode = REPLACE (@CriteriaEntityAddressPostalCode ,'*' ,'%')
	SET @CriteriaEntityAddressPostalCode = REPLACE (@CriteriaEntityAddressPostalCode ,'?' ,'_')
	DECLARE @CriteriaEntityAddressPostalCode_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressPostalCode) > 0 OR CHARINDEX('_', @CriteriaEntityAddressPostalCode) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressPostalCode_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressPostalCode_HasWildCard = 1 AND @CriteriaEntityAddressPostalCode = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressStateProvinceDistrict = RTRIM(LTRIM(@CriteriaEntityAddressStateProvinceDistrict))
	SET @CriteriaEntityAddressStateProvinceDistrict = CASE WHEN @CriteriaEntityAddressStateProvinceDistrict IS NULL OR LEN(@CriteriaEntityAddressStateProvinceDistrict) = 0 THEN NULL ELSE @CriteriaEntityAddressStateProvinceDistrict END;
	SET @CriteriaEntityAddressStateProvinceDistrict = REPLACE (@CriteriaEntityAddressStateProvinceDistrict ,'*' ,'%')
	SET @CriteriaEntityAddressStateProvinceDistrict = REPLACE (@CriteriaEntityAddressStateProvinceDistrict ,'?' ,'_')
	DECLARE @CriteriaEntityAddressStateProvinceDistrict_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressStateProvinceDistrict) > 0 OR CHARINDEX('_', @CriteriaEntityAddressStateProvinceDistrict) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressStateProvinceDistrict_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressStateProvinceDistrict_HasWildCard = 1 AND @CriteriaEntityAddressStateProvinceDistrict = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityAddressPhone = RTRIM(LTRIM(@CriteriaEntityAddressPhone));
	SET @CriteriaEntityAddressPhone = CASE WHEN @CriteriaEntityAddressPhone IS NULL OR LEN(@CriteriaEntityAddressPhone) = 0 THEN NULL ELSE @CriteriaEntityAddressPhone END;
	SET @CriteriaEntityAddressPhone = REPLACE (@CriteriaEntityAddressPhone ,'*' ,'%');
	SET @CriteriaEntityAddressPhone = REPLACE (@CriteriaEntityAddressPhone ,'?' ,'_');
	DECLARE @CriteriaEntityAddressPhone_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityAddressPhone) > 0 OR CHARINDEX('_', @CriteriaEntityAddressPhone) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityAddressPhone_WildCardAny AS BIT = CASE WHEN @CriteriaEntityAddressPhone_HasWildCard = 1 AND @CriteriaEntityAddressPhone = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityIDLabel = RTRIM(LTRIM(@CriteriaEntityIDLabel))
	SET @CriteriaEntityIDLabel = CASE WHEN @CriteriaEntityIDLabel IS NULL OR LEN(@CriteriaEntityIDLabel) = 0 THEN NULL ELSE @CriteriaEntityIDLabel END;
	SET @CriteriaEntityIDLabel = REPLACE (@CriteriaEntityIDLabel ,'*' ,'%')
	SET @CriteriaEntityIDLabel = REPLACE (@CriteriaEntityIDLabel ,'?' ,'_')
	DECLARE @CriteriaEntityIDLabel_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityIDLabel) > 0 OR CHARINDEX('_', @CriteriaEntityIDLabel) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityIDLabel_WildCardAny AS BIT = CASE WHEN @CriteriaEntityIDLabel_HasWildCard = 1 AND @CriteriaEntityIDLabel = '%' THEN 1 ELSE 0 END;

	SET @CriteriaEntityIDNumber = RTRIM(LTRIM(@CriteriaEntityIDNumber))
	SET @CriteriaEntityIDNumber = REPLACE(@CriteriaEntityIDNumber, '-', '')
	SET @CriteriaEntityIDNumber = CASE WHEN @CriteriaEntityIDNumber IS NULL OR LEN(@CriteriaEntityIDNumber) = 0 THEN NULL ELSE @CriteriaEntityIDNumber END;
	SET @CriteriaEntityIDNumber = REPLACE (@CriteriaEntityIDNumber ,'*' ,'%')
	SET @CriteriaEntityIDNumber = REPLACE (@CriteriaEntityIDNumber ,'?' ,'_')
	DECLARE @CriteriaEntityIDNumber_HasWildCard AS BIT = CASE WHEN CHARINDEX('%', @CriteriaEntityIDNumber) > 0 OR CHARINDEX('_', @CriteriaEntityIDNumber) > 0 THEN 1 ELSE 0 END;
	DECLARE @CriteriaEntityIDNumber_WildCardAny AS BIT = CASE WHEN @CriteriaEntityIDNumber_HasWildCard = 1 AND @CriteriaEntityIDNumber = '%' THEN 1 ELSE 0 END;

	DECLARE @CriteriaEntityAdditionalInfoValue1AsDecimal AS DECIMAL(18,4);
	DECLARE @CriteriaEntityAdditionalInfoValue2AsDecimal AS DECIMAL(18,4);
	DECLARE @CriteriaEntityAdditionalInfoValue1AsDatetime AS DATETIME;
	DECLARE @CriteriaEntityAdditionalInfoValue2AsDatetime AS DATETIME;

	IF @CriteriaEntityAdditionalInfoType IN (20,18,12,7) BEGIN
		IF @CriteriaEntityAdditionalInfoValue1 IS NOT NULL
			SET @CriteriaEntityAdditionalInfoValue1AsDecimal = CAST(@CriteriaEntityAdditionalInfoValue1 AS DECIMAL(18,4));
		IF @CriteriaEntityAdditionalInfoValue2 IS NOT NULL
			SET @CriteriaEntityAdditionalInfoValue2AsDecimal = CAST(@CriteriaEntityAdditionalInfoValue2 AS DECIMAL(18,4));
	END ELSE IF @CriteriaEntityAdditionalInfoType IN (4) BEGIN
		IF @CriteriaEntityAdditionalInfoValue1 IS NOT NULL
			SET @CriteriaEntityAdditionalInfoValue1AsDatetime = CAST(@CriteriaEntityAdditionalInfoValue1 AS DATETIME);
		IF @CriteriaEntityAdditionalInfoValue2 IS NOT NULL
			SET @CriteriaEntityAdditionalInfoValue2AsDatetime = CAST(@CriteriaEntityAdditionalInfoValue2 AS DATETIME);
	END

	IF @CwlCustomWatchlistType = 1 BEGIN
		SELECT country.Id FROM dbo.CwlCountryEntity AS country
		INNER JOIN dbo.CwlCustomWatchlist cwl ON country.CustomWatchlist_Id = cwl.Id
		WHERE country.CustomWatchlist_Id = @ListId AND cwl.CustomerId = @CustomerId AND country.IsDeleted = 0		
		AND
		(
			@CriteriaDateListedEnd IS NULL OR country.DateListed <= @CriteriaDateListedEnd
		)
		AND
		(
			@CriteriaDateListedStart IS NULL OR country.DateListed >= @CriteriaDateListedStart
		)
		AND
		(
			@CriteriaEntityEntityAddedBy IS NULL
			OR
			(
					country.CreatedBy Like '%\' + @CriteriaEntityEntityAddedBy +')'

					OR
					(
						@CriteriaEntityEntityAddedByUserName = '' OR (country.CreatedBy= @CriteriaEntityEntityAddedByUserName)
					)
			)
		)
		AND
		(
			@CriteriaCountryName IS NULL
			OR
			(
				@CriteriaCountryName IS NOT NULL
				AND
				(
					@CriteriaCountryName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(country.Country))) > 0
					OR
					(
						@CriteriaCountryName_WildCardAny = 0
						AND
						(
							@CriteriaCountryName_HasWildCard = 1 AND RTRIM(LTRIM(country.Country)) LIKE @CriteriaCountryName
							OR
							@CriteriaCountryName_HasWildCard = 0 AND RTRIM(LTRIM(country.Country)) = @CriteriaCountryName
						)
					)
				)
			)
			OR
			(
				@CriteriaCountryName IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM dbo.CwlCountryAka aka
					WHERE aka.CountryEntity_Id = country.Id
					AND aka.Type = 1 --AKA
					AND aka.IsDeleted = 0
					AND
					(
						@CriteriaCountryName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.Name))) > 0
						OR
						(
							@CriteriaCountryName_WildCardAny = 0
							AND
							(
								@CriteriaCountryName_HasWildCard = 1 AND RTRIM(LTRIM(aka.Name)) LIKE @CriteriaCountryName
								OR
								@CriteriaCountryName_HasWildCard = 0 AND RTRIM(LTRIM(aka.Name)) = @CriteriaCountryName
							)
						)

					)
				)
			)
		)
		AND
		(
			@CriteriaCountryAlternateName IS NULL
			OR
			(
				@CriteriaCountryAlternateName IS NOT NULL
				AND
				(
					@CriteriaCountryAlternateName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(country.Country))) > 0
					OR
					(
						@CriteriaCountryAlternateName_WildCardAny = 0
						AND
						(
							@CriteriaCountryAlternateName_HasWildCard = 1 AND RTRIM(LTRIM(country.Country)) LIKE @CriteriaCountryAlternateName
							OR
							@CriteriaCountryAlternateName_HasWildCard = 0 AND RTRIM(LTRIM(country.Country)) = @CriteriaCountryAlternateName
						)
					)
				)
			)
			OR
			(
				@CriteriaCountryAlternateName IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM dbo.CwlCountryAka aka
					WHERE aka.CountryEntity_Id = country.Id
					AND aka.Type = 1 --AKA
					AND aka.IsDeleted = 0
					AND
					(
						@CriteriaCountryAlternateName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.Name))) > 0
						OR
						(
							@CriteriaCountryAlternateName_WildCardAny = 0
							AND
							(
								@CriteriaCountryAlternateName_HasWildCard = 1 AND RTRIM(LTRIM(aka.Name)) LIKE @CriteriaCountryAlternateName
								OR
								@CriteriaCountryAlternateName_HasWildCard = 0 AND RTRIM(LTRIM(aka.Name)) = @CriteriaCountryAlternateName
							)
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaReasonListed IS NULL
			OR
			(
				@CriteriaReasonListed IS NOT NULL
				AND
				(
					@CriteriaReasonListed_WildCardAny = 1 AND LEN(RTRIM(LTRIM(country.ReasonListed))) > 0
					OR
					(
						@CriteriaReasonListed_WildCardAny = 0
						AND
						(
							@CriteriaReasonListed_HasWildCard = 1 AND RTRIM(LTRIM(country.ReasonListed)) LIKE @CriteriaReasonListed
							OR
							@CriteriaReasonListed_HasWildCard = 0 AND RTRIM(LTRIM(country.ReasonListed)) = @CriteriaReasonListed
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaReferenceNumber IS NULL
			OR
			(
				@CriteriaReferenceNumber IS NOT NULL
				AND
				(
					@CriteriaReferenceNumber_WildCardAny = 1 AND LEN(RTRIM(LTRIM(country.ReferenceNumber))) > 0
					OR
					(
						@CriteriaReferenceNumber_WildCardAny = 0
						AND
						(
							@CriteriaReferenceNumber_HasWildCard = 1 AND RTRIM(LTRIM(country.ReferenceNumber)) LIKE @CriteriaReferenceNumber
							OR
							@CriteriaReferenceNumber_HasWildCard = 0 AND RTRIM(LTRIM(country.ReferenceNumber)) = @CriteriaReferenceNumber
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaCountryCity IS NULL
			OR
			(
				@CriteriaCountryCity IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM dbo.CwlCountryLocation loc
					WHERE loc.CountryEntity_Id = country.Id
					AND loc.Type = 4 --City
					AND loc.IsDeleted = 0
					AND
					(
						@CriteriaCountryCity_WildCardAny = 1 AND LEN(RTRIM(LTRIM(loc.Name))) > 0
						OR
						(
							@CriteriaCountryCity_WildCardAny = 0
							AND
							(
								@CriteriaCountryCity_HasWildCard = 1 AND RTRIM(LTRIM(loc.Name)) LIKE @CriteriaCountryCity
								OR
								@CriteriaCountryCity_HasWildCard = 0 AND RTRIM(LTRIM(loc.Name)) = @CriteriaCountryCity
							)
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaCountryCode IS NULL
			OR
			(
				@CriteriaCountryCode IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM dbo.CwlCountryAka aka
					WHERE aka.CountryEntity_Id = country.Id
					AND aka.Type = 2 --Code
					AND aka.IsDeleted = 0
					AND
					(
						@CriteriaCountryCode_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.Name))) > 0
						OR
						(
							@CriteriaCountryCode_WildCardAny = 0
							AND
							(
								@CriteriaCountryCode_HasWildCard = 1 AND RTRIM(LTRIM(aka.Name)) LIKE @CriteriaCountryCode
								OR
								@CriteriaCountryCode_HasWildCard = 0 AND RTRIM(LTRIM(aka.Name)) = @CriteriaCountryCode
							)
						)
					)
				)
			)
		)
		ORDER BY Id ASC
	END ELSE BEGIN
		SELECT entity.Id FROM dbo.CWLEntity AS entity
		INNER JOIN dbo.CwlCustomWatchlist cwl ON entity.CustomWatchlist_Id = cwl.Id
		WHERE entity.CustomWatchlist_Id = @ListId AND cwl.CustomerId = @CustomerId
		AND entity.IsDeleted = 0		
		AND
		(
			@CriteriaEntityEntityType = 0 OR @CriteriaEntityEntityType IS NULL OR entity.[Type] = @CriteriaEntityEntityType
		)
		AND
		(
			@CriteriaDateListedEnd IS NULL OR @CriteriaDateListedEnd IS NOT NULL AND entity.DateListed <= @CriteriaDateListedEnd
		)
		AND
		(
			@CriteriaDateListedStart IS NULL OR @CriteriaDateListedStart IS NOT NULL AND entity.DateListed >= @CriteriaDateListedStart
		)
		AND
		(
			@CriteriaEntityEntityAddedBy IS NULL
			OR
			(
				entity.CreatedBy Like '%\' + @CriteriaEntityEntityAddedBy +')'

				OR
				(
					@CriteriaEntityEntityAddedByUserName = '' OR (entity.CreatedBy= @CriteriaEntityEntityAddedByUserName)
				)
			)
		)
		AND
		(
			@CriteriaEntityFirstName IS NULL
			OR
			(
				@CriteriaEntityFirstName IS NOT NULL
				AND
				(
					@CriteriaEntityFirstName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.[First]))) > 0
					OR
					(
						@CriteriaEntityFirstName_WildCardAny = 0
						AND
						(
							@CriteriaEntityFirstName_HasWildCard = 1 AND RTRIM(LTRIM(entity.[First])) LIKE @CriteriaEntityFirstName
							OR
							@CriteriaEntityFirstName_HasWildCard = 0 AND RTRIM(LTRIM(entity.[First])) = @CriteriaEntityFirstName
						)
					)
				)
			)
			OR
			(
				@CriteriaEntityFirstName IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM dbo.CwlAka aka
					WHERE aka.Entity_Id = entity.Id
					AND aka.IsDeleted = 0
					AND
					(
						@CriteriaEntityFirstName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.[First]))) > 0
						OR
						(
							@CriteriaEntityFirstName_WildCardAny = 0
							AND
							(
								@CriteriaEntityFirstName_HasWildCard = 1 AND RTRIM(LTRIM(aka.[First])) LIKE @CriteriaEntityFirstName
								OR
								@CriteriaEntityFirstName_HasWildCard = 0 AND RTRIM(LTRIM(aka.[First])) = @CriteriaEntityFirstName
							)
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaEntityMiddleName IS NULL
			OR
			(
				@CriteriaEntityMiddleName IS NOT NULL
				AND
				(
					@CriteriaEntityMiddleName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.Middle))) > 0
					OR
					(
						@CriteriaEntityMiddleName_WildCardAny = 0
						AND
						(
							@CriteriaEntityMiddleName_HasWildCard = 1 AND RTRIM(LTRIM(entity.Middle)) LIKE @CriteriaEntityMiddleName
							OR
							@CriteriaEntityMiddleName_HasWildCard = 0 AND RTRIM(LTRIM(entity.Middle)) = @CriteriaEntityMiddleName
						)
					)
				)
			)
			OR
			(
				@CriteriaEntityMiddleName IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM dbo.CwlAka aka
					WHERE aka.Entity_Id = entity.Id
					AND aka.IsDeleted = 0
					AND
					(
						@CriteriaEntityMiddleName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.Middle))) > 0
						OR
						(
							@CriteriaEntityMiddleName_WildCardAny = 0
							AND
							(
								@CriteriaEntityMiddleName_HasWildCard = 1 AND RTRIM(LTRIM(aka.Middle)) LIKE @CriteriaEntityMiddleName
								OR
								@CriteriaEntityMiddleName_HasWildCard = 0 AND RTRIM(LTRIM(aka.Middle)) = @CriteriaEntityMiddleName
							)
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaEntityLastName IS NULL
			OR
			(
				@CriteriaEntityLastName IS NOT NULL
				AND
				(
					@CriteriaEntityLastName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.[Last]))) > 0
					OR
					(
						@CriteriaEntityLastName_WildCardAny = 0
						AND
						(
							@CriteriaEntityLastName_HasWildCard = 1 AND RTRIM(LTRIM(entity.[Last])) LIKE @CriteriaEntityLastName
							OR
							@CriteriaEntityLastName_HasWildCard = 0 AND RTRIM(LTRIM(entity.[Last])) = @CriteriaEntityLastName
						)
					)
				)
			)
			OR
			(
				@CriteriaEntityLastName IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM dbo.CwlAka aka
					WHERE aka.Entity_Id = entity.Id
					AND aka.IsDeleted = 0
					AND
					(
						@CriteriaEntityLastName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.[Last]))) > 0
						OR
						(
							@CriteriaEntityLastName_WildCardAny = 0
							AND
							(
								@CriteriaEntityLastName_HasWildCard = 1 AND RTRIM(LTRIM(aka.[Last])) LIKE @CriteriaEntityLastName
								OR
								@CriteriaEntityLastName_HasWildCard = 0 AND RTRIM(LTRIM(aka.[Last])) = @CriteriaEntityLastName
							)
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaEntityFullName IS NULL
			OR
			(
				@CriteriaEntityFullName IS NOT NULL
				AND
				(
					@CriteriaEntityFullName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.[Full]))) > 0
					OR
					(
						@CriteriaEntityFullName_WildCardAny = 0
						AND
						(
							@CriteriaEntityFullName_HasWildCard = 1 AND RTRIM(LTRIM(entity.[Full])) LIKE @CriteriaEntityFullName
							OR
							@CriteriaEntityFullName_HasWildCard = 0 AND RTRIM(LTRIM(entity.[Full])) = @CriteriaEntityFullName
						)
					)
				)
			)
			OR
			@CriteriaEntityFullName IS NOT NULL
			AND
			EXISTS(SELECT 1 FROM dbo.CwlAka aka
				WHERE aka.Entity_Id = entity.Id
				AND aka.IsDeleted = 0
				AND
				(
					@CriteriaEntityFullName_WildCardAny = 1 AND LEN(RTRIM(LTRIM(aka.[Full]))) > 0
					OR
					(
						@CriteriaEntityFullName_WildCardAny = 0
						AND
						(
							@CriteriaEntityFullName_HasWildCard = 1 AND RTRIM(LTRIM(aka.[Full])) LIKE @CriteriaEntityFullName
							OR
							@CriteriaEntityFullName_HasWildCard = 0 AND RTRIM(LTRIM(aka.[Full])) = @CriteriaEntityFullName
						)
					)
				)
			)
		)
		AND
		(
			(
				@CriteriaEntityAdditionalInfoType IS NULL
				OR @CriteriaEntityAdditionalInfoType = 0
				OR @CriteriaEntityAdditionalInfoValue1 IS NULL AND @CriteriaEntityAdditionalInfoValue2 IS NULL
			)
			OR
  			(
				@CriteriaEntityAdditionalInfoType IS NOT NULL
				AND @CriteriaEntityAdditionalInfoType > 0
				AND
				(
					@CriteriaEntityAdditionalInfoValue1 IS NOT NULL
					OR
					@CriteriaEntityAdditionalInfoValue2 IS NOT NULL
				)
				AND
				EXISTS(SELECT 1 FROM dbo.CwlAdditionalInfo info
					WHERE info.Entity_Id = entity.Id
					AND info.[Type] = @CriteriaEntityAdditionalInfoType
					AND info.IsDeleted = 0
					AND
					(
						@CriteriaEntityAdditionalInfoType IN (4)
							AND (@CriteriaEntityAdditionalInfoValue1AsDatetime IS NOT NULL OR @CriteriaEntityAdditionalInfoValue2AsDatetime IS NOT NULL)
							AND (@CriteriaEntityAdditionalInfoValue1AsDatetime IS NULL OR @CriteriaEntityAdditionalInfoValue1AsDatetime IS NOT NULL AND @CriteriaEntityAdditionalInfoValue1AsDatetime <= CAST(info.Value AS DATETIME))
							AND (@CriteriaEntityAdditionalInfoValue2AsDatetime IS NULL OR @CriteriaEntityAdditionalInfoValue2AsDatetime IS NOT NULL AND @CriteriaEntityAdditionalInfoValue2AsDatetime >= CAST(info.Value AS DATETIME))
						OR
						@CriteriaEntityAdditionalInfoType NOT IN (4)
							AND (@CriteriaEntityAdditionalInfoValue1 IS NOT NULL OR @CriteriaEntityAdditionalInfoValue2 IS NOT NULL)
							AND
							(
								@CriteriaEntityAdditionalInfoValue1 IS NOT NULL
								AND
								(
									@CriteriaEntityAdditionalInfoValue1_WildCardAny = 1 AND LEN(RTRIM(LTRIM(info.Value))) > 0
									OR
									(
										@CriteriaEntityAdditionalInfoValue1_WildCardAny = 0
										AND
										(
											@CriteriaEntityAdditionalInfoValue1_HasWildCard = 1 AND RTRIM(LTRIM(info.Value)) LIKE @CriteriaEntityAdditionalInfoValue1
											OR
											@CriteriaEntityAdditionalInfoValue1_HasWildCard = 0 AND RTRIM(LTRIM(info.Value)) = @CriteriaEntityAdditionalInfoValue1
										)
									)
								)
								OR
								@CriteriaEntityAdditionalInfoValue2 IS NOT NULL
								AND
								(
									@CriteriaEntityAdditionalInfoValue2_WildCardAny = 1 AND LEN(RTRIM(LTRIM(info.Value))) > 0
									OR
									(
										@CriteriaEntityAdditionalInfoValue2_WildCardAny = 0
										AND
										(
											@CriteriaEntityAdditionalInfoValue2_HasWildCard = 1 AND RTRIM(LTRIM(info.Value)) LIKE @CriteriaEntityAdditionalInfoValue2
											OR
											@CriteriaEntityAdditionalInfoValue2_HasWildCard = 0 AND RTRIM(LTRIM(info.Value)) = @CriteriaEntityAdditionalInfoValue2
										)
									)
								)
							)
					)
				)
			)
		)
		AND
		(
			(
				@CriteriaEntityAddressStreet1 IS NULL
				AND @CriteriaEntityAddressStreet2 IS NULL
				AND @CriteriaEntityAddressCity IS NULL
				AND @CriteriaEntityAddressCountry IS NULL
				AND @CriteriaEntityAddressPostalCode IS NULL
				AND @CriteriaEntityAddressStateProvinceDistrict IS NULL
			)
			OR EXISTS(SELECT 1 FROM dbo.CwlAddress addr
				WHERE addr.Entity_Id = entity.Id
				AND addr.IsDeleted = 0
				AND
				(
					(
						@CriteriaEntityAddressStreet1 IS NULL
						OR
						(
							@CriteriaEntityAddressStreet1 IS NOT NULL
							AND
							(
								@CriteriaEntityAddressStreet1_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.AddressLine1))) > 0
								OR
								(
									@CriteriaEntityAddressStreet1_WildCardAny = 0
									AND
									(
										@CriteriaEntityAddressStreet1_HasWildCard = 1 AND RTRIM(LTRIM(addr.AddressLine1)) LIKE @CriteriaEntityAddressStreet1
										OR
										@CriteriaEntityAddressStreet1_HasWildCard = 0 AND RTRIM(LTRIM(addr.AddressLine1)) = @CriteriaEntityAddressStreet1
									)
								)
							)
						)
					)
					AND
					(
						@CriteriaEntityAddressStreet2 IS NULL
						OR
						(
							@CriteriaEntityAddressStreet2 IS NOT NULL
							AND
							(
								@CriteriaEntityAddressStreet2_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.AddressLine2))) > 0
								OR
								(
									@CriteriaEntityAddressStreet2_WildCardAny = 0
									AND
									(
										@CriteriaEntityAddressStreet2_HasWildCard = 1 AND RTRIM(LTRIM(addr.AddressLine2)) LIKE @CriteriaEntityAddressStreet2
										OR
										@CriteriaEntityAddressStreet2_HasWildCard = 0 AND RTRIM(LTRIM(addr.AddressLine2)) = @CriteriaEntityAddressStreet2
									)
								)
							)
						)
					)
					AND
					(
						@CriteriaEntityAddressCity IS NULL
						OR
						(
							@CriteriaEntityAddressCity IS NOT NULL
							AND
							(
								@CriteriaEntityAddressCity_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.City))) > 0
								OR
								(
									@CriteriaEntityAddressCity_WildCardAny = 0
									AND
									(
										@CriteriaEntityAddressCity_HasWildCard = 1 AND RTRIM(LTRIM(addr.City)) LIKE @CriteriaEntityAddressCity
										OR
										@CriteriaEntityAddressCity_HasWildCard = 0 AND RTRIM(LTRIM(addr.City)) = @CriteriaEntityAddressCity
									)
								)
							)
						)
					)
					AND
					(
						@CriteriaEntityAddressCountry IS NULL
						OR
						(
							@CriteriaEntityAddressCountry IS NOT NULL
							AND
							(
								@CriteriaEntityAddressCountry_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.Country))) > 0
								OR
								(
									@CriteriaEntityAddressCountry_WildCardAny = 0
									AND
									(
										@CriteriaEntityAddressCountry_HasWildCard = 1 AND RTRIM(LTRIM(addr.Country)) LIKE @CriteriaEntityAddressCountry
										OR
										@CriteriaEntityAddressCountry_HasWildCard = 0 AND RTRIM(LTRIM(addr.Country)) = @CriteriaEntityAddressCountry
									)
								)
							)
						)
					)
					AND
					(
						@CriteriaEntityAddressPostalCode IS NULL
						OR
						(
							@CriteriaEntityAddressPostalCode IS NOT NULL
							AND
							(
								@CriteriaEntityAddressPostalCode_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.PostalCode))) > 0
								OR
								(
									@CriteriaEntityAddressPostalCode_WildCardAny = 0
									AND
									(
										@CriteriaEntityAddressPostalCode_HasWildCard = 1 AND RTRIM(LTRIM(addr.PostalCode)) LIKE @CriteriaEntityAddressPostalCode
										OR
										@CriteriaEntityAddressPostalCode_HasWildCard = 0 AND RTRIM(LTRIM(addr.PostalCode)) = @CriteriaEntityAddressPostalCode
									)
								)
							)
						)
					)
					AND
					(
						@CriteriaEntityAddressStateProvinceDistrict IS NULL
						OR
						(
							@CriteriaEntityAddressStateProvinceDistrict IS NOT NULL
							AND
							(
								@CriteriaEntityAddressStateProvinceDistrict_WildCardAny = 1 AND LEN(RTRIM(LTRIM(addr.[State]))) > 0
								OR
								(
									@CriteriaEntityAddressStateProvinceDistrict_WildCardAny = 0
									AND
									(
										@CriteriaEntityAddressStateProvinceDistrict_HasWildCard = 1 AND RTRIM(LTRIM(addr.[State])) LIKE @CriteriaEntityAddressStateProvinceDistrict
										OR
										@CriteriaEntityAddressStateProvinceDistrict_HasWildCard = 0 AND RTRIM(LTRIM(addr.[State])) = @CriteriaEntityAddressStateProvinceDistrict
									)
								)
							)
						)
					)
				)
			)
		)
		AND
        (
			(
				@CriteriaEntityAddressPhone IS null
                OR
				@CriteriaEntityAddressPhone IS NOT NULL
				AND
				EXISTS(SELECT 1 FROM CwlPhonenumber phone
					WHERE phone.Entity_Id = entity.Id
					AND phone.IsDeleted = 0
					AND
					(
						@CriteriaEntityAddressPhone_WildCardAny = 1 AND LEN(RTRIM(LTRIM(phone.Number))) > 0
						OR
						(
							@CriteriaEntityAddressPhone_WildCardAny = 0
							AND
							(
								@CriteriaEntityAddressPhone_HasWildCard = 1 AND RTRIM(LTRIM(phone.Number)) LIKE @CriteriaEntityAddressPhone
								OR
								@CriteriaEntityAddressPhone_HasWildCard = 0 AND RTRIM(LTRIM(phone.Number)) = @CriteriaEntityAddressPhone
							)
						)
					)
				)
			)
		)
		AND
		(
			(
				@CriteriaEntityIDType IS NULL
				OR @CriteriaEntityIDType = 0
				OR @CriteriaEntityIDLabel IS NULL AND @CriteriaEntityIDNumber IS NULL
			)
			OR EXISTS(SELECT 1 FROM dbo.CwlIdentification id
				WHERE id.Entity_Id = entity.Id
				AND id.Type = @CriteriaEntityIDType
				AND id.IsDeleted = 0
				AND
				(
					(
						@CriteriaEntityIDLabel IS NULL
						OR
						(
							@CriteriaEntityIDLabel IS NOT NULL
							AND
							(
								@CriteriaEntityIDLabel_WildCardAny = 1 AND LEN(RTRIM(LTRIM(id.Label))) > 0
								OR
								(
									@CriteriaEntityIDLabel_WildCardAny = 0
									AND
									(
										@CriteriaEntityIDLabel_HasWildCard = 1 AND RTRIM(LTRIM(id.Label)) LIKE @CriteriaEntityIDLabel
										OR
										@CriteriaEntityIDLabel_HasWildCard = 0 AND RTRIM(LTRIM(id.Label)) = @CriteriaEntityIDLabel
									)
								)
							)
						)
					)
					AND
					(
						@CriteriaEntityIDNumber IS NULL
						OR
						(
							@CriteriaEntityIDNumber IS NOT NULL
							AND
							(
								@CriteriaEntityIDNumber_WildCardAny = 1 AND LEN(RTRIM(LTRIM(id.Number))) > 0
								OR
								(
									@CriteriaEntityIDNumber_WildCardAny = 0
									AND
									(
										@CriteriaEntityIDNumber_HasWildCard = 1 AND REPLACE(RTRIM(LTRIM(id.Number)),'-','') LIKE @CriteriaEntityIDNumber
										OR
										@CriteriaEntityIDNumber_HasWildCard = 0 AND REPLACE(RTRIM(LTRIM(id.Number)),'-','') = @CriteriaEntityIDNumber
									)
								)
							)
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaReasonListed IS NULL
			OR
			(
				@CriteriaReasonListed IS NOT NULL
				AND
				(
					@CriteriaReasonListed_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.ReasonListed))) > 0
					OR
					(
						@CriteriaReasonListed_WildCardAny = 0
						AND
						(
							@CriteriaReasonListed_HasWildCard = 1 AND RTRIM(LTRIM(entity.ReasonListed)) LIKE @CriteriaReasonListed
							OR
							@CriteriaReasonListed_HasWildCard = 0 AND RTRIM(LTRIM(entity.ReasonListed)) = @CriteriaReasonListed
						)
					)
				)
			)
		)
		AND
		(
			@CriteriaReferenceNumber IS NULL
			OR
			(
				@CriteriaReferenceNumber IS NOT NULL
				AND
				(
					@CriteriaReferenceNumber_WildCardAny = 1 AND LEN(RTRIM(LTRIM(entity.ReferenceNumber))) > 0
					OR
					(
						@CriteriaReferenceNumber_WildCardAny = 0
						AND
						(
							@CriteriaReferenceNumber_HasWildCard = 1 AND RTRIM(LTRIM(entity.ReferenceNumber)) LIKE @CriteriaReferenceNumber
							OR
							@CriteriaReferenceNumber_HasWildCard = 0 AND RTRIM(LTRIM(entity.ReferenceNumber)) = @CriteriaReferenceNumber
						)
					)
				)
			)
		)
		ORDER BY Id ASC
	END
END


GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM   sys.objects WHERE  object_id = OBJECT_ID(N'[dbo].[Split]') AND type IN ( N'FN', N'IF', N'TF', N'FS', N'FT' ))
  DROP FUNCTION [dbo].[Split]
GO
CREATE FUNCTION [dbo].[Split]
(
    @String NVARCHAR(4000),
    @Delimiter NCHAR(1)
)
RETURNS TABLE
AS
RETURN
(
    WITH Split(stpos,endpos)
    AS(
        SELECT 0 AS stpos, CHARINDEX(@Delimiter,@String) AS endpos
        UNION ALL
        SELECT endpos+1, CHARINDEX(@Delimiter,@String,endpos+1)
            FROM Split
            WHERE endpos > 0
    )
    SELECT 'Id' = ROW_NUMBER() OVER (ORDER BY (SELECT 1)),
        'Data' = SUBSTRING(@String,stpos,COALESCE(NULLIF(endpos,0),LEN(@String)+1)-stpos)
    FROM Split
)
GO

-- GRANT EXECUTE ON [dbo].[CwlCustomWatchlistSearch] TO cdbr_E;
-- GO
